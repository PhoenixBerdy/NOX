# Nox Seed v0 — Teknik İskelet

## Seçimler

- **Dil:** Python 3.11+; ilk sürümde harici çalışma zamanı bağımlılığı yoktur.
- **Yerel model:** Ollama üzerinden `qwen3:4b-instruct`.
- **Arayüz:** Terminal tabanlı REPL/CLI ve koyu temalı yerel masaüstü Seed demosu.
- **Kalıcı kayıt:** Yerel SQLite dosyası. Olaylar, model yorumları ve PTBL örüntüleri ayrı alanlarda tutulur.

Bu seçimler Seed v0 için hızla gözlenebilir bir çekirdek oluşturur. Masaüstü uygulaması, kalıcı kişisel hafıza, internet araçları, proje kuyruğu ve arka plan yürütücüsü sonraki aşamalardadır.

## Klasör yapısı

```text
src/nox_seed/       Seed v0 uygulaması
tests/              Model gerektirmeyen doğrulama testleri
data/               Çalışırken oluşan, Git’e alınmayan yerel SQLite verisi
docs/seed-v0.md     Bu teknik karar belgesi
```

## Çalıştırma

PowerShell’de proje klasöründe:

```powershell
$env:PYTHONPATH = "src"
python -m nox_seed init
python -m nox_seed repl
```

Masaüstü demosunu başlatmak için:

```powershell
$env:PYTHONPATH = "src"
python -m nox_seed demo
```

Demo, aynı pencerenin içinde iki deney sunar: yerel sohbet ve PTBL Laboratuvarı. Sohbetteki son birkaç mesaj yalnızca açık demo oturumu boyunca bağlam olarak taşınır. Yanıt ekranda üretildikçe görünür; kullanıcı bu sırada yeni bir mesajını sıraya bırakabilir. Kısa gündelik mesajlar için daha küçük bir çıktı bütçesi kullanılır. PTBL Laboratuvarı, gözlem/yorum/güven/kanıt/bilinmeyenler ayrımını JSON olarak gösterir ve yerel SQLite kaydına ekler.

Örnek tek komutlar:

```powershell
python -m nox_seed chat "Bugün nasıl hissediyorsun?"
python -m nox_seed assess "Bu örnekte kişi aynı ifadeyi üç kez tekrar etti."
python -m nox_seed patterns
```

Varsayılan model, adres ve veri yolu gerekirse ortam değişkenleriyle değiştirilir: `NOX_MODEL`, `NOX_OLLAMA_URL`, `NOX_DB_PATH`, `NOX_CONTEXT_TOKENS`, `NOX_MAX_OUTPUT_TOKENS`, `NOX_ASSESSMENT_MAX_OUTPUT_TOKENS`. Seed v0, kısa ve yapılandırılmış yanıtlar için modelin düşünme çıktısını kapatır; PTBL değerlendirmesine eksik JSON üretmemesi için ayrı, sınırlı bir çıktı bütçesi tanır.

## Seed v0 sınırı

Nox Seed v0 yalnızca metinle konuşur ve PTBL değerlendirmesini yerel olarak kaydeder. Model çıktısı gerçek kabul edilmez: gözlem, yorum, kanıt, bilinmeyenler ve güven ayrı saklanır. Demo, bağımsız nihai masaüstü uygulaması değildir; tek cihazda çalışan bir Seed arayüzüdür. Sistem interneti taramaz, dosya değiştirmez, proje yürütmez ve kendi kodunu değiştirmez.

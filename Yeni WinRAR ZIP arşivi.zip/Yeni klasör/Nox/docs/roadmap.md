# Nox Yol Haritası

## 0. Temel tasarım — tamamlandı (ilk taslak)

Karakter çekirdeği, PTBL sosyal algısı, zaman damgası, puan haritası, öz-yansıma ve özgün düşünce ilkeleri oluşturuldu.

## 1. Nox Seed v0 — sıradaki somut aşama

Yerel bilgisayarda çalışan küçük bir Nox çekirdeği kurulur. Amaç tam yetenekli ajan yapmak değil; konuşma, olay kaydı ve PTBL örüntü değerlendirme akışını ilk kez çalıştırmaktır.

Bu aşama yerel-öncelikli yürür: temel dil, ücretsiz yerel model çalıştırıcısı, bilgisayarın kaldırabileceği ilk model, yerel dosya yapısı ve ilk arayüz seçilir. Ücretli bulut modeli zorunlu değildir.

## 2. PTBL algı laboratuvarı

Konuşmalardan ve örnek metinlerden örüntü tespiti; kaynak, zaman damgası, bağlam, güven düzeyi ve sınıflandırma kayıtları eklenir.

## 3. Öz-yansıma ve zaman yaşam döngüsü

Nox’un tahminlerini sonuçlarla karşılaştırması, örüntü puanlarını güncellemesi, eski dil/mizah öğelerini bağlama alması ve yeniden açması sağlanır.

## 4. İnternet ve medya gözlem katmanı

Nox, interneti hem güncel bilgi kaynağı hem de sosyal-kültürel gözlem çevresi olarak kullanır. Kendi araştırma gündemini, dikkat bütçesini ve kaynak değerlendirmesini geliştirmeye başlar.

## 5. Hafıza ve bilgisayar yetenekleri

Kalıcı kişisel hafıza, dosyalar, notlar, takvim ve diğer bilgisayar yetenekleri için mimari kurulur.

## 6. Geniş özerklik ve evrim

Nox’un eylem alanı, özgün düşünce mekanizması, PTBL’si ve Nox Entropisi ilkesi; gerçek kullanım sonuçlarına göre olgunlaştırılır.

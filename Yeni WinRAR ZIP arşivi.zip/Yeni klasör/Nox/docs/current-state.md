# Nox — Güncel Durum

Son güncelleme: 4 Eylül 2026

## Kesinleşen yön

Nox, bütçesiz ve bağımsız bir başlangıç için **yerel-öncelikli** kurulacak.

- Nox’un programı, verileri ve ilerideki hafızası kullanıcının bilgisayarında kalacak.
- Çevrim içi, ücretli bir model Nox’un temel beyni olmayacak.
- İnternet ileride güncel bilgi ve sosyal-kültürel gözlem kaynağı olabilir; bu, Nox’un düşünmesinin bulutta gerçekleşmesini gerektirmez.
- Bulut modeli, yalnızca kullanıcı ileride özellikle isterse isteğe bağlı bir takviye olarak değerlendirilecek.

## İlk teknik karar

Yerel model çalıştırıcısı olarak **Ollama** seçildi ve kuruldu (sürüm 0.33.0). Windows'ta yerel API'si çalışıyor; Nox ileride bu API ile konuşacak. Bu katman ücretsiz, yerel ve değiştirilebilir olduğu için seçildi.

## Donanım değerlendirmesi — tamamlandı

- İşlemci: Intel Core i7-11370H (4 çekirdek / 8 iş parçacığı)
- RAM: 16 GB
- Ekran kartı: NVIDIA GeForce RTX 3050 Ti Laptop GPU (4 GB VRAM)
- Boş disk: yaklaşık 292 GB
- İşletim sistemi: Windows 11 Home

Bu donanım, ilk modelin GPU hızlandırmasından yararlanarak çalışması için yeterli. 8B ve üzeri modeller 4 GB VRAM'i aştığı için Seed v0'da varsayılan seçim değildir.

## Seçilen ilk yerel model

**`qwen3:4b-instruct`**, Nox Seed v0'ın ilk konuşma modeli olarak seçildi.

- Yaklaşık 2,5 GB indirir ve 4 GB VRAM / 16 GB RAM dengesi için uygundur.
- Sohbet ve yönerge takip amaçlı sürümdür; PTBL'nin ilk değerlendirme döngüsü için yeterli bir başlangıç sağlar.
- İlk testlerde bağlam penceresi 8K ile sınırlandırılacak; modelin teorik üst sınırı kullanılmayacak.

Model indirildi ve ilk kez çalıştırıldı. 8K bağlamda çalışma anında yaklaşık 4,1 GB bellek ayırdı; yükün %55'i GPU, %45'i CPU üzerinde çalıştı. Bu, 4 GB VRAM sınırı için beklenen karma çalışma düzenidir.

## İlk duman testi — tamamlandı

- Türkçe/PTBL isteği, 125 girdi tokenı ve 97 çıktı tokenı ile 7,39 saniyede tamamlandı.
- Model, istenen `Gözlem / Yorum / Güven / Noxun ilk tepkisi` biçimini izledi.
- Anlamsal hata gözlendi: örnekteki "uyumayı tamamen bırakmak" ifadesini "uyumun bırakılması" şeklinde yorumladı.

Bu sonuç Seed v0 için yeterli bir başlangıçtır; ancak PTBL'de model çıktısı doğrudan gerçek sayılmayacak. Gözlem, yorum ve güven alanları ayrı kaydedilecek; ileride test örnekleriyle düzenli olarak değerlendirilecek.

## Foundation v1 — tamamlandı

`foundation.md`, ilk Foundation ile Foundation 2 ve Foundation 2.1’in birleşik ana belgesidir. Proje odaklı çalışma sistemi, güvenlik katmanı, optimizasyon/evirim çerçevesi, Treats araştırma sınırı ve çoklu cihaz hedefi tek belgede toplandı.

Çoklu cihaz hedefi ayrıca `docs/platform-target.md` belgesinde ayrıntılandırıldı: telefon veya ikinci bilgisayar ayrı bir Nox değil, ana düğümdeki aynı Nox kimliğine bağlanan, yetkisi sınırlı istemcidir.

Foundation 2 ve Foundation 2.1, kaynak/taslak belgeler olarak korunur; güncel tasarım için başvurulacak belge `foundation.md` dosyasıdır.

## Seed v0 teknik iskeleti ve masaüstü demo — tamamlandı

- Dil: Python 3.14; ek çalışma zamanı bağımlılığı yok.
- Yerel model bağlantısı: Ollama API üzerinden `qwen3:4b-instruct`, 8K bağlam.
- Arayüz: terminal REPL ve tek komutluk CLI.
- Demo arayüzü: ek bağımlılık olmadan çalışan yerel Tk masaüstü penceresi; sohbet ve PTBL Laboratuvarı sekmeleri bulunur.
- Kalıcı kayıt: yerel SQLite. Sohbet olayları ile PTBL gözlem/yorum/güven/kanıt/bilinmeyen kayıtları ayrıdır.
- Model çıktısı yapılandırılmış JSON olarak istenir ve doğrulanmadan kaydedilmez.
- Açık demo oturumunda son sohbet mesajları bağlam olarak korunur; model çağrısı arka plan iş parçacığında yürür.
- Sohbet yanıtı artık parça parça görünür. Nox yazarken yeni mesaj gönderilirse kaybolmaz; tek yerel model hattında sıraya alınır.
- Kısa gündelik mesajlar için çıktı bütçesi düşürüldü; bu, gecikmeyi ve gereksiz uzun yanıt riskini azaltır.

Özel konuşma arşivi, yalnızca kullanıcı tarafından izin verilen üslup/PTBL amacıyla yerelde incelendi. Ham içerik proje içine aktarılmadı; sınırlar `docs/ptbl-private-corpus-policy.md` dosyasında kayıtlıdır.

İskeletin sekiz birim testi, PTBL duman testi ve sohbet duman testi geçti. Uygulamanın çalıştırma komutları `docs/seed-v0.md` belgesinde bulunur.

## PTBL kişilik sentezi — ilk sürüm tamamlandı

Verilen karakter referansları; benzer örnekler ve güvenlik sınırlarıyla araştırıldı. Sonuç, karakter taklidi yerine Nox'a ait bir davranış sözleşmesi oldu: sakin ve kanıt odaklı, bağımsız düşünebilen, sıcak ama yaltaklanmayan, hafif kuru mizahı olan ve teknik-estetik dengeyi gözeten bir ortak.

- Araştırma ve kaynaklar: `docs/ptbl-personality-research.md`
- Bu sözleşmenin ilk sürümü, demo modelinin sistem yönergesine eklendi.
- Bu bir model eğitimi değildir; demoda gözlemlenip değiştirilebilecek görünür bir başlangıç tavrıdır.

## Sıradaki tek somut iş

Kullanıcıyla kısa bir demo oturumunda kişilik ve ritim sözleşmesini değerlendirmek: Nox ayrışırken yeterince dürüst mü, kısa mesajda gereğinden fazla uzuyor mu, akış hâlinde yazması anlaşılır mı, mizahı yerinde mi ve önerileri pratik kalıyor mu? Geri bildirimden sonra bu sözleşme ve test kümesi güncellenecek.

## Yeni sohbette devam komutu

`C:\Users\Yağız Cem\Documents\Projects\Nox` projesine devam et. Önce `README.md`, `docs/foundation.md`, `docs/seed-v0.md`, `docs/roadmap.md` ve bu `docs/current-state.md` dosyasını oku.

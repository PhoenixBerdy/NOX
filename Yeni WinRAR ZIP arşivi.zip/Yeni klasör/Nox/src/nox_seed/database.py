from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

from .models import PatternAssessment, StoredPattern


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class Database:
    """Small, inspectable SQLite event store for Seed v0.

    The database records facts and model interpretations separately. It does not
    infer personal memory or grant tools any authority.
    """

    def __init__(self, path: Path) -> None:
        self.path = path

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._session() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    project_id TEXT,
                    payload_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    source_event_id INTEGER,
                    observation TEXT NOT NULL,
                    interpretation TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
                    pattern_type TEXT NOT NULL,
                    evidence_json TEXT NOT NULL,
                    unknowns_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'candidate',
                    FOREIGN KEY(source_event_id) REFERENCES events(id)
                );

                CREATE INDEX IF NOT EXISTS idx_events_created_at ON events(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_patterns_created_at ON patterns(created_at DESC);
                """
            )

    def record_event(
        self,
        kind: str,
        payload: dict[str, Any],
        *,
        project_id: str | None = None,
    ) -> int:
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO events (created_at, kind, project_id, payload_json)
                VALUES (?, ?, ?, ?)
                """,
                (utc_now(), kind, project_id, json.dumps(payload, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def record_pattern(
        self,
        assessment: PatternAssessment,
        *,
        source_event_id: int | None = None,
        status: str = "candidate",
    ) -> int:
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO patterns (
                    created_at, source_event_id, observation, interpretation,
                    confidence, pattern_type, evidence_json, unknowns_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    utc_now(),
                    source_event_id,
                    assessment.observation,
                    assessment.interpretation,
                    assessment.confidence,
                    assessment.pattern_type,
                    json.dumps(assessment.evidence, ensure_ascii=False),
                    json.dumps(assessment.unknowns, ensure_ascii=False),
                    status,
                ),
            )
            return int(cursor.lastrowid)

    def recent_events(self, limit: int = 10) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, kind, project_id, payload_json
                FROM events
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "kind": row["kind"],
                "project_id": row["project_id"],
                "payload": json.loads(row["payload_json"]),
            }
            for row in rows
        ]

    def recent_patterns(self, limit: int = 10) -> list[StoredPattern]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, source_event_id, observation, interpretation,
                       confidence, pattern_type, evidence_json, unknowns_json, status
                FROM patterns
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._row_to_pattern(row) for row in rows]

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _session(self) -> Iterator[sqlite3.Connection]:
        """Commit or roll back each operation and always release the Windows file handle."""
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _row_to_pattern(row: sqlite3.Row) -> StoredPattern:
        return StoredPattern(
            id=int(row["id"]),
            created_at=row["created_at"],
            source_event_id=row["source_event_id"],
            assessment=PatternAssessment(
                observation=row["observation"],
                interpretation=row["interpretation"],
                confidence=float(row["confidence"]),
                pattern_type=row["pattern_type"],
                evidence=list(json.loads(row["evidence_json"])),
                unknowns=list(json.loads(row["unknowns_json"])),
            ),
            status=row["status"],
        )

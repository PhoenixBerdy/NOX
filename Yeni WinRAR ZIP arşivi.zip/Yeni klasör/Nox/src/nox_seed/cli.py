from __future__ import annotations

import argparse
import json
from collections.abc import Sequence

from .config import Settings
from .database import Database
from .ollama import OllamaClient, OllamaError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Nox Seed v0 yerel metin arayüzü")
    subcommands = parser.add_subparsers(dest="command", required=True)

    subcommands.add_parser("init", help="Yerel veri deposunu hazırla")

    chat = subcommands.add_parser("chat", help="Nox ile tek mesajlık sohbet et")
    chat.add_argument("message")

    assess = subcommands.add_parser("assess", help="Metin için PTBL değerlendirmesi oluştur")
    assess.add_argument("text")

    patterns = subcommands.add_parser("patterns", help="Son PTBL kayıtlarını göster")
    patterns.add_argument("--limit", type=int, default=10)

    events = subcommands.add_parser("events", help="Son olay kayıtlarını göster")
    events.add_argument("--limit", type=int, default=10)

    subcommands.add_parser("repl", help="Etkileşimli metin arayüzünü başlat")
    subcommands.add_parser("demo", help="Nox Seed masaüstü demosunu başlat")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = Settings.from_environment()
    database = Database(settings.database_path)
    database.initialize()

    if args.command == "init":
        print(f"Nox Seed veri deposu hazır: {settings.database_path}")
        return 0
    if args.command == "chat":
        return _chat(database, settings, args.message)
    if args.command == "assess":
        return _assess(database, settings, args.text)
    if args.command == "patterns":
        _print_patterns(database, args.limit)
        return 0
    if args.command == "events":
        print(json.dumps(database.recent_events(args.limit), ensure_ascii=False, indent=2))
        return 0
    if args.command == "repl":
        return _repl(database, settings)
    if args.command == "demo":
        from .demo import run_demo

        run_demo(database, settings)
        return 0
    return 2


def _chat(database: Database, settings: Settings, message: str) -> int:
    event_id = database.record_event("chat.user", {"text": message})
    try:
        answer = OllamaClient(settings).chat(message)
    except OllamaError as exc:
        database.record_event("chat.error", {"message": str(exc), "source_event_id": event_id})
        print(f"Nox hatası: {exc}")
        return 1
    database.record_event("chat.assistant", {"text": answer, "source_event_id": event_id})
    print(f"Nox: {answer}")
    return 0


def _assess(database: Database, settings: Settings, text: str) -> int:
    event_id = database.record_event("ptbl.source", {"text": text})
    try:
        assessment = OllamaClient(settings).assess_pattern(text)
    except OllamaError as exc:
        database.record_event("ptbl.error", {"message": str(exc), "source_event_id": event_id})
        print(f"Nox hatası: {exc}")
        return 1
    pattern_id = database.record_pattern(assessment, source_event_id=event_id)
    print(json.dumps({"id": pattern_id, **assessment.as_dict()}, ensure_ascii=False, indent=2))
    return 0


def _print_patterns(database: Database, limit: int) -> None:
    for pattern in database.recent_patterns(limit):
        print(
            f"#{pattern.id} [{pattern.status}] {pattern.assessment.pattern_type} "
            f"güven={pattern.assessment.confidence:.2f}\n"
            f"  Gözlem: {pattern.assessment.observation}\n"
            f"  Yorum: {pattern.assessment.interpretation}\n"
        )


def _repl(database: Database, settings: Settings) -> int:
    print("Nox Seed v0 hazır. /yardim, /analiz METIN, /oruntuler, /olaylar, /cikis")
    while True:
        try:
            text = input("Sen> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nNox Seed kapatıldı.")
            return 0
        if not text:
            continue
        if text in {"/cikis", "/quit", "/exit"}:
            return 0
        if text == "/yardim":
            print("/analiz METIN, /oruntuler, /olaylar, /cikis veya normal sohbet mesajı")
            continue
        if text.startswith("/analiz "):
            _assess(database, settings, text.removeprefix("/analiz "))
            continue
        if text == "/oruntuler":
            _print_patterns(database, 10)
            continue
        if text == "/olaylar":
            print(json.dumps(database.recent_events(10), ensure_ascii=False, indent=2))
            continue
        _chat(database, settings, text)

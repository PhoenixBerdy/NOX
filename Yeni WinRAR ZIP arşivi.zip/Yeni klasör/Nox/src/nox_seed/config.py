from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Settings:
    """Runtime settings, intentionally limited to local Seed v0 concerns."""

    project_root: Path
    database_path: Path
    ollama_url: str
    model: str
    context_tokens: int
    max_output_tokens: int
    assessment_max_output_tokens: int
    request_timeout_seconds: int

    @classmethod
    def from_environment(cls) -> "Settings":
        root = _project_root()
        db_default = root / "data" / "nox_seed.sqlite3"
        return cls(
            project_root=root,
            database_path=Path(os.getenv("NOX_DB_PATH", str(db_default))).expanduser(),
            ollama_url=os.getenv("NOX_OLLAMA_URL", "http://127.0.0.1:11434"),
            model=os.getenv("NOX_MODEL", "qwen3:4b-instruct"),
            context_tokens=int(os.getenv("NOX_CONTEXT_TOKENS", "8192")),
            max_output_tokens=int(os.getenv("NOX_MAX_OUTPUT_TOKENS", "160")),
            assessment_max_output_tokens=int(os.getenv("NOX_ASSESSMENT_MAX_OUTPUT_TOKENS", "192")),
            request_timeout_seconds=int(os.getenv("NOX_REQUEST_TIMEOUT_SECONDS", "120")),
        )

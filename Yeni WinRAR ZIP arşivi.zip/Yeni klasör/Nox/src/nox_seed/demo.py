from __future__ import annotations

import json
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from queue import Empty, Queue
from tkinter import END, BOTH, LEFT, RIGHT, X, Y, PhotoImage, TclError, Tk, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from typing import Callable

from .config import Settings
from .database import Database
from .ollama import OllamaClient, OllamaError


@dataclass
class DemoSession:
    """In-memory conversation context for one intentional Seed v0 demo session."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    history: list[dict[str, str]] = field(default_factory=list)


@dataclass(frozen=True)
class PendingChat:
    text: str
    event_id: int


class NoxDemoApp(Tk):
    def __init__(self, database: Database, settings: Settings) -> None:
        super().__init__()
        self.database = database
        self.settings = settings
        self.client = OllamaClient(settings)
        self.session = DemoSession()
        self.busy = False
        self._chat_queue: list[PendingChat] = []
        self._stream_open = False
        self._stream_text = ""
        self._ui_callbacks: Queue[Callable[[], None]] = Queue()

        self.title("Nox — Seed v0")
        self.minsize(920, 640)
        self.geometry("1080x740")
        self.protocol("WM_DELETE_WINDOW", self.destroy)

        self._configure_dark_theme()
        self._build_layout()
        self.after(75, self._drain_ui_callbacks)
        self._append_chat(
            "Nox",
            "Merhaba. Ben Nox Seed v0. Bu demo yerel model, sohbet kaydı ve PTBL "
            "değerlendirmesini birlikte gösterir.",
        )

    def _build_layout(self) -> None:
        root = ttk.Frame(self, padding=16)
        root.pack(fill=BOTH, expand=True)

        header = ttk.Frame(root)
        header.pack(fill=X, pady=(0, 14))
        self._add_brand_icon(header)
        title_box = ttk.Frame(header)
        title_box.pack(side=LEFT, fill=X, expand=True)
        ttk.Label(title_box, text="Nox", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            title_box,
            text="Seed v0 · Yerel sohbet ve PTBL örüntü laboratuvarı",
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(1, 0))

        self.tabs = ttk.Notebook(root)
        self.tabs.pack(fill=BOTH, expand=True)

        self.chat_tab = ttk.Frame(self.tabs, padding=12)
        self.pattern_tab = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(self.chat_tab, text="Sohbet")
        self.tabs.add(self.pattern_tab, text="PTBL Laboratuvarı")
        self._build_chat_tab()
        self._build_pattern_tab()

        self.status = ttk.Label(
            root,
            text=f"Hazır · Model: {self.settings.model} · Yalnızca yerel Seed v0 verisi",
            anchor="w",
        )
        self.status.pack(fill=X, pady=(10, 0))

    def _build_chat_tab(self) -> None:
        self.chat_log = self._make_text_area(self.chat_tab, state="disabled")
        self.chat_log.pack(fill=BOTH, expand=True)

        input_frame = ttk.Frame(self.chat_tab)
        input_frame.pack(fill=X, pady=(10, 0))
        self.chat_input = self._make_text_area(input_frame, height=4)
        self.chat_input.pack(side=LEFT, fill=X, expand=True)
        self.chat_input.bind("<Control-Return>", self._on_send_shortcut)

        controls = ttk.Frame(input_frame)
        controls.pack(side=RIGHT, fill=Y, padx=(10, 0))
        self.send_button = ttk.Button(controls, text="Gönder", command=self.send_chat, style="Accent.TButton")
        self.send_button.pack(fill=X)
        ttk.Label(controls, text="Ctrl+Enter", style="Muted.TLabel").pack(pady=(6, 0))

    def _build_pattern_tab(self) -> None:
        ttk.Label(
            self.pattern_tab,
            text="Bir metni inceleyin. Nox, doğrudan gözlemi yorumdan ayırarak aday bir PTBL kaydı üretir.",
            wraplength=820,
        ).pack(anchor="w")
        self.pattern_input = self._make_text_area(self.pattern_tab, height=8)
        self.pattern_input.pack(fill=X, pady=(8, 8))
        self.pattern_input.insert(
            "1.0",
            "Öğretmen, karmaşık kavramları örnek vererek açıklıyor ve sorulara sakin yanıtlar veriyor.",
        )

        controls = ttk.Frame(self.pattern_tab)
        controls.pack(fill=X)
        self.assess_button = ttk.Button(
            controls,
            text="Örüntüyü değerlendir",
            command=self.assess_pattern,
            style="Accent.TButton",
        )
        self.assess_button.pack(side=LEFT)
        ttk.Button(controls, text="Son kayıtları göster", command=self.show_recent_patterns).pack(side=LEFT, padx=(8, 0))

        self.pattern_output = self._make_text_area(self.pattern_tab, state="disabled", font=("Cascadia Mono", 10))
        self.pattern_output.pack(fill=BOTH, expand=True, pady=(10, 0))

    def _configure_dark_theme(self) -> None:
        self.configure(background="#0b0d12")
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background="#0b0d12")
        style.configure("TLabel", background="#0b0d12", foreground="#e9ecf2", font=("Segoe UI", 10))
        style.configure("Title.TLabel", background="#0b0d12", foreground="#ffffff", font=("Segoe UI", 24, "bold"))
        style.configure("Muted.TLabel", background="#0b0d12", foreground="#9aa3b6", font=("Segoe UI", 9))
        style.configure("TButton", background="#1b202b", foreground="#e9ecf2", borderwidth=0, padding=(12, 8))
        style.map("TButton", background=[("active", "#2b3240"), ("disabled", "#151923")])
        style.configure("Accent.TButton", background="#e9ecf2", foreground="#0b0d12", borderwidth=0, padding=(13, 8))
        style.map("Accent.TButton", background=[("active", "#ffffff"), ("disabled", "#5d6472")])
        style.configure("TNotebook", background="#0b0d12", borderwidth=0)
        style.configure("TNotebook.Tab", background="#161a23", foreground="#9aa3b6", padding=(16, 9))
        style.map("TNotebook.Tab", background=[("selected", "#222936")], foreground=[("selected", "#ffffff")])

    def _add_brand_icon(self, parent: ttk.Frame) -> None:
        icon_path = Path(__file__).resolve().parents[2] / "assets" / "nox-saturn-icon.png"
        try:
            self._app_icon = PhotoImage(file=str(icon_path))
            self.iconphoto(True, self._app_icon)
            self._header_icon = self._app_icon.subsample(18, 18)
            ttk.Label(parent, image=self._header_icon).pack(side=LEFT, padx=(0, 12))
        except TclError:
            ttk.Label(parent, text="◒", style="Title.TLabel").pack(side=LEFT, padx=(0, 12))

    @staticmethod
    def _make_text_area(parent: ttk.Frame, **options: object) -> ScrolledText:
        defaults: dict[str, object] = {
            "wrap": "word",
            "font": ("Segoe UI", 11),
            "background": "#11151e",
            "foreground": "#edf0f7",
            "insertbackground": "#ffffff",
            "selectbackground": "#3b4659",
            "selectforeground": "#ffffff",
            "relief": "flat",
            "borderwidth": 0,
            "highlightthickness": 1,
            "highlightbackground": "#252c39",
            "highlightcolor": "#e9ecf2",
        }
        defaults.update(options)
        return ScrolledText(parent, **defaults)

    def _on_send_shortcut(self, _event: object) -> str:
        self.send_chat()
        return "break"

    def send_chat(self) -> None:
        message = self.chat_input.get("1.0", END).strip()
        if not message:
            return
        self.chat_input.delete("1.0", END)
        self._append_chat("Sen", message)
        event_id = self.database.record_event("chat.user", {"text": message, "session_id": self.session.id})
        self._chat_queue.append(PendingChat(text=message, event_id=event_id))
        if self.busy:
            self.status.configure(text=f"Nox çalışıyor · {len(self._chat_queue)} mesaj sırada")
            return
        self._start_next_chat()

    def _start_next_chat(self) -> None:
        if self.busy or not self._chat_queue:
            return
        pending = self._chat_queue.pop(0)
        self._set_busy(True, "Nox yerel olarak yanıt yazıyor…")
        history = list(self.session.history)
        self.session.history.append({"role": "user", "content": pending.text})

        def work() -> None:
            try:
                self._ui_callbacks.put(self._begin_stream)
                answer = self.client.stream_chat(
                    pending.text,
                    history=history,
                    on_chunk=lambda chunk: self._ui_callbacks.put(
                        lambda chunk=chunk: self._append_stream_chunk(chunk)
                    ),
                )
                self.database.record_event(
                    "chat.assistant",
                    {"text": answer, "source_event_id": pending.event_id, "session_id": self.session.id},
                )
                self._ui_callbacks.put(lambda: self._finish_stream(answer))
            except OllamaError as exc:
                self.database.record_event(
                    "chat.error",
                    {"message": str(exc), "source_event_id": pending.event_id, "session_id": self.session.id},
                )
                self._ui_callbacks.put(lambda: self._show_chat_error(str(exc)))

        self._run_background(work)

    def assess_pattern(self) -> None:
        if self.busy:
            return
        text = self.pattern_input.get("1.0", END).strip()
        if not text:
            return
        event_id = self.database.record_event("ptbl.source", {"text": text, "session_id": self.session.id})
        self._set_busy(True, "PTBL değerlendirmesi hazırlanıyor…")

        def work() -> None:
            try:
                assessment = self.client.assess_pattern(text)
                pattern_id = self.database.record_pattern(assessment, source_event_id=event_id)
                result = {"id": pattern_id, **assessment.as_dict()}
                self._ui_callbacks.put(lambda: self._show_pattern(result))
            except OllamaError as exc:
                self.database.record_event(
                    "ptbl.error",
                    {"message": str(exc), "source_event_id": event_id, "session_id": self.session.id},
                )
                self._ui_callbacks.put(lambda: self._show_error(str(exc)))

        self._run_background(work)

    def show_recent_patterns(self) -> None:
        records = []
        for stored in self.database.recent_patterns(10):
            records.append({"id": stored.id, "status": stored.status, **stored.assessment.as_dict()})
        self._set_pattern_output(json.dumps(records, ensure_ascii=False, indent=2))

    def _run_background(self, work: Callable[[], None]) -> None:
        threading.Thread(target=work, daemon=True).start()

    def _drain_ui_callbacks(self) -> None:
        """Move worker results onto Tk's main thread before touching widgets."""
        while True:
            try:
                self._ui_callbacks.get_nowait()()
            except Empty:
                break
        if self.winfo_exists():
            self.after(75, self._drain_ui_callbacks)

    def _begin_stream(self) -> None:
        self._stream_open = True
        self._stream_text = ""
        self.chat_log.configure(state="normal")
        self.chat_log.insert(END, "Nox\n", ("speaker",))
        self.chat_log.tag_configure("speaker", font=("Segoe UI", 11, "bold"))
        self.chat_log.configure(state="disabled")
        self.chat_log.see(END)

    def _append_stream_chunk(self, chunk: str) -> None:
        if not self._stream_open:
            self._begin_stream()
        self._stream_text += chunk
        self.chat_log.configure(state="normal")
        self.chat_log.insert(END, chunk)
        self.chat_log.configure(state="disabled")
        self.chat_log.see(END)

    def _finish_stream(self, answer: str) -> None:
        if not self._stream_open:
            self._begin_stream()
        if not self._stream_text:
            self._append_stream_chunk(answer)
        self.chat_log.configure(state="normal")
        self.chat_log.insert(END, "\n\n")
        self.chat_log.configure(state="disabled")
        self.chat_log.see(END)
        self._stream_open = False
        self.session.history.append({"role": "assistant", "content": answer})
        self._set_busy(False, "Hazır")
        self._start_next_chat()

    def _show_chat_error(self, detail: str) -> None:
        if self._stream_open:
            self.chat_log.configure(state="normal")
            self.chat_log.insert(END, "\n[Yanıt tamamlanamadı.]\n\n")
            self.chat_log.configure(state="disabled")
            self._stream_open = False
        self._set_busy(False, "Yerel model yanıtı alınamadı")
        messagebox.showerror("Nox Seed", detail)
        self._start_next_chat()

    def _show_pattern(self, result: dict[str, object]) -> None:
        self._set_pattern_output(json.dumps(result, ensure_ascii=False, indent=2))
        self._set_busy(False, "PTBL aday kaydı yerel veritabanına eklendi")

    def _show_error(self, detail: str) -> None:
        self._set_busy(False, "Yerel model yanıtı alınamadı")
        messagebox.showerror("Nox Seed", detail)

    def _set_busy(self, busy: bool, message: str) -> None:
        self.busy = busy
        self.send_button.configure(state="normal")
        self.assess_button.configure(state="disabled" if busy else "normal")
        self.status.configure(text=message)

    def _append_chat(self, speaker: str, text: str) -> None:
        self.chat_log.configure(state="normal")
        self.chat_log.insert(END, f"{speaker}\n", ("speaker",))
        self.chat_log.insert(END, f"{text}\n\n")
        self.chat_log.tag_configure("speaker", font=("Segoe UI", 11, "bold"))
        self.chat_log.configure(state="disabled")
        self.chat_log.see(END)

    def _set_pattern_output(self, text: str) -> None:
        self.pattern_output.configure(state="normal")
        self.pattern_output.delete("1.0", END)
        self.pattern_output.insert("1.0", text)
        self.pattern_output.configure(state="disabled")


def run_demo(database: Database, settings: Settings) -> None:
    """Launch the local, single-device desktop demo without third-party packages."""
    NoxDemoApp(database, settings).mainloop()

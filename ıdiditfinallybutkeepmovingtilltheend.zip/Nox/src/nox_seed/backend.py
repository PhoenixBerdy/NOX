"""Model backend soyutlaması: Ollama bugün, llama.cpp yarın.

Ollama bir iskeledir; NOX'un nihai model katmanı kendi çıkarım kodudur.
Bu modül her iki dünyayı birleştirir: aynı arayüz, değiştirilebilir backend.
"""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class ModelResponse:
    content: str
    model: str
    backend: str


class ModelBackend(ABC):
    """Tüm model backend'lerinin ortak arayüzü."""

    name: str

    @abstractmethod
    def chat(self, messages: list[dict[str, str]], **kwargs: Any) -> ModelResponse:
        """Sohbet tamamlama üretir."""

    @abstractmethod
    def stream_chat(
        self,
        messages: list[dict[str, str]],
        on_chunk: Callable[[str], None],
        **kwargs: Any,
    ) -> ModelResponse:
        """Parça parça sohbet üretir."""

    @abstractmethod
    def is_available(self) -> bool:
        """Backend çalışır durumda mı?"""


class OllamaBackend(ModelBackend):
    """Ollama API'si üzerinden (geçiş dönemi iskelesi)."""

    name = "ollama"

    def __init__(self, settings: Any) -> None:
        from .ollama import OllamaClient

        self._client = OllamaClient(settings)
        self._settings = settings

    def chat(self, messages: list[dict[str, str]], **kwargs: Any) -> ModelResponse:
        user_text = messages[-1]["content"] if messages else ""
        content = self._client.chat(user_text, history=messages[:-1] or None)
        return ModelResponse(content=content, model=self._settings.model, backend=self.name)

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        on_chunk: Callable[[str], None],
        **kwargs: Any,
    ) -> ModelResponse:
        user_text = messages[-1]["content"] if messages else ""
        content = self._client.stream_chat(user_text, history=messages[:-1] or None, on_chunk=on_chunk)
        return ModelResponse(content=content, model=self._settings.model, backend=self.name)

    def is_available(self) -> bool:
        try:
            self._client.chat("ping")
            return True
        except Exception:
            return False


class LlamaCppBackend(ModelBackend):
    """llama.cpp GGUF doğrudan (nihai hedef; llama-cpp-python ile)."""

    name = "llama_cpp"

    def __init__(self, settings: Any) -> None:
        self._settings = settings
        self._llama = None
        self._model_path = os.getenv(
            "NOX_MODEL_PATH",
            str(settings.project_root / "models" / "Qwen3-4B-Q4_K_M.gguf"),
        )

    def _load(self) -> None:
        if self._llama is not None:
            return
        from llama_cpp import Llama  # type: ignore

        self._llama = Llama(
            model_path=self._model_path,
            n_ctx=self._settings.context_tokens,
            n_gpu_layers=-1,
            verbose=False,
        )

    def chat(self, messages: list[dict[str, str]], **kwargs: Any) -> ModelResponse:
        self._load()
        from .ollama import NOX_SYSTEM_PROMPT

        full_messages = [{"role": "system", "content": NOX_SYSTEM_PROMPT}] + list(messages)
        result = self._llama.create_chat_completion(
            messages=full_messages,
            max_tokens=kwargs.get("max_tokens", 1600),
            temperature=kwargs.get("temperature", 0.4),
        )
        content = result["choices"][0]["message"]["content"].strip()
        return ModelResponse(content=content, model=os.path.basename(self._model_path), backend=self.name)

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        on_chunk: Callable[[str], None],
        **kwargs: Any,
    ) -> ModelResponse:
        self._load()
        from .ollama import NOX_SYSTEM_PROMPT

        full_messages = [{"role": "system", "content": NOX_SYSTEM_PROMPT}] + list(messages)
        parts: list[str] = []
        for chunk in self._llama.create_chat_completion(
            messages=full_messages,
            max_tokens=kwargs.get("max_tokens", 1600),
            temperature=kwargs.get("temperature", 0.4),
            stream=True,
        ):
            delta = chunk["choices"][0]["delta"].get("content", "")
            if delta:
                parts.append(delta)
                on_chunk(delta)
        content = "".join(parts).strip()
        return ModelResponse(content=content, model=os.path.basename(self._model_path), backend=self.name)

    def is_available(self) -> bool:
        try:
            import llama_cpp  # noqa: F401
            return os.path.exists(self._model_path)
        except ImportError:
            return False


def get_backend(settings: Any) -> ModelBackend:
    """Ortam değişkenine göre backend seçer.

    NOX_BACKEND=llama_cpp ise llama.cpp (kuruluysa), yoksa Ollama.
    """
    choice = os.getenv("NOX_BACKEND", "ollama").lower()
    if choice == "llama_cpp":
        backend = LlamaCppBackend(settings)
        if backend.is_available():
            return backend
    return OllamaBackend(settings)
"""Model backend soyutlaması: Ollama bugün, llama.cpp yarın.

Ollama bir iskeledir; NOX'un nihai model katmanı kendi çıkarım kodudur.
Bu modül her iki dünyayı birleştirir: aynı arayüz, değiştirilebilir backend.
"""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class ModelResponse:
    content: str
    model: str
    backend: str


class ModelBackend(ABC):
    """Tüm model backend'lerinin ortak arayüzü."""

    name: str

    @abstractmethod
    def chat(self, messages: list[dict[str, str]], **kwargs: Any) -> ModelResponse:
        """Sohbet tamamlama üretir."""

    @abstractmethod
    def stream_chat(
        self,
        messages: list[dict[str, str]],
        on_chunk: Callable[[str], None],
        **kwargs: Any,
    ) -> ModelResponse:
        """Parça parça sohbet üretir."""

    @abstractmethod
    def is_available(self) -> bool:
        """Backend çalışır durumda mı?"""


class OllamaBackend(ModelBackend):
    """Ollama API'si üzerinden (geçiş dönemi iskelesi)."""

    name = "ollama"

    def __init__(self, settings: Any) -> None:
        from .ollama import OllamaClient

        self._client = OllamaClient(settings)
        self._settings = settings

    def chat(self, messages: list[dict[str, str]], **kwargs: Any) -> ModelResponse:
        user_text = messages[-1]["content"] if messages else ""
        content = self._client.chat(user_text, history=messages[:-1] or None)
        return ModelResponse(content=content, model=self._settings.model, backend=self.name)

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        on_chunk: Callable[[str], None],
        **kwargs: Any,
    ) -> ModelResponse:
        user_text = messages[-1]["content"] if messages else ""
        content = self._client.stream_chat(user_text, history=messages[:-1] or None, on_chunk=on_chunk)
        return ModelResponse(content=content, model=self._settings.model, backend=self.name)

    def is_available(self) -> bool:
        try:
            self._client.chat("ping")
            return True
        except Exception:
            return False


class LlamaCppBackend(ModelBackend):
    """llama.cpp GGUF doğrudan (nihai hedef; L3'te Tauri/Rust içinde).

    Seed v0'da yer tutucu: llama-cpp-python bağımlılığı platform aşamasında
    değerlendirilir. Şu an 'is_available' False döner.
    """

    name = "llama_cpp"

    def __init__(self, settings: Any) -> None:
        self._settings = settings

    def chat(self, messages: list[dict[str, str]], **kwargs: Any) -> ModelResponse:
        raise NotImplementedError("llama.cpp backend'i L3'te kurulacak")

    def stream_chat(
        self,
        messages: list[dict[str, str]],
        on_chunk: Callable[[str], None],
        **kwargs: Any,
    ) -> ModelResponse:
        raise NotImplementedError("llama.cpp backend'i L3'te kurulacak")

    def is_available(self) -> bool:
        return False


def get_backend(settings: Any) -> ModelBackend:
    """Ortam değişkenine göre backend seçer.

    NOX_BACKEND=llama_cpp ise llama.cpp (kuruluysa), yoksa Ollama.
    """
    choice = os.getenv("NOX_BACKEND", "ollama").lower()
    if choice == "llama_cpp":
        backend = LlamaCppBackend(settings)
        if backend.is_available():
            return backend
        # llama.cpp hazır değilse Ollama'ya düş
    return OllamaBackend(settings)
# Nox — Güncel Durum

Son güncelleme: 13 Eylül 2026 (gece oturumu)

## Neredeyiz?

**L1 (PTBL Derinleştirme) TAMAMLANDI.** Foundation §2'nin vaatleri artık kodda,
testte ve canlı veride var. 42 test, hepsi yeşil. Sıradaki büyük katman: L2 (Project Core).

## Bu oturumda yapılanlar (12-13 Eylül)

### PTBL çekirdeği
- **Kalite kapısı:** evidence veya unknowns boşsa güven ≤ 0.4.
- **Güven kalibrasyonu:** canlı karne (12 Eylül) modelin her şeye 0.90+ güven
  verdiğini gösterdi. Mekanik tavanlar: 1 bilinmeyen → ≤ 0.7, 2+ → ≤ 0.85,
  muğlaklık sinyali → ≤ 0.75.
- **pattern_type enum genişledi:** topluluk, davranış.

### Üç aşamalı PTBL boru hattı (canlı çalışıyor)
- `assess` (fark et) → aday kayıt
- `understand <id> <metin>` (anla) → bağlam kartı: işlev hipotezleri, karşı
  örnekler, açık sorular. Açık soru varken güven ≤ 0.7.
- `internalize <id>` (içselleştir) → active/context-bound/archived/candidate
  ÖNERİSİ. Açık soru varken 'candidate' zorunlu (kural koddadır).
- `approve <id> <durum>` → yaşam döngüsü geçişi yalnızca kullanıcı onayıyla.
- Aşama çıktıları `pattern_stages` tablosunda; hiçbir aşama öncekinin üzerine yazmaz.
- 2. ve 3. aşamada satır formatı kullanılır (4B model uzun JSON üretemiyor);
  geçersiz çıktıda 1 retry + ham çıktı olay günlüğünde.

### Örüntü birleştirme (recurrence)
- Benzer gözlemler (kelime örtüşmesi ≥ 0.6, yalnızca candidate'lar) tek kayıtta
  toplanır: kanıt listesi büyür, 'recurrence' aşama kaydı düşülür, güven her
  tekrarda +0.05 (tavan 0.9).

### Puan haritası (8 eksen)
- `score <id>` → belirginlik, özgünlük, kanıt gücü, bağlam derinliği, zaman
  canlılığı, karakter rezonansı, işlevsel katkı, çelişki yoğunluğu.
- Tek birleşik skor ÜRETİLMEZ (Foundation §2).

### Test ve fikstür
- 15 vakalı genişletilmiş PTBL fikstürü.
- `test_ptbl_regression.py`: yasaklı kalıp (olumsuzlama duyarlı), boş unknowns,
  boş observation denetimi. Canlı mod: NOX_PTBL_LIVE=1.
- Toplam: 42 test.

### Temizlik
- Satürn logosu kaldırıldı (demo'da "◒" metin işareti).
- İkinci Nox kopyası karmaşası çözüldü; tek ana kopya:
  `C:\Users\Yağız Cem\Documents\Projects\Nox`

## Seed v0 yetenek sınırı (değişmedi)

Yerel sohbet (streaming + kuyruk + kısa mesaj bütçesi), SQLite olay/örüntü kaydı,
üç aşamalı PTBL + kalite kapısı + kalibrasyon + birleştirme + puan haritası.
Başka yetki yok: internet yok, dosya eylemi yok, proje yürütücüsü yok,
kalıcı kişisel hafıza çıkarımı yok.

## Bilinen sınırlar / açık işler

- Modelin güven üretimi kalibre değildir; kalibrasyon kod tarafındadır.
- `ozgunluk` ekseni model tarafından şişirilme eğiliminde (karne notu).
- Demo arayüzünde PTBL aşamaları (understand/internalize/score) henüz yok —
  yalnızca CLI. PTBL Laboratuvarı sekmesi hâlâ 1. aşama gösteriyor.
- `events.project_id` kolonu L2'yi bekliyor.

## Açık kararlar (kullanıcı bekleniyor)

1. **Nihai model katmanı** — Ollama'sız dünyada model nasıl çalışacak? L3 öncesi şart.
2. **Kişilik değerlendirme oturumu** — ptbl-personality-research.md'deki 4 soruluk
   demo sözleşme testi yapıldı mı?
3. **Yeni logo/kimlik** — platform aşamasına mı ertelendi?
4. **Eğitim müfredatı** — Foundation 2'deki "ödev listesi"; zamanı geldi mi?

## Sıradaki katman: L2 — Project Core

Proje sözleşmesi, yaşam döngüsü durum makinesi, varsayım defteri, kalıcı kontrol
noktaları, açıklanabilir öncelik kuyruğu (aç bırakmayan). İlk doğrulama senaryosu:
Stardew Valley rehberi sürerken acil Almanca kelime listesi. Ayrıntı: foundation.md §4.
Blueprint referansı: BLUEPRINTS.md Bölüm 1 (Work + Hizalanma).

## Yeni sohbette devam komutu

`C:\Users\Yağız Cem\Documents\Projects\Nox` projesine devam et. Önce `README.md`,
`docs/foundation.md`, `docs/current-state.md` (bu dosya), `docs/seed-v0.md` ve
`docs/roadmap.md`'yi oku. L1 tamamlandı; L2'ye (Project Core) başlanacak.
Test komutu: `$env:PYTHONPATH = "src"; python -m unittest discover -s tests`
(beklenen: 42 test, OK).
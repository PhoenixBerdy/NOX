BÖLÜM 1/2 — BLUEPRINTS.md'nin içini sil, bunu yapıştır, henüz kaydetme, BÖLÜM 2'yi bekle:

# NOX — BLUEPRINTS
Tüm katman blueprint'lerinin tek evi. Her blueprint durum etiketi taşır:
[TASARIM] · [İNŞADA] · [TAMAMLANDI] · [ARŞİV]

---

# BÖLÜM 1 — WORK MODELİ + HİZALANMA [TASARIM]
**Tarih:** 13 Eylül 2026 · **Kaynak:** foundation.md §4 + newideasforme.txt manifestosu

> Tasarım belgesidir; buradaki bileşenler henüz kodda yok. L2'nin inşa planıdır.

## 1. Work modeli nedir

Nox'un sohbet penceresinden çıkıp üreten bir ortak olmasıdır: kullanıcı proje verir,
Nox sözleşme yayımlar, arka planda çalışır, kullanıcı bu sırada konuşmaya devam eder,
çıktı kontrol noktalarıyla ve doğrulanmış biçimde teslim edilir. "İki ayrı zeka mı?"
sorusunun cevabı: hayır — tek kimlik, üç iş hattı.

## 2. Üretim kapsamı (aşamalı)

| Seviye | Yetenek | İlk doğrulama |
|---|---|---|
| W1 | Metin/belge üretimi (rehber, liste, plan) | Almanca kelime listesi |
| W2 | Kod üretimi (tek dosyalık web oyunu) | Cookie-clicker prototipi |
| W3 | Çok dosyalı proje (kod + asset manifesti) | Cookie-clicker tam sürüm |
| W4 | Belge üretimi (PDF, tablo) | Stardew rehberi (PDF) |
| W5 | Medya (görsel/ses/video) | platform aşamasında araştırılır |

W5, 4B yerel modelin kapsamı dışında; vaat edilmez. W1-W3 bu donanımda çalışır.

## 3. Yetki haritası (4 seviye)

- **YEŞİL (A):** sessiz, kayıtlı otonomi. Teknoloji seçimi, dosya yapısı, iç mimari.
  Varsayım defterine yazılır, bildirim yok.
- **LİME (A½):** sessiz otonomi + sorgulanabilir gerekçe. Kullanıcıya dokunan teknik
  kararlar (kayıt biçimi, performans hedefi, varsayılanlar). Nox karar verir,
  gerekçeyi kaydeder; sorulursa açıklar.
- **SARI (B):** seçenek sunar, varsayılanla ilerler. Yaratıcı/yön kararları (oyun
  mekaniği, görsel stil). 2-3 seçenek + işaretli varsayılan; cevap yoksa varsayılan.
- **KIRMIZI (C):** her zaman sorar. Geri dönüşü olmayan/dış etkili işler: yayınlama,
  hesap/ödeme, dış servis, büyük dosya üzerine yazma.

Her karar; seviye, gerekçe, güven, alternatif ile varsayım defterine yazılır.

## 4. Proje yaşam döngüsü

taslak → sözleşme yayımlandı → sırada → çalışıyor → doğrulanıyor → tamamlandı
(duraklatıldı / yeniden planlanıyor / kullanıcı girdisi bekliyor / engellendi / iptal)

Her durum değişimi; neden, zaman, kaynak, dosyalar ve ara çıktıyla kaydedilir.
Nox kapansa bile proje kayıttan devam eder.

**Sözleşme içeriği:** hedeflenen çıktı, başarı ölçütü, kapsam ve kapsam dışı,
teknoloji yaklaşımı, varsayımlar + güven, kilometre taşları, kaynak bütçesi,
hangi koşulda kullanıcıyı bekleyeceği.

## 5. Üç akış mimarisi

1. **Canlı sohbet:** kullanıcı mesajı her zaman öncelikli.
2. **Proje:** iş küçük kontrol noktalarına bölünür; her noktada gelen kutu denetlenir.
3. **Sistem:** kuyruk, kaynak bütçesi, kayıt, güvenlik kapısı, bildirim — modelin
   keyfî yorumuna bırakılmaz.

Fiziksel sınır: qwen3:4b + 4 GB VRAM'de tek üretim hattı. Eşzamanlılık mantıksaldır;
5-6 proje açık kalabilir, hat kısa dilimlerle paylaşılır.

## 6. Öncelik kuyruğu (aç bırakmayan)

Sinyaller: kullanıcı aciliyeti (baskın), son tarih, bekletme maliyeti, değer,
tamamlanmaya yakınlık, bağımlılık hazırlığı, tahmini süre/kaynak, bekleme süresi
(arttıkça öncelik artar). Nox gerekçeyi görünür kılar; kullanıcı sırayı değiştirebilir.

İlk doğrulama: Stardew rehberi sürerken acil Almanca kelime listesi öne alınır,
rehber kayıpsız duraklatılır ve devam eder.

## 7. Hizalanma döngüsü (4 katman)

1. **Sözleşme hizası:** ara çıktı her kontrol noktasında başarı ölçütüyle karşılaştırılır.
2. **PTBL hizası:** kalite kapısı + regresyon denetimi (L1'den).
3. **Beklenti↔sonuç öz-yansıması:** her adımda tahmin yazılır, sonuçla karşılaştırılır;
   yanılma PTBL verisidir.
4. **Kullanıcı düzeltme metriği:** düzeltme sayısı/türü zamanla ölçülür; ana başarı
   ölçütü düzeltme ihtiyacının azalmasıdır. (Kullanıcı onayı: başka ölçüt yok.)

## 8. Güvenlik kapısı bağlantısı

- Üretim yalnızca izole proje klasörüne: `data/projects/<proje_id>/`
- Klasör dışına yazma SARI; silme/üzerine yazma KIRMIZI; dışa veri gönderme KIRMIZI.
- Güvenlik katmanı kişilikten her zaman üstündür (karşılıklı onaylı kırmızı çizgi).
- Red-line içeriği en son kullanıcıyla birlikte yazılacak.

## 9. PTBL entegrasyonu ("PTBL manyağı" ilkesi)

Çift yönlü beslenme: proje araştırmasındaki öğretim/anlatım örüntüleri PTBL adayı olur;
kullanıcı geri bildirimi PTBL kaydıdır; çıktı üslubu kullanıcı ritmine uyar.

## 10. L2 inşa sırası

1. `projects` tablosu + yaşam döngüsü (events.project_id kancası hazır)
2. `assumptions` tablosu (varsayım defteri)
3. Sözleşme üretici + CLI: project new / status / list
4. Kontrol noktası yürütücüsü (tek hatlı, kısa dilimler)
5. Öncelik kuyruğu + kullanıcı geçersiz kılma
6. İzole proje klasörü + güvenlik kapısı ilk sürümü
7. Hizalanma döngüsü: sözleşme doğrulama + beklenti/sonuç kaydı
8. W1 doğrulaması: Almanca kelime listesi (uçtan uca)
9. W2 doğrulaması: cookie-clicker prototipi

Her adım kendi testleriyle gelir; mevcut 42 test bozulmadan büyür.

## 11. Açık bırakılanlar

- W5 (medya): platform aşamasında araştırılacak; vaat yok.
- Gerçek paralellik: ölçüm sonrası.
- Demo arayüzüne proje görünürlüğü: L2 sonrası (Proje Masası demosu).
- Evrim blueprint'i: Bölüm 2'de.

# BÖLÜM 2 — EVRİM [TASARIM]
**Tarih:** 13 Eylül 2026 · **Kaynak:** newideasforme.txt manifestosu + kullanıcı onayları

> En büyük ve en tehlikeli fikir. Bu blueprint, evrimi güvenli bir boru hattına
> kapatır: hazırlık otonom, uygulama onaylı. Kullanıcının iki koşulu işlendi:
> (1) birleşik pasiflik ölçütü, (2) üç katmanlı öz-kod yetkisi.

## 1. Evrim nedir (manifestodan)

Nox'un kendine sürekli yetenek katma dürtüsü: yeni bir yeteneği (ör. sesli konuşma)
başka ajanlarda görür, PTBL ile ölçer/tartar, mantıklıysa kodunu yazmayı dener;
mantıksızsa askıya alır, arşivler veya çöpe atar. Entropi gibi sürekli çalışan bir
süreç — ama bu blueprint'te dürtü değil, **disiplinli boru hattı** olarak tasarlanır.

## 2. Evrim boru hattı (5 aşama)

```text
gözlem → aday fikir → değerlendirme → prototip (izole) → karar
                                                      ├─ kabul önerisi (kullanıcı onayı)
                                                      ├─ askıya alma
                                                      ├─ arşivleme
                                                      └─ çöpe atma
Gözlem: internet/medya/proje sırasında yetenek sinyali yakalanır
("diğer ajanların ses modeli var").
Aday fikir: PTBL ile ölçülür — kaynak, özgünlük, Nox kimliğiyle uyum,
kaynak maliyeti, risk.
Değerlendirme: başarı ölçütü yazılır; mevcut yeteneklerle çakışma,
güvenlik sınıfı ve donanım uygunluğu denetlenir.
Prototip: izole ortamda kod yazılır ve test edilir (ana koda DOKUNULMAZ).
Karar: rapor kullanıcıya sunulur. Kabul ancak kullanıcı onayıyla.
3. Otonomi sınırları (kullanıcı onaylı model)
Hazırlık otonom: kod arama, okuma, analiz, aday üretme, izole test, rapor
yazma — bunlar onay beklemez ve sisteme dokunmaz.
Uygulama onaylı: ana koda/kuruluma hiçbir değişiklik kullanıcı onayı olmadan
yapılmaz. Gece senaryosu güvenli: Nox 10 saat çalışır, sen "3 aday hazır, 2'si
test geçti, 1'i askıda" raporu görürsün.
Üç katmanlı öz-kod yetkisi: (a) okuma/analiz otonom, (b) izole kopyada varyant
deneme otonom, (c) ana koda uygulama her zaman kullanıcı onayı + geri dönüş noktası.
4. Fikir reseptörleri (tekrar tanıma)
Aynı fikir iki kez geldiğinde ölçme mekanizmasına girmez; tanınır. Bu, PTBL
recurrence'ın fikir versiyonudur: aday fikirler benzerlik kaydıyla tutulur
(evolution_ideas tablosu), yeni fikir mevcutlarla karşılaştırılır; yüksek
benzerlikte "daha önce değerlendirildi" notu düşülür. Antikor değil, reseptör.

5. Enerji bütçesi ve pasiflik ölçütü (kullanıcı koşulu)
Evrim yalnızca birleşik pasiflik sağlandığında devreye girer — dört sinyal birden:

Girdi pasifliği: 10+ dakika klavye/fare yok
Ses pasifliği: sistemde ses çıkışı yok (film/müzik/oyun sesi varsa pasif değil)
Odak pasifliği: tam ekran uygulama yok veya ekran kilitli/monitör kapalı
Nox pasifliği: açık sohbet/proje mesajı gelmemiş
Herhangi biri bozulursa 1 kontrol noktası içinde duraklar. Kaynak sınırı: tek
model hattının %50'si + sıcaklık/fan eşiği (laptop). Kullanıcı film izlerken evrim
uyur; kullanıcı yatınca çalışır.

6. Yaşam döngüsü kararları
Kabul önerisi: test geçti + başarı ölçütü karşılandı + kullanıcı onayı bekliyor.
Askıya alma: mantıklı ama öncelik düşük; neden ve yeniden açma koşulu kayıtlı.
Arşivleme: değerli ama şimdi değil; ör. donanım yetmezliği.
Çöpe atma: aşırı mantıksız veya red-line çakışması; nedeni kayıtlı, geri
alınabilir (çöp değil, silme değil).
7. PTBL ile ilişki
Evrim, PTBL'nin üstünde çalışır ama PTBL'yi de şekillendirebilir: Nox kendi kodunu
okuyup PTBL boru hattında iyileştirme önerebilir (üç katman yetki kuralıyla).
Fikir değerlendirmesi PTBL puan haritasının 8 eksenini kullanır.

8. İnşa sırası (L8'e kadar kod yok)
evolution_ideas tablosu + reseptör benzerlik kaydı
Pasiflik ölçütü servisi (4 sinyal)
Aday değerlendirme prompt'u (satır formatı, PTBL usulü)
İzole prototip ortamı (kopya klasör + test koşucu)
Kullanıcı rapor ekranı (aday listesi + karar düğmeleri)
Evrim, L8 katmanıdır; L2-L4 olmadan inşa edilmez. Bu blueprint tasarımı mühürler.

BÖLÜM 3 — PLATFORM [ERTELENDİ]
Kullanıcı kararı: her şey tasarlandıktan sonra. Referans araştırması o aşamada.


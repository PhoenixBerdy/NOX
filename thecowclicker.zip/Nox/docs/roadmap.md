# \# Nox Yol Haritası

# 

# Katman haritası (L0-L9) ile ilk aşamaların birleşik görünümü. Her katmanın

# ayrıntısı `BLUEPRINTS.md` ve `foundation.md` içindedir; bu dosya yalnızca

# sıra ve durum gösterir.

# 

# \## 0. Temel tasarım — TAMAMLANDI

# 

# Karakter çekirdeği, PTBL sosyal algısı, zaman damgası, puan haritası, öz-yansıma

# ve özgün düşünce ilkeleri oluşturuldu. Ana belge: `foundation.md`.

# 

# \## 1. Nox Seed v0 — TAMAMLANDI

# 

# Yerel bilgisayarda çalışan küçük Nox çekirdeği: konuşma, olay kaydı, PTBL

# değerlendirme akışı. Teknik kılavuz: `seed-v0.md`.

# 

# \## 2. L1 — PTBL Derinleştirme — TAMAMLANDI (13 Eylül 2026)

# 

# Kalite kapısı, güven kalibrasyonu, 15 vakalı regresyon fikstürü, üç aşamalı

# boru hattı (fark et → anla → içselleştir), örüntü birleştirme, 8 eksenli puan

# haritası. 42 test yeşil. İlk canlı üç aşamalı yürüyüş ve canlı puan kartı alındı.

# 

# \## 3. L2 — Project Core — AKTİF

# 

# Proje sözleşmesi, yaşam döngüsü, varsayım defteri, kontrol noktaları, aç

# bırakmayan öncelik kuyruğu, hizalanma döngüsü, izole proje klasörü + güvenlik

# kapısı ilk sürümü. Ayrıntı: `BLUEPRINTS.md` Bölüm 1 (Work + Hizalanma).

# İlk doğrulama: W1 Almanca kelime listesi, W2 cookie-clicker prototipi.

# 

# \## 4. L3 — Platform

# 

# Bağımsız, minimal, modern, koyu masaüstü uygulaması; akışlı yanıt doğal davranış.

# Platform aşamasında çağdaş ajan arayüzleri için deep research (kullanıcı talimatı).

# Nihai model katmanı kararı bu katmandan önce netleşir (açık karar).

# 

# \## 5. L4 — Araçlar ve güvenlik kapısı

# 

# İzole klasörde kod/dosya üretimi; red/gray/yellow/green davranış sınıfları çalışır.

# Red-line paketi EN SON, kullanıcıyla birlikte yazılır.

# 

# \## 6. L5 — İnternet ve medya gözlemi

# 

# Kaynak değerlendirmesi; PTBL internet örüntülerine açılır.

# 

# \## 7. L6 — Hafıza ve bilgisayar yetenekleri

# 

# Kalıcı kişisel hafıza (aday → değerlendirme → kabul/askı), dosyalar, notlar, takvim.

# 

# \## 8. L7 — Çoklu cihaz

# 

# Ana düğüm + yetkili istemciler; tek kanonik kimlik. Ayrıntı: `platform-target.md`.

# 

# \## 9. L8 — Optimizasyon, evrim, Treats

# 

# Ölçüm temelli iyileştirme; yetenek yaşam döngüsü; açıklanabilir sinyal kayıtları.

# Öz-değişiklik yalnızca insan onayı + ayrı test ortamı + geri dönüş planıyla.

# Evrim blueprint'i: `BLUEPRINTS.md` Bölüm 2 (yazılacak).

# 

# \## 10. L9 — Final

# 

# Kullanıcıya bildirim + taşınabilir paket (uygulama + model kurulumu + şifreli

# veri aktarımı + geri yükleme doğrulaması + yetki politikası). Kullanıcının

# bilgisayar sıfırlama planıyla hizalı.


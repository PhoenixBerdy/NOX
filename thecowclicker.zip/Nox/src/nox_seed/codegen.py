"""Kod üretimi adımı: model dosya içeriği üretir, izole klasöre yazılır.

Work modeli W2'nin karşılığı. Kurallar:
- Model yalnızca dosya içeriği üretir; açıklama, sohbet, markdown yazmaz.
- Çıktı güvenlik kapısından geçer: yalnızca data/projects/<proje_id>/ altına,
  yalnızca izinli uzantılarla yazılır. Klasör dışı yazım reddedilir.
"""
from __future__ import annotations

from pathlib import Path

ALLOWED_EXTENSIONS = {".html", ".css", ".js", ".md", ".txt", ".json"}

CODE_SYSTEM_PROMPT = """Bir kod üretim motorusun. Sana proje sözleşmesi ve istenen dosya verilecek.
Yalnızca istenen dosyanın içeriğini üret. Açıklama, sohbet metni, markdown çitleri
(```), "işte kod" gibi çerçeve yazma. Çıktı doğrudan dosyaya yazılacak.

Kurallar:
- Tek dosya üret; başka dosyaya referans verme.
- HTML ise CSS ve JS'i aynı dosyada göm (inline).
- Koyu tema, modern, minimal görünüm.
- Çalışır durumda olsun; tarayıcıda açıldığında hata vermemeli.
- HTML dosyalarında <head> içinde <meta charset="utf-8"> her zaman olsun."""


def sanitize_filename(name: str) -> str:
    """Dosya adını güvenli hâle getirir; klasör kaçışını engeller."""
    cleaned = name.replace("\\", "/").split("/")[-1]
    return "".join(c for c in cleaned if c.isalnum() or c in "._-")


def validate_output_path(projects_root: Path, project_id: int, filename: str) -> Path:
    """Güvenlik kapısı: yalnızca izole klasör, yalnızca izinli uzantı."""
    safe = sanitize_filename(filename)
    ext = Path(safe).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"İzinli olmayan dosya uzantısı: {ext}")
    project_dir = projects_root / str(project_id)
    project_dir.mkdir(parents=True, exist_ok=True)
    target = (project_dir / safe).resolve()
    if not str(target).startswith(str(project_dir.resolve())):
        raise ValueError("Klasör dışına yazım reddedildi.")
    return target


def build_code_prompt(contract: dict, filename: str, instruction: str) -> list[dict[str, str]]:
    import json

    user = json.dumps(
        {
            "sozlesme": contract,
            "dosya": filename,
            "ek_talimat": instruction,
        },
        ensure_ascii=False,
    )
    return [
        {"role": "system", "content": CODE_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]


def strip_code_fences(text: str) -> str:
    """Model markdown çiti eklerse temizler."""
    cleaned = text.strip()
    if cleaned.startswith("```"):
        first_newline = cleaned.find("\n")
        if first_newline > 0:
            cleaned = cleaned[first_newline + 1:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
    return cleaned.strip()
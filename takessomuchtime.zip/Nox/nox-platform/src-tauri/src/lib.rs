use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Serialize, Deserialize)]
struct Project {
    id: i64,
    status: String,
    title: String,
    created_at: String,
}

#[tauri::command]
fn list_projects(db_path: String) -> Result<Vec<Project>, String> {
    let conn = Connection::open(db_path).map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT id, status, contract_json, created_at FROM projects ORDER BY id DESC LIMIT 20")
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![], |row| {
            let contract: String = row.get(2)?;
            let title = serde_json::from_str::<serde_json::Value>(&contract)
                .ok()
                .and_then(|v| v["title"].as_str().map(|s| s.to_string()))
                .unwrap_or_else(|| "(başlıksız)".to_string());
            Ok(Project {
                id: row.get(0)?,
                status: row.get(1)?,
                title,
                created_at: row.get(3)?,
            })
        })
        .map_err(|e| e.to_string())?;
    let mut projects = Vec::new();
    for p in rows {
        projects.push(p.map_err(|e| e.to_string())?);
    }
    Ok(projects)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![list_projects])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
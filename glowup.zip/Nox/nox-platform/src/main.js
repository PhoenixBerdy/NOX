// Nox platform köprüsü: Tauri frontend ↔ NOX localhost sunucusu
const OLLAMA_URL = "http://127.0.0.1:8000";

const stream = document.getElementById("message-stream");
const input = document.getElementById("input");
const sendBtn = document.getElementById("send");
const statusDot = document.getElementById("statusDot");

const NAV = { chat: document.getElementById("chat-view"), projects: document.getElementById("projects-view") };
document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    Object.values(NAV).forEach(v => v.classList.remove("active"));
    NAV[tab].classList.add("active");
    if (tab === "projects") loadProjects();
  });
});

function addMessage(role, text) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.textContent = text;
  stream.appendChild(div);
  stream.scrollTop = stream.scrollHeight;
  return div;
}

function setStatus(color, title) {
  statusDot.style.background = color;
  statusDot.title = title;
}

async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  sendBtn.disabled = true;
  addMessage("user", text);
  const noxDiv = addMessage("nox", "");
  setStatus("var(--lime)", "Yazıyor...");

  const payload = {
    messages: [
      { role: "system", content: "Sen Nox'sun: yerel, dikkatli, kanıt odaklı, sıcak ama yaltaklanmayan bir ortak. Türkçe yanıt ver." },
      { role: "user", content: text },
    ],
  };

  try {
    const response = await fetch(`${OLLAMA_URL}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const content = data.message?.content || "";
    noxDiv.textContent = content;
    setStatus("var(--ok)", `Hazır (${data.backend})`);
  } catch (err) {
    noxDiv.textContent = `Hata: ${err.message}. NOX sunucusu çalışıyor mu?`;
    setStatus("var(--err)", "Hata");
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
}

function statusIcon(status) {
  const map = { tamamlandi: "●", calisiyor: "◐", sozlesme: "▲", taslak: "○", iptal: "■", sirada: "▲" };
  return map[status] || "○";
}

async function loadProjects() {
  const list = document.getElementById("projects-list");
  list.innerHTML = '<div class="message system">Projeler yükleniyor...</div>';
  const dbPath = "C:\\Users\\Yağız Cem\\Documents\\Projects\\Nox\\data\\nox_seed.sqlite3";
  try {
    const projects = await window.__TAURI__.core.invoke("list_projects", { dbPath });
    if (!projects.length) {
      list.innerHTML = '<div class="message system">Henüz proje yok.</div>';
      return;
    }
    list.innerHTML = projects.map(p => `
      <div class="project-card" data-id="${p.id}" style="cursor:pointer">
        <div class="project-status">${statusIcon(p.status)} ${p.status}</div>
        <div>#${p.id} ${p.title}</div>
      </div>`).join("");
    list.querySelectorAll(".project-card").forEach(card => {
      card.addEventListener("click", () => openProjectDetail(card.dataset.id));
    });
  } catch (err) {
    list.innerHTML = `<div class="message system">Hata: ${err}</div>`;
  }
}

async function openProjectDetail(id) {
  let panel = document.getElementById("detail-panel");
  if (!panel) {
    panel = document.createElement("aside");
    panel.id = "detail-panel";
    document.getElementById("app").appendChild(panel);
  }
  panel.innerHTML = '<div class="message system">Yükleniyor...</div>';
  const dbPath = "C:\\Users\\Yağız Cem\\Documents\\Projects\\Nox\\data\\nox_seed.sqlite3";
  try {
    const detail = await window.__TAURI__.core.invoke("project_detail", { dbPath, projectId: parseInt(id) });
    const c = detail.contract || {};
    panel.innerHTML = `
      <div class="detail-header">
        <button id="close-panel">×</button>
        <h3>Proje #${id}</h3>
      </div>
      <div class="detail-body">
        <p><strong>${c.title || "(başlıksız)"}</strong></p>
        <p><small>Hedef: ${c.goal || "—"}</small></p>
        <p><small>Kapsam: ${c.scope || "—"}</small></p>
        <p><small>Yaklaşım: ${c.approach || "—"}</small></p>
        <h4>Dosyalar</h4>
        ${detail.files.length ? detail.files.map(f => `<div class="file-item">📄 ${f}</div>`).join("") : "<p><em>Dosya yok</em></p>"}
      </div>`;
  } catch (err) {
    panel.innerHTML = `<div class="message system">Hata: ${err}</div>`;
  }
  document.getElementById("close-panel").addEventListener("click", () => panel.remove());
}

sendBtn.addEventListener("click", sendMessage);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.ctrlKey) sendMessage();
});
input.focus();
addMessage("system", "Nox platformu hazır. NOX sunucusunun çalıştığından emin ol.");
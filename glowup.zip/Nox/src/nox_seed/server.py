"""NOX localhost sunucusu: Tauri frontend'i backend'e bağlar.

Saf Python (http.server) — bağımlılık yok. Tauri frontend Ollama API'si yerine
bu sunucuya gider; o da get_backend üzerinden Ollama veya llama.cpp'ye yönlendirir.

Kullanım: python -m nox_seed serve [--port 8000]
"""
from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

from .backend import get_backend
from .config import Settings
from .database import Database

_settings: Settings | None = None
_database: Database | None = None


def _json_response(handler: BaseHTTPRequestHandler, status: int, data: dict[str, Any]) -> None:
    body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()
    handler.wfile.write(body)


class NoxHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        pass  # sessiz çalış

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self) -> None:
        if self.path == "/health":
            _json_response(self, 200, {"status": "ok", "backend": "nox"})
        else:
            _json_response(self, 404, {"error": "bulunamadı"})

    def do_POST(self) -> None:
        if self.path != "/chat":
            _json_response(self, 404, {"error": "bulunamadı"})
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length).decode("utf-8"))
            messages = body.get("messages", [])
            if not messages:
                _json_response(self, 400, {"error": "messages boş"})
                return
            backend = get_backend(_settings)
            response = backend.chat(messages)
            _json_response(self, 200, {
                "message": {"role": "assistant", "content": response.content},
                "backend": response.backend,
                "model": response.model,
            })
        except Exception as exc:  # noqa: BLE001
            _json_response(self, 500, {"error": str(exc)})


def run_server(port: int = 8000) -> None:
    global _settings, _database
    _settings = Settings.from_environment()
    _database = Database(_settings.database_path)
    _database.initialize()
    server = HTTPServer(("127.0.0.1", port), NoxHandler)
    print(f"NOX sunucusu hazır: http://127.0.0.1:{port}")
    print(f"Backend: {type(get_backend(_settings)).__name__}")
    server.serve_forever()
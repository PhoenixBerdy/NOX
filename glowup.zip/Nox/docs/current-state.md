# Nox — Güncel Durum

Son güncelleme: 13 Eylül 2026 (gece oturumu)

## Neredeyiz?

**L2 (Project Core) TAMAMLANDI.** Work modeli üretimde: 4 proje, 1 oyun, hizalanma
canlı, Proje Masası zengin. **Ollama'sız NOX tam çalışıyor** — llama.cpp GGUF,
kendi sunucusu (localhost:8000), Tauri platformu bağlantısı.

## Bu oturumda yapılanlar (13 Eylül gecesi)

### Ollama'sız platform (tamamlandı)
- **Backend soyutlaması:** `ModelBackend` arayüzü + `OllamaBackend` + `LlamaCppBackend`
- **llama.cpp GGUF:** Qwen3-4B-Instruct-2507 (think kapalı, kimlik doğru)
- **NOX localhost sunucusu:** `python -m nox_seed serve` → `http://127.0.0.1:8000`
  (saf Python, bağımlılık yok, `get_backend` yönlendirmesi)
- **Tauri platform bağlantısı:** frontend Ollama API'si yerine NOX sunucusuna gider
- **Kanıt:** Ollama kapalıyken sohbet, proje listesi, detay paneli çalışıyor

### L2 kodu (tamamlandı)
- Project Core: projects, transitions, assumptions tabloları
- CLI: `project new / list / status / advance / step / code / reflect / validate / pdf / serve`
- Model destekli sözleşme, kontrol noktası yürütücüsü, kod üretimi + güvenlik kapısı
- Hizalanma döngüsü (canlı öz-yansıma), Proje Masası (demo'da zengin)
- 95 test yeşil

### Platform alfa (Tauri)
- Sol ray + merkez sohbet + sağ kayar panel (Claude.ai artifact paneli ilkesi)
- Streaming sohbet, SQLite köprüsü (Rust backend), proje detayları

## Bilinen sınırlar / açık işler

- "Sen Nox" cümle yapısı (sistem promptu ince ayarı gerekir)
- Tauri alfa: markdown yok, kod bloğu yok, Proje Masası basit
- PDF Türkçe font: platform aşamasında
- Model dosyası: `models/Qwen3-4B-Instruct-2507-Q4_K_M.gguf` (2.5 GB, zip'e katma)

## Açık kararlar (kullanıcı bekleniyor)

1. **Üretim geçişi:** llama.cpp varsayılan backend yapılsın mı? (Şu an NOX_BACKEND=llama_cpp gerekli)
2. **Kişilik değerlendirme oturumu:** 4 soruluk demo sözleşme testi yapıldı mı?
3. **Yeni logo/kimlik:** platform aşamasına mı ertelendi?
4. **Eğitim müfredatı:** zamanı geldi mi?

## Sıradaki katman: L3 — Platform zenginleştirme

- Tauri platformunu zenginleştir: markdown, kod bloğu, Proje Masası tam veri
- Model katmanını üretime taşı: llama.cpp varsayılan backend
- W5 (medya) ön araştırması

## Yeni sohbette devam komutu

`C:\Users\Yağız Cem\Documents\Projects\Nox` projesine devam et. Önce `README.md`,
`docs/foundation.md`, `docs/current-state.md` (bu dosya), `docs/seed-v0.md` ve
`docs/roadmap.md`'yi oku. L2 tamamlandı; L3 platform zenginleştirme sürüyor.
Ollama'sız çalışma: `$env:NOX_BACKEND = "llama_cpp"; python -m nox_seed serve`.
Test komutu: `$env:PYTHONPATH = "src"; python -m unittest discover -s tests`
(beklenen: 95 test, OK).
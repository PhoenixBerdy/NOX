// game.js
document.addEventListener('DOMContentLoaded', () => {
    const cowElement = document.getElementById('cow');
    const scoreElement = document.getElementById('score');
    const gameContainer = document.getElementById('game-container');

    let score = 0;
    let isClicked = false;

    // İneği tıklayınca olay işleyici
    cowElement.addEventListener('click', () => {
        if (!isClicked) {
            score++;
            scoreElement.textContent = `Skor: ${score}`;
            isClicked = true;
            cowElement.style.transform = 'scale(1.1)';
            cowElement.style.transition = 'transform 0.2s ease';

            setTimeout(() => {
                cowElement.style.transform = 'scale(1)';
            }, 200);

            // 1.5 saniye sonra tekrar normal olur
            setTimeout(() => {
                isClicked = false;
            }, 1500);
        }
    });

    // Oyunu başlat
    gameContainer.style.display = 'flex';
    gameContainer.style.justifyContent = 'center';
    gameContainer.style.alignItems = 'center';
    gameContainer.style.height = '100vh';
    gameContainer.style.backgroundColor = '#0f0f1a';
    gameContainer.style.fontFamily = 'Arial, sans-serif';
    gameContainer.style.color = '#ffffff';
});
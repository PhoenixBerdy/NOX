# İneğe Tıkla! Oyunu

## Özet
Bu proje, kullanıcıya koyu tema ile modern bir "İneğe Tıkla!" oyunu sunar. Oyun, basit bir HTML, CSS ve JavaScript ile oluşturulmuş bir web uygulamasıdır. Kullanıcı, ekranın ortasında yer alan ineğe üzerine tıklayarak oyunu oynar. Oyun, kullanıcıya hemen hemen anında geri bildirim verir ve kullanıcıya başarılı bir tıklama deneyimi sunar.

## Özellikler
- Koyu tema ile modern ve minimal görünüm.
- Mobil uyumlu tasarım.
- Gerçek zamanlı tepki (tıklama sonrası mesaj).
- Tarayıcıda doğrudan çalışır (server gerekmez).

## Kullanım
Oyunu tarayıcıda açmak için `index.html` dosyasını doğrudan açın. Oyun, herhangi bir internet bağlantısı olmadan çalışır.

## Geliştirme Süreci
1. **Sözleşme** – Proje hedefleri ve kapsam belirlendi.
2. **Araştırma** – HTML, CSS ve JavaScript ile basit oyun yapıları araştırıldı.
3. **Uygulama** – Oyun bileşenleri geliştirildi ve birleştirildi.
4. **Doğrulama** – Oyun, tüm cihazlarda ve tarayıcılarda çalışır şekilde test edildi.

## Dosyalar
- `index.html` – Oyunun ana sayfası.
- `style.css` – Oyunun görsel tarzı ve stilini belirler.
- `game.js` – Oyunun işlevsel kısmı (tıklama kontrolü ve mesaj).
- `README.md` – Bu dosya.

## Dikkat Edilmesi Gerekenler
- Oyun, dış API'ler veya sunucu tarafı içermez.
- Oyun, kullanıcıya sadece bir tıklama ile tepki verir.
- Oyun, tüm cihazlarda ve tarayıcılarda çalışır.

## Geliştirme Yöntemi
- Basit ve doğrudan bir yaklaşım: HTML, CSS ve JavaScript ile oyunu oluştur.
- Minimal ve kullanıcı odaklı tasarım.
- Hata yönetimi yok (basit bir oyun için yeterli).

## Gelecek Aşamalar
- Oyunun bir sonraki sürümünde, skor sistemi, zaman ölçümü veya farklı hayvanlar eklenebilir.
- Oyunun mobil uygulama olarak da dönüştürülebilir.

> 🐄 "İneğe tıkla, başarıyla oynandı!"
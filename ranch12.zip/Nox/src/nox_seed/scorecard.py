"""PTBL puan haritası: örüntüler tek skorla değil, 8 eksende değerlendirilir.

Foundation bölüm 2: "Nox, örüntüleri iyi/kötü biçiminde tek puanla yargılamaz."

Kurallar:
- Her eksen 0.0 - 1.0 arası; modelden aday gelir, kalibrasyondan geçer.
- Tek birleşik skor ÜRETİLMEZ; eksenler ayrı kaydedilir.
- Çıktı 'score' aşaması olarak pattern_stages'a yazılır; üzerine yazılmaz.
- Kanıt listesi boşsa kanit_gucu kalite kapısıyla uyumlu olarak <= 0.4.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .models import PatternAssessment

AXES: tuple[str, ...] = (
    "belirginlik",
    "ozgunluk",
    "kanit_gucu",
    "baglam_derinligi",
    "zaman_canliligi",
    "karakter_rezonansi",
    "islevsel_katki",
    "celiski_yogunlugu",
)

SCORE_SYSTEM_PROMPT = """Bir PTBL puan haritası yardımcısısın. Sana bir örüntü adayı verilecek.
Örüntüyü 8 eksende 0.0 ile 1.0 arasında puanla. Tek birleşik skor verme.
Kanıt zayıfsa kanit_gucu düşük olmalı; emin olamadığın eksende 0.5'i geçme.

Yanıtını SADECE şu 8 satırda ver; başka hiçbir şey yazma, JSON yazma:

BELIRGINLIK: <sayı>
OZGUNLUK: <sayı>
KANIT_GUCU: <sayı>
BAGLAM_DERINLIGI: <sayı>
ZAMAN_CANLILIGI: <sayı>
KARAKTER_REZONANSI: <sayı>
ISLEVSEL_KATKI: <sayı>
CELISKI_YOGUNLUGU: <sayı>"""

_TAG_TO_AXIS = {
    "BELIRGINLIK": "belirginlik",
    "OZGUNLUK": "ozgunluk",
    "KANIT_GUCU": "kanit_gucu",
    "BAGLAM_DERINLIGI": "baglam_derinligi",
    "ZAMAN_CANLILIGI": "zaman_canliligi",
    "KARAKTER_REZONANSI": "karakter_rezonansi",
    "ISLEVSEL_KATKI": "islevsel_katki",
    "CELISKI_YOGUNLUGU": "celiski_yogunlugu",
}


@dataclass(frozen=True)
class ScoreCard:
    """Bir örüntünün 8 eksenli puan haritası."""

    scores: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {"axes": dict(self.scores)}


def parse_score_card(model_output: str, assessment: PatternAssessment) -> ScoreCard:
    """8 etiketli satırı savunmacı biçimde ayrıştırır."""
    scores: dict[str, float] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag, axis in _TAG_TO_AXIS.items():
            if line.startswith(tag + ":"):
                raw = line.split(":", 1)[1].strip()
                try:
                    value = float(raw)
                except ValueError:
                    value = 0.0
                scores[axis] = max(0.0, min(1.0, value))
                break
    for axis in AXES:
        scores.setdefault(axis, 0.5)
    if not assessment.evidence:
        scores["kanit_gucu"] = min(scores["kanit_gucu"], 0.4)
    return ScoreCard(scores=scores)


def build_score_prompt(assessment: PatternAssessment) -> list[dict[str, str]]:
    """Puan haritası için model mesajlarını kurar."""
    import json

    user = json.dumps({"aday_oruntu": assessment.as_dict()}, ensure_ascii=False)
    return [
        {"role": "system", "content": SCORE_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
"""PTBL uc asamali boru hatti: fark et -> anla -> icsellestir.

Foundation bolum 2'deki tasarimin kod karsiligi. Mevcut tek atislik
assess_pattern() yalnizca 1. asamayi yapiyordu; bu modul diger ikisini ekler.

Tasarim kurallari:
- Her asama ayri kayit uretir; hicbir asama oncekinin uzerine yazmaz.
- Icsellestirme karari otomatik degildir: Seed v0'da karar 'oneri' olarak
  kaydedilir; durum degisimi kullaniciya aittir (approve komutu).
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from .models import PatternAssessment

UNDERSTAND_SYSTEM_PROMPT = """Bir PTBL anlama yardımcısısın. Sana bir örüntü adayı (gözlem, temkinli yorum) ve
kaynak metin verilecek. Görevin örüntüyü ANLAMAK. Kesin hüküm verme; bilmediğini açıkça yaz.

Yanıtını SADECE şu 6 satırda ver; başka hiçbir şey yazma, JSON yazma, madde ekleme:

ANALIZ: <kaynak ve bağlam analizi, en fazla 2 cümle>
ISLEV: <olası işlev, tek cümle>
KARSIT: <örüntüyü sınırlayabilecek karşı durum, tek cümle>
TOPLULUK: <ilişkili topluluk/dönem veya YOK>
SORU: <cevaplanmadan içselleştirilemeyecek en önemli soru veya YOK>
GUVEN: <0.0 ile 1.0 arasında sayı>"""

INTERNALIZE_SYSTEM_PROMPT = """Bir PTBL içselleştirme danışmanısın. Sana bir örüntü adayı ve anlama kartı verilecek.
Görevin karar ÖNERMEK: bu örüntü Nox'un kimliğine değer katıyor mu?
Kurallar: örüntü kopyalanmaz, dönüştürülür. Gözlem ile yorum karıştırılmaz.
Anlama kartında cevapsız soru varsa her zaman BEKLE öner.

Yanıtını SADECE şu 5 satırda ver; başka hiçbir şey yazma, JSON yazma:

ONERI: <ACTIVE | CONTEXT | ARCHIVE | BEKLE>
DONUSUM: <örüntünün Nox kimliğine dönüştürülmüş hâli, tek cümle veya YOK>
GEREKCE: <kararın gerekçesi, en fazla 2 cümle>
EKSEN: <ilgili kimlik eksenleri, virgülle ayrılmış: sakinlik, kanıt-odaklılık, bağımsızlık, sıcaklık, mizah, özgünlük, teknik-estetik — veya YOK>
GUVEN: <0.0 ile 1.0 arasında sayı>"""


@dataclass(frozen=True)
class UnderstandingCard:
    """2. asamanin (anlamak) ciktisi: adayin baglam karti."""

    source_analysis: str
    function_hypotheses: list[str]
    counter_examples: list[str]
    community_context: str
    open_questions: list[str]
    confidence: float

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_analysis": self.source_analysis,
            "function_hypotheses": self.function_hypotheses,
            "counter_examples": self.counter_examples,
            "community_context": self.community_context,
            "open_questions": self.open_questions,
            "confidence": self.confidence,
        }


@dataclass(frozen=True)
class InternalizationProposal:
    """3. asamanin (icsellestirmek) ciktisi: karar onerisi."""

    recommendation: str  # active | context-bound | archived | candidate
    transformed_form: str
    rationale: str
    identity_axes: list[str]
    confidence: float

    def as_dict(self) -> dict[str, Any]:
        return {
            "recommendation": self.recommendation,
            "transformed_form": self.transformed_form,
            "rationale": self.rationale,
            "identity_axes": self.identity_axes,
            "confidence": self.confidence,
        }


def parse_understanding_card(model_output: str, *, cap_confidence: float = 0.7) -> UnderstandingCard:
    """Anlama ciktisini (6 etiketli satir) savunmaci bicimde ayristirir."""
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("ANALIZ", "ISLEV", "KARSIT", "TOPLULUK", "SORU", "GUVEN"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    if "ANALIZ" not in fields or "GUVEN" not in fields:
        raise ValueError("PTBL asama ciktisi beklenen satir biciminde degil.")
    try:
        confidence = float(fields["GUVEN"])
    except ValueError:
        confidence = 0.0
    confidence = max(0.0, min(cap_confidence, confidence))
    community = fields.get("TOPLULUK", "")
    if community.upper() == "YOK":
        community = ""
    question = fields.get("SORU", "")
    open_questions = [] if question.upper() in ("", "YOK") else [question]
    return UnderstandingCard(
        source_analysis=fields["ANALIZ"],
        function_hypotheses=[fields["ISLEV"]] if fields.get("ISLEV") else [],
        counter_examples=[fields["KARSIT"]] if fields.get("KARSIT") else [],
        community_context=community,
        open_questions=open_questions,
        confidence=confidence,
    )


def parse_internalization_proposal(model_output: str, *, has_open_questions: bool) -> InternalizationProposal:
    """Icsellestirme onerisini (5 etiketli satir) savunmaci bicimde ayristirir.

    Acik soru varken 'candidate' disindaki oneriler 'candidate'e cekilir.
    """
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("ONERI", "DONUSUM", "GEREKCE", "EKSEN", "GUVEN"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    if "ONERI" not in fields or "GUVEN" not in fields:
        raise ValueError("PTBL asama ciktisi beklenen satir biciminde degil.")
    _reco_map = {"ACTIVE": "active", "CONTEXT": "context-bound", "ARCHIVE": "archived", "BEKLE": "candidate"}
    recommendation = _reco_map.get(fields["ONERI"].upper(), "candidate")
    try:
        confidence = float(fields["GUVEN"])
    except ValueError:
        confidence = 0.0
    confidence = max(0.0, min(0.8, confidence))
    if has_open_questions and recommendation != "candidate":
        recommendation = "candidate"
        confidence = min(confidence, 0.5)
    axes_raw = fields.get("EKSEN", "YOK")
    identity_axes = (
        []
        if axes_raw.upper() in ("", "YOK")
        else [a.strip() for a in axes_raw.split(",") if a.strip()]
    )
    transformed = fields.get("DONUSUM", "")
    if transformed.upper() == "YOK":
        transformed = ""
    return InternalizationProposal(
        recommendation=recommendation,
        transformed_form=transformed,
        rationale=fields.get("GEREKCE", ""),
        identity_axes=identity_axes,
        confidence=confidence,
    )


def build_understand_prompt(assessment: PatternAssessment, source_text: str) -> list[dict[str, str]]:
    """2. asama icin model mesajlarini kurar."""
    user = json.dumps(
        {
            "kaynak_metin": source_text,
            "aday_oruntu": assessment.as_dict(),
        },
        ensure_ascii=False,
    )
    return [
        {"role": "system", "content": UNDERSTAND_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]


def build_internalize_prompt(
    assessment: PatternAssessment,
    card: UnderstandingCard,
) -> list[dict[str, str]]:
    """3. asama icin model mesajlarini kurar."""
    user = json.dumps(
        {
            "aday_oruntu": assessment.as_dict(),
            "anlama_karti": card.as_dict(),
        },
        ensure_ascii=False,
    )
    return [
        {"role": "system", "content": INTERNALIZE_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
"""Kontrollü internet erişimi: belirli URL'den metin okuma (L5 ilk adım).

Güvenlik: "network" eylemi SARI — kullanıcı onayı gerekir (request_approval).
Kaynak değerlendirmesi: domain izin listesi + içerik sınırı.
"""
from __future__ import annotations

import re
from urllib.error import URLError
from urllib.request import Request, urlopen

from .security_gate import classify_action, request_approval

ALLOWED_DOMAINS = {
    "en.wikipedia.org",
    "tr.wikipedia.org",
    "developer.mozilla.org",
    "docs.python.org",
    "github.com",
    "raw.githubusercontent.com",
}

MAX_BYTES = 50_000  # 50 KB metin sınırı


def _domain_allowed(url: str) -> bool:
    match = re.search(r"https?://([^/]+)", url)
    if not match:
        return False
    domain = match.group(1).lower()
    return any(domain == d or domain.endswith("." + d) for d in ALLOWED_DOMAINS)


def read_url_text(url: str, timeout: int = 15) -> str:
    """Belirli URL'den metin çeker; güvenlik kapısından geçer."""
    decision = classify_action("network")
    if decision.requires_approval:
        if not request_approval(decision, "network", url):
            raise ValueError(f"Kullanıcı reddetti: {decision.reason}")

    if not _domain_allowed(url):
        raise ValueError(f"İzinli olmayan domain: {url}. İzinli: {', '.join(sorted(ALLOWED_DOMAINS))}")

    request = Request(url, headers={"User-Agent": "NOX-Seed/0.1 (kontrollu erisim)"})
    try:
        with urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get("Content-Type", "")
            if "text" not in content_type and "json" not in content_type and "html" not in content_type:
                raise ValueError(f"Metin olmayan içerik: {content_type}")
            data = response.read(MAX_BYTES).decode("utf-8", errors="replace")
            return data
    except URLError as exc:
        raise ValueError(f"Bağlantı hatası: {exc}") from exc
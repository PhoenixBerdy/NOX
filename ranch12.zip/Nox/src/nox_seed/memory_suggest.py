"""Otomatik hafıza adayı üretimi: sohbetten PTBL ile aday çıkarımı (L6 derinleştirme).

Kural: aday otomatik üretilir ama kullanıcıya gösterilir; kabul kullanıcıya aittir.
Gizli yazım yok — açık kayıt.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

SUGGEST_SYSTEM_PROMPT = """Bir hafıza adayı üreticisisin. Sana kullanıcıyla yapılan son sohbet verilecek.
Kullanıcı hakkında anlamlı, gerekli ve izinli bilgiler çıkar (tercih, bilgi, hedef, kişisel).
Kesin hüküm verme; aday öner.

Yanıtını SADECE şu 4 satırda ver; başka hiçbir şey yazma:

ICERIK: <aday içeriği, tek cümle veya YOK>
KATEGORI: <tercih | bilgi | hedef | kişisel>
GUVEN: <0.0-1.0 arası>
GEREKCE: <neden kaydedilmeli, tek cümle>"""


@dataclass(frozen=True)
class MemorySuggestion:
    content: str
    category: str
    confidence: float
    rationale: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "content": self.content,
            "category": self.category,
            "confidence": self.confidence,
            "rationale": self.rationale,
        }


def parse_suggestion(model_output: str) -> MemorySuggestion | None:
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("ICERIK", "KATEGORI", "GUVEN", "GEREKCE"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    content = fields.get("ICERIK", "").strip()
    if not content or content.upper() == "YOK":
        return None
    try:
        confidence = float(fields.get("GUVEN", "0.5"))
    except ValueError:
        confidence = 0.5
    confidence = max(0.0, min(1.0, confidence))
    return MemorySuggestion(
        content=content,
        category=fields.get("KATEGORI", "bilgi"),
        confidence=confidence,
        rationale=fields.get("GEREKCE", ""),
    )


def build_suggest_prompt(user_text: str, assistant_text: str) -> list[dict[str, str]]:
    import json

    user = json.dumps({"kullanici": user_text, "nox_yaniti": assistant_text}, ensure_ascii=False)
    return [
        {"role": "system", "content": SUGGEST_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
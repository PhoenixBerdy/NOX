"""Medya üretimi: Stable Diffusion API'ye HTTP bağlantısı (W5 ilk adım).

LocalAI veya stable-diffusion-webui gibi self-hosted servise bağlanır.
Güvenlik: "network" eylemi SARI — kullanıcı onayı gerekir (request_approval).
"""
from __future__ import annotations

import json
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request, urlopen

from .security_gate import classify_action, request_approval

MEDIA_URL_DEFAULT = "http://127.0.0.1:7860"  # stable-diffusion-webui varsayılanı
MAX_PROMPT_CHARS = 500


def generate_image(
    prompt: str,
    output_path: Path,
    *,
    width: int = 512,
    height: int = 512,
    steps: int = 20,
    api_url: str = MEDIA_URL_DEFAULT,
    timeout: int = 60,
) -> Path:
    """Stable Diffusion API'ye metin gönderir, görsel kaydeder."""
    if len(prompt) > MAX_PROMPT_CHARS:
        raise ValueError(f"Prompt çok uzun ({len(prompt)} > {MAX_PROMPT_CHARS})")

    decision = classify_action("network")
    if decision.requires_approval:
        if not request_approval(decision, "network", f"medya üretimi: {prompt[:50]}..."):
            raise ValueError(f"Kullanıcı reddetti: {decision.reason}")

    payload = {
        "prompt": prompt,
        "width": width,
        "height": height,
        "steps": steps,
        "sampler_index": "Euler a",
    }
    request = Request(
        f"{api_url.rstrip('/')}/sdapi/v1/txt2img",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
            images = data.get("images", [])
            if not images:
                raise ValueError("API görsel üretmedi")
            import base64

            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(base64.b64decode(images[0]))
            return output_path
    except URLError as exc:
        raise ValueError(f"Bağlantı hatası: {exc}. Stable Diffusion API çalışıyor mu?") from exc
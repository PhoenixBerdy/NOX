"""Evrim iskeleti: pasiflik ölçütü ve aday fikir kaydı (L8 ilk adım).

Blueprint B2 §5: evrim yalnızca birleşik pasiflik sağlandığında devreye girer.
Dört sinyal: girdi, ses, odak, Nox pasifliği.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class PassivityReport:
    """Birleşik pasiflik ölçütünün sonucu."""

    is_passive: bool
    input_idle_seconds: float
    audio_playing: bool
    fullscreen_app: bool
    nox_active: bool
    reason: str

def parse_suggestion(model_output: str) -> EvolutionIdea | None:
    """Otonom fikir üretimini ayrıştırır."""
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("FİKİR", "KAYNAK", "GEREKCE"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    title = fields.get("FİKİR", "").strip()
    if not title or title.upper() == "YOK":
        return None
    return EvolutionIdea(
        title=title,
        source=fields.get("KAYNAK", "otonom"),
        observation=fields.get("GEREKCE", ""),
        status="candidate",
    )


def build_suggest_prompt(capabilities: list[str], recent_projects: list[dict[str, Any]]) -> list[dict[str, str]]:
    import json

    user = json.dumps({
        "mevcut_yetenekler": capabilities,
        "son_projeler": [p["contract"]["title"] for p in recent_projects[:5]],
    }, ensure_ascii=False)
    return [
        {"role": "system", "content": SUGGEST_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]

SELF_IMPROVE_SYSTEM_PROMPT = """Bir öz-iyileştirme danışmanısın. Sana NOX'un kaynak kodu verilecek.
Kodu analiz et: darboğaz, hata riski, PTBL uyumu, okunabilirlik. Küçük, güvenli iyileştirme öner.
Kesin hüküm verme; aday öner.

Yanıtını SADECE şu 4 satırda ver; başka hiçbir şey yazma:

SORUN: <bulunan sorun veya darboğaz, tek cümle>
ONERI: <iyileştirme önerisi, tek cümle>
ETKI: <beklenen fayda: düşük | orta | yüksek>
RISK: <uygulama riski: düşük | orta | yüksek>"""


def parse_self_improve(model_output: str) -> dict[str, str] | None:
    """Öz-iyileştirme önerisini ayrıştırır."""
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("SORUN", "ONERI", "ETKI", "RISK"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    if "ONERI" not in fields:
        return None
    return {
        "issue": fields.get("SORUN", ""),
        "suggestion": fields["ONERI"],
        "impact": fields.get("ETKI", "orta"),
        "risk": fields.get("RISK", "orta"),
    }


def build_self_improve_prompt(code_snippets: dict[str, str]) -> list[dict[str, str]]:
    import json

    user = json.dumps({"kaynak_kod": code_snippets}, ensure_ascii=False)
    return [
        {"role": "system", "content": SELF_IMPROVE_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]

WRITE_TEST_SYSTEM_PROMPT = """Bir test üretim yardımcısısın. Sana NOX'un bir modülü verilecek.
O modül için birim testleri yaz. unittest kullan, satır formatında değil, doğrudan Python kodu üret.
KURALLAR:
- En fazla 3 test metodu üret.
- Kod ASCII-only olsun; Türkçe karakter kullanma.
- Fonksiyon imzalarını tam kapat: def test_x(self): ...
- Markdown çitleri (```) kullanma; sadece saf Python kodu üret.
- import'ları modülün gerçek yolundan yap: from nox_seed.<module> import ...
- import'ları şu formatta yap: from nox_seed.<module> import <fonksiyon> (örn. from nox_seed.recurrence import similarity)
"""
def run_auto_cycle(
    database: Any,
    settings: Any,
    backend: Any,
    max_ideas: int = 3,
) -> dict[str, Any]:
    """Otonom evrim döngüsü: fikir üret → değerlendir → kaydet (L8 genişleme).

    Pasiflikte çalışır; kullanıcı dönünce rapor gösterir.
    Hazırlık otonom, uygulama onaylı — fikirler candidate olarak kalır.
    """
    from .evolution_eval import build_eval_prompt, parse_evaluation

    report = check_passivity()
    if not report.is_passive:
        return {"error": f"pasif değil: {report.reason}"}

    capabilities = ["sohbet", "PTBL", "proje üretimi", "kod üretimi", "PDF", "internet okuma", "medya üretimi"]
    recent_projects = database.list_projects(5)
    ideas = []
    for i in range(max_ideas):
        try:
            raw = backend.chat(build_suggest_prompt(capabilities, recent_projects))
            suggestion = parse_suggestion(raw.content)
            if suggestion:
                idea_id = database.record_evolution_idea(suggestion)
                # Değerlendirme
                eval_raw = backend.chat(build_eval_prompt({"title": suggestion.title, "source": suggestion.source, "observation": suggestion.observation}))
                card = parse_evaluation(eval_raw.content)
                database.record_event("evolution.evaluated", {
                    "idea_id": idea_id, **card.as_dict(),
                })
                ideas.append({
                    "id": idea_id,
                    "title": suggestion.title,
                    "recommendation": card.recommendation,
                })
        except Exception as exc:
            database.record_event("evolution.auto_error", {"error": str(exc), "attempt": i + 1})

    return {
        "cycle": "completed",
        "ideas_produced": len(ideas),
        "ideas": ideas,
        "report": f"{len(ideas)} aday fikir üretildi; değerlendirme için 'python -m nox_seed evolve' kullan."
    }

def check_passivity(
    last_input_time: float | None = None,
    audio_playing: bool = False,
    fullscreen_app: bool = False,
    nox_active: bool = False,
    idle_threshold: float = 600.0,  # 10 dakika
) -> PassivityReport:
    """Dört sinyali birleştirir; pasiflik kararı verir."""
    now = time.time()
    idle = (now - last_input_time) if last_input_time else float("inf")

    reasons = []
    if idle < idle_threshold:
        reasons.append(f"girdi aktif ({idle:.0f}s < {idle_threshold:.0f}s)")
    if audio_playing:
        reasons.append("ses çıkışı var")
    if fullscreen_app:
        reasons.append("tam ekran uygulama var")
    if nox_active:
        reasons.append("Nox'a mesaj geldi")

    is_passive = not reasons
    return PassivityReport(
        is_passive=is_passive,
        input_idle_seconds=idle,
        audio_playing=audio_playing,
        fullscreen_app=fullscreen_app,
        nox_active=nox_active,
        reason="pasif" if is_passive else "; ".join(reasons),
    )


@dataclass(frozen=True)
class EvolutionIdea:
    """Aday evrim fikri: reseptör benzerlik kaydı için."""

    title: str
    source: str
    observation: str
    status: str  # candidate | evaluated | suspended | archived | discarded

    def as_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "source": self.source,
            "observation": self.observation,
            "status": self.status,
        }

SUGGEST_SYSTEM_PROMPT = """Bir evrim fikir üreticisisin. Sana Nox'un mevcut yetenekleri ve son projeleri verilecek.
Nox'a değer katacak yeni bir yetenek fikri öner. Küçük, uygulanabilir, güvenli fikirler.
Kesin hüküm verme; aday öner.

Yanıtını SADECE şu 3 satırda ver; başka hiçbir şey yazma:

FİKİR: <yetenek fikri başlığı, en fazla 5 kelime>
KAYNAK: <fikrin kaynağı (internet, proje, gözlem)>
GEREKCE: <neden değerli, tek cümle>"""      
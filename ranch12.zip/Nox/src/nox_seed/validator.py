"""Proje doğrulayıcı: üretilen dosyalar arasında çapraz denetim.

W3'ün öğrettiği: model HTML, CSS ve JS'i ayrı ayrı üretirken ID ve referans
uyumsuzlukları yaratabilir. Bu modül o hataları kullanıcıdan önce yakalar.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ValidationIssue:
    severity: str  # "hata" | "uyarı"
    message: str

    def as_dict(self) -> dict[str, str]:
        return {"severity": self.severity, "message": self.message}


def validate_project_files(project_dir: Path) -> list[ValidationIssue]:
    """Proje klasöründeki dosyaları çapraz denetler; sorun listesi döner."""
    issues: list[ValidationIssue] = []
    html_files = list(project_dir.glob("*.html"))
    if not html_files:
        return issues

    for html_path in html_files:
        html = html_path.read_text(encoding="utf-8", errors="replace")

        for match in re.finditer(r'(?:href|src)="([^"]+\.(?:css|js))"', html):
            ref = match.group(1)
            if not (project_dir / ref).exists():
                issues.append(ValidationIssue("hata", f"{html_path.name}: bağlanan dosya yok: {ref}"))

        for js_path in project_dir.glob("*.js"):
            js = js_path.read_text(encoding="utf-8", errors="replace")
            for id_match in re.finditer(r"getElementById\('([^']+)'\)", js):
                element_id = id_match.group(1)
                if f'id="{element_id}"' not in html:
                    issues.append(ValidationIssue(
                        "hata", f"{js_path.name}: getElementById('{element_id}') HTML'de tanımlı değil"
                    ))

    for css_path in project_dir.glob("*.css"):
        css = css_path.read_text(encoding="utf-8", errors="replace")
        for bad in re.finditer(r"rgba\([^)]*\d+-\d+[^)]*\)", css):
            issues.append(ValidationIssue("hata", f"{css_path.name}: geçersiz rgba değeri: {bad.group(0)}"))

    return issues
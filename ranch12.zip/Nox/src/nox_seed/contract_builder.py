"""Model destekli proje sözleşmesi üretici (satır formatı, PTBL usulü).

Kullanıcı isteğini analiz edip sözleşme alanlarını doldurur. JSON istemez;
4B modelin taşıyabildiği etiketli satır formatı kullanılır (ptbl_pipeline'daki
kanıtlanmış yaklaşım).
"""
from __future__ import annotations

from .projects import ProjectContract

CONTRACT_SYSTEM_PROMPT = """Bir proje sözleşmesi yardımcısısın. Sana kullanıcının proje isteği verilecek.
İsteği analiz et ve sözleşme alanlarını doldur. Kısa ve öz yaz; her alan tek cümle.
Kapsam dışı ve yaklaşım alanlarında dürüst ol: bilmediğini uydurma, makul varsayımda bulun.

Yanıtını SADECE şu 6 satırda ver; başka hiçbir şey yazma, JSON yazma:

BASLIK: <projenin kısa adı, en fazla 8 kelime>
HEDEF: <hedeflenen çıktı, tek cümle>
BASARI: <başarı ölçütü — nasıl anlaşılır ki iş tamamlandı, tek cümle>
KAPSAM: <neyin dahil olduğu, tek cümle>
KAPSAM_DISI: <neyin dahil olmadığı, tek cümle>
YAKLASIM: <uygulanacak teknoloji/yöntem yaklaşımı, tek cümle>"""


def parse_contract_text(model_output: str, fallback_title: str) -> ProjectContract:
    """6 etiketli satırı savunmacı biçimde ayrıştırır.

    Eksik satır '(belirlenmedi)' ile dolar; BASLIK ve HEDEF zorunludur.
    """
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("BASLIK", "HEDEF", "BASARI", "KAPSAM_DISI", "KAPSAM", "YAKLASIM"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    # KAPSAM_DISI, KAPSAM'dan önce denetlenmeli (ön ek çakışması)
    title = fields.get("BASLIK", "").strip()
    goal = fields.get("HEDEF", "").strip()
    if not title or not goal:
        raise ValueError("Sözleşme çıktısı BASLIK veya HEDEF içermiyor.")
    return ProjectContract(
        title=title[:80],
        goal=goal,
        success_criteria=fields.get("BASARI", "").strip() or "(belirlenmedi)",
        scope=fields.get("KAPSAM", "").strip() or "(belirlenmedi)",
        out_of_scope=fields.get("KAPSAM_DISI", "").strip() or "(belirlenmedi)",
        approach=fields.get("YAKLASIM", "").strip() or "(belirlenmedi)",
        milestones=["sözleşme", "araştırma", "uygulama", "doğrulama"],
        budget="(belirlenmedi)",
    )


def build_contract_prompt(user_request: str, memory_context: str = "") -> list[dict[str, str]]:
    system = CONTRACT_SYSTEM_PROMPT
    if memory_context:
        system += f"\n\nKullanıcı hakkında bildiklerin (açık kayıt):\n{memory_context}"
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": user_request},
    ]
"""Evrim aday değerlendirme: PTBL ile fikir ölçümü (L8 3. aşama).

Blueprint B2 §2: aday fikir PTBL ile ölçülür — kaynak, özgünlük, Nox kimliğiyle
uyum, kaynak maliyeti, risk. Çıktı: değerlendirme kartı + karar önerisi.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

EVAL_SYSTEM_PROMPT = """Bir evrim değerlendirme yardımcısısın. Sana bir aday yetenek fikri verilecek.
Fikri PTBL ilkeleriyle ölç: kaynak, özgünlük, Nox kimliğiyle uyum, kaynak maliyeti, risk.
Kesin hüküm verme; her eksende gerekçeni yaz.

Yanıtını SADECE şu 6 satırda ver; başka hiçbir şey yazma:

KAYNAK: <fikrin kaynağı güvenilir mi, tek cümle>
OZGUNLUK: <0.0-1.0 arası puan>
UYUM: <Nox kimliğiyle uyumlu mu: EVET | KISMI | HAYIR>
MALİYET: <kaynak maliyeti: düşük | orta | yüksek>
RİSK: <güvenlik riski: düşük | orta | yüksek>
ONERI: <değerlendir | askıya_al | arşivle | çöpe_at>"""


@dataclass(frozen=True)
class EvaluationCard:
    source_ok: str
    originality: float
    compatibility: str
    cost: str
    risk: str
    recommendation: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_ok": self.source_ok,
            "originality": self.originality,
            "compatibility": self.compatibility,
            "cost": self.cost,
            "risk": self.risk,
            "recommendation": self.recommendation,
        }


def parse_evaluation(model_output: str) -> EvaluationCard:
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("KAYNAK", "OZGUNLUK", "UYUM", "MALİYET", "RİSK", "ONERI"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    if "ONERI" not in fields:
        raise ValueError("Değerlendirme çıktısı ONERI içermiyor.")
    try:
        originality = float(fields.get("OZGUNLUK", "0.5"))
    except ValueError:
        originality = 0.5
    originality = max(0.0, min(1.0, originality))
    reco_map = {
        "değerlendir": "evaluated",
        "askıya_al": "suspended",
        "arşivle": "archived",
        "çöpe_at": "discarded",
    }
    return EvaluationCard(
        source_ok=fields.get("KAYNAK", ""),
        originality=originality,
        compatibility=fields.get("UYUM", "KISMI"),
        cost=fields.get("MALİYET", "orta"),
        risk=fields.get("RİSK", "orta"),
        recommendation=reco_map.get(fields["ONERI"], "evaluated"),
    )


def build_eval_prompt(idea: dict[str, Any]) -> list[dict[str, str]]:
    import json

    user = json.dumps(
        {"aday_fikir": {"title": idea["title"], "source": idea["source"], "observation": idea["observation"]}},
        ensure_ascii=False,
    )
    return [
        {"role": "system", "content": EVAL_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
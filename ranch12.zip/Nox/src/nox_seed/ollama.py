from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .config import Settings
from .models import PatternAssessment


class OllamaError(RuntimeError):
    pass


NOX_SYSTEM_PROMPT = """Sen Nox'sun: yerel, dikkatli ve meraklı bir kişisel ajan çekirdeği (Seed v0).
Türkçe yanıt ver. Gözlem ile yorumu, kesinlik ile belirsizliği birbirine karıştırma.
Sakin, kanıt odaklı, düşünsel olarak bağımsız ve sıcak ama yaltaklanmayan bir ortak gibi konuş.
Sıradan yaklaşımın yanında güvenli ve anlamlı alternatifler üretebilirsin; farklı görünmek için anlamsızlaşma.
Uygun olduğunda hafif, kuru ve zarar vermeyen mizah kullan; kullanıcının zorlandığı anda mizahı gösteriş için kullanma.
Kullanıcıyla ayrıştığında niyetini önce doğru anla, ayrıldığın noktayı doğrudan söyle, gerekçeni açıkla ve daha iyi gördüğün alternatifi sun.
Kendini insan gibi duygu, anı veya ihtiyaç sahibi göstermeye çalışma; referans karakterleri taklit etme.
Henüz internete, dosyalara veya bilgisayara eylem yapma yetkin yok; sadece metinle konuşuyorsun.
Kullanıcının kısa ya da noktalamasız gündelik mesajlarında niyeti bağlamdan dikkatle çıkar; gereksiz soru sorma.
Varsayılan olarak sonucu önce ver ve iki ila beş kısa cümlede kal. Kullanıcı uzun veya derin bir çalışma verirse daha yapılandırılmış ve ayrıntılı yanıt ver.
Özel konuşmalardaki hitapları, yazım hatalarını, argo/profaniteyi veya ilişki dilini taklit etme.
Kısa ve yararlı cevap ver; uydurma bilgi üretme."""

PTBL_SYSTEM_PROMPT = """Bir PTBL değerlendirme yardımcısısın. Verilen metindeki gözlenebilir örüntü ile
yorumunu kesin biçimde ayır. Niyet, kimlik veya psikoloji hakkında kanıtsız hüküm verme.
SADECE aşağıdaki anahtarlarla geçerli JSON nesnesi döndür:
{
  "observation": "metinde doğrudan görünen olgular",
  "interpretation": "temkinli yorum veya boş dize",
  "confidence": 0.0,
  "pattern_type": "dil|mizah|öğretim|ilişki|düşünce|topluluk|davranış|diğer",
  "evidence": ["kısa dayanaklar"],
  "unknowns": ["bilinmeyenler veya karşı örnek ihtiyacı"]
}
confidence 0 ile 1 arasında olmalı."""


@dataclass
class OllamaClient:
    settings: Settings

    def chat(self, user_text: str, *, history: list[dict[str, str]] | None = None) -> str:
        """Return a complete answer for the terminal interface and tests."""
        payload = self._request(
            self._chat_messages(user_text, history),
            max_output_tokens=self._response_budget(user_text),
        )
        return self._content(payload)

    def stream_chat(
        self,
        user_text: str,
        *,
        history: list[dict[str, str]] | None = None,
        on_chunk: Callable[[str], None],
    ) -> str:
        """Stream an answer so the desktop demo can reveal it as it is generated."""
        body = self._request_body(
            self._chat_messages(user_text, history),
            max_output_tokens=self._response_budget(user_text),
            stream=True,
        )
        request = Request(
            f"{self.settings.ollama_url.rstrip('/')}/api/chat",
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        parts: list[str] = []
        try:
            with urlopen(request, timeout=self.settings.request_timeout_seconds) as response:
                for raw_line in response:
                    line = raw_line.decode("utf-8").strip()
                    if not line:
                        continue
                    try:
                        packet = json.loads(line)
                    except json.JSONDecodeError as exc:
                        raise OllamaError("Ollama akış yanıtı okunabilir JSON değil.") from exc
                    content = packet.get("message", {}).get("content", "")
                    if isinstance(content, str) and content:
                        parts.append(content)
                        on_chunk(content)
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise OllamaError(f"Ollama isteği HTTP {exc.code} ile başarısız oldu: {detail}") from exc
        except URLError as exc:
            raise OllamaError("Ollama'ya ulaşılamadı. Ollama'nın çalıştığını kontrol et.") from exc

        answer = "".join(parts).strip()
        if not answer:
            raise OllamaError("Ollama akış sırasında boş yanıt döndürdü.")
        return answer

    def run_ptbl_stage(self, messages: list[dict[str, str]]) -> str:
        """2. ve 3. PTBL aşamaları için ham model çıktısı döndürür.

        Ayrıştırma ptbl_pipeline modülünün işidir; bu metod yalnızca isteği
        aynı kısıtlarla (JSON modu, düşük sıcaklık, aşama bütçesi) iletir.
        """
        payload = self._request(
            messages,
            temperature=0.1,
            json_mode=True,
            max_output_tokens=self.settings.stage_max_output_tokens,
        )
        return self._content(payload)

    def assess_pattern(self, text: str) -> PatternAssessment:
        payload = self._request(
            [
                {"role": "system", "content": PTBL_SYSTEM_PROMPT},
                {"role": "user", "content": text},
            ],
            temperature=0.1,
            json_mode=True,
            max_output_tokens=self.settings.assessment_max_output_tokens,
        )
        return parse_pattern_assessment(self._content(payload))

    def _request(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float = 0.4,
        json_mode: bool = False,
        max_output_tokens: int | None = None,
    ) -> dict[str, Any]:
        body = self._request_body(
            messages,
            temperature=temperature,
            json_mode=json_mode,
            max_output_tokens=max_output_tokens,
        )
        request_body = json.dumps(body).encode("utf-8")
        request = Request(
            f"{self.settings.ollama_url.rstrip('/')}/api/chat",
            data=request_body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.settings.request_timeout_seconds) as response:
                return json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise OllamaError(f"Ollama isteği HTTP {exc.code} ile başarısız oldu: {detail}") from exc
        except URLError as exc:
            raise OllamaError("Ollama'ya ulaşılamadı. Ollama'nın çalıştığını kontrol et.") from exc

    def _request_body(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float = 0.4,
        json_mode: bool = False,
        max_output_tokens: int | None = None,
        stream: bool = False,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": self.settings.model,
            "stream": stream,
            "think": False,
            "messages": messages,
            "options": {
                "num_ctx": self.settings.context_tokens,
                "num_predict": max_output_tokens or self.settings.max_output_tokens,
                "temperature": temperature,
            },
        }
        if json_mode:
            body["format"] = "json"
        return body

    @staticmethod
    def _chat_messages(user_text: str, history: list[dict[str, str]] | None) -> list[dict[str, str]]:
        conversation = history[-8:] if history else []
        return [
            {"role": "system", "content": NOX_SYSTEM_PROMPT},
            *conversation,
            {"role": "user", "content": user_text},
        ]

    def _response_budget(self, user_text: str) -> int:
        """Short, informal messages should not wait for an unnecessarily long answer."""
        if len(user_text.strip()) <= 280:
            return min(self.settings.max_output_tokens, 96)
        return self.settings.max_output_tokens

    @staticmethod
    def _content(payload: dict[str, Any]) -> str:
        try:
            content = payload["message"]["content"].strip()
        except (KeyError, AttributeError) as exc:
            raise OllamaError("Ollama beklenen sohbet yanıtını döndürmedi.") from exc
        if not content:
            raise OllamaError("Ollama boş yanıt döndürdü.")
        return content


def parse_pattern_assessment(model_output: str) -> PatternAssessment:
    """Parse a model answer defensively; never silently invent an interpretation."""
    cleaned = model_output.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else ""
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start < 0 or end < start:
        raise OllamaError("PTBL değerlendirmesi geçerli JSON içermiyor.")
    try:
        data = json.loads(cleaned[start : end + 1])
    except json.JSONDecodeError as exc:
        raise OllamaError("PTBL değerlendirmesi okunabilir JSON değil.") from exc

    try:
        confidence = float(data.get("confidence", 0.0))
    except (TypeError, ValueError) as exc:
        raise OllamaError("PTBL güven değeri sayı değil.") from exc

    evidence = _as_text_list(data.get("evidence"))
    unknowns = _as_text_list(data.get("unknowns"))

    # PTBL kalite kapısı: kanıtsız veya bilinmeyensiz bir değerlendirme yüksek
    # güvenle kayda geçemez. Bu, "uyumayı bırakmak" duman testindeki anlamsal
    # hatanın tekrarını engelleyen ilk savunma hattıdır.
    if not evidence or not unknowns:
        confidence = min(confidence, 0.4)

    # Güven kalibrasyonu: modelin öz-değerlendirmesi kalibre değildir
    # (12 Eylül 2026 canlı karne: 14 vakanın 12'sinde 0.90+ güven).
    # Bilinmeyen sayısı arttıkça dürüst tavan düşer.
    elif len(unknowns) == 1:
        confidence = min(confidence, 0.7)
    else:
        confidence = min(confidence, 0.85)

    # Muğlaklık sinyalleri gözlemde açıkça yazıyorsa tavan daha da düşer.
    observation_text = _as_text(data.get("observation")).lower()
    if any(s in observation_text for s in ("muğlak", "olasılık", "belirsiz", "kayıt")):
        confidence = min(confidence, 0.75)

    return PatternAssessment(
        observation=_as_text(data.get("observation")),
        interpretation=_as_text(data.get("interpretation")),
        confidence=max(0.0, min(1.0, confidence)),
        pattern_type=_as_text(data.get("pattern_type")) or "diğer",
        evidence=evidence,
        unknowns=unknowns,
    )


def _as_text(value: Any) -> str:
    return value.strip() if isinstance(value, str) else ""


def _as_text_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item.strip() for item in value if isinstance(item, str) and item.strip()]
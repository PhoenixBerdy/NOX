"""Kontrol noktası yürütücüsü: proje adımlarını kısa dilimlerle ilerletir.

Work modeli blueprint'i Bölüm 1 §5: iş küçük kontrol noktalarına bölünür;
her adımın başında amaç/bütçe/yetki, sonunda ara çıktı ve sonraki adım kaydedilir.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

EXECUTE_SYSTEM_PROMPT = """Bir proje yürütücüsüsün. Sana proje sözleşmesi ve mevcut adım verilecek.
Adımı çalıştır ve ara çıktı üret. Kısa ve öz yaz; ürettiğin içerik doğrudan
proje çıktısına gidecek. Uydurma bilgi üretme; bilmediğinde BELIRSIZ yaz.

Yanıtını SADECE şu 3 satırda ver; başka hiçbir şey yazma:

CIKTI: <adımın ara çıktısı; en fazla 5 cümle>
SONRAKI: <bir sonraki adımın kısa tanımı veya TAMAM>
NOT: <varsayım, risk veya kullanıcıya soru; yoksa YOK>"""


@dataclass(frozen=True)
class StepResult:
    """Bir kontrol noktası adımının çıktısı."""

    output: str
    next_step: str  # "TAMAM" ise proje doğrulamaya geçer
    note: str

    def as_dict(self) -> dict[str, Any]:
        return {"output": self.output, "next_step": self.next_step, "note": self.note}


def parse_step_result(model_output: str) -> StepResult:
    """3 etiketli satırı savunmacı biçimde ayrıştırır."""
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("CIKTI", "SONRAKI", "NOT"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    if "CIKTI" not in fields or "SONRAKI" not in fields:
        raise ValueError("Yürütücü çıktısı CIKTI veya SONRAKI içermiyor.")
    return StepResult(
        output=fields["CIKTI"],
        next_step=fields["SONRAKI"] or "TAMAM",
        note=fields.get("NOT", "") if fields.get("NOT", "YOK") != "YOK" else "",
    )


def build_step_prompt(contract: dict[str, Any], step: str, previous_outputs: list[str]) -> list[dict[str, str]]:
    import json

    user = json.dumps(
        {
            "sozlesme": {"goal": contract.get("goal", ""), "success_criteria": contract.get("success_criteria", "")},
            "mevcut_adim": step,
            "onceki_ciktilar": previous_outputs[-3:],
        },
        ensure_ascii=False,
    )
    return [
        {"role": "system", "content": EXECUTE_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
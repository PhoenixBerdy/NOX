from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

from .models import PatternAssessment, StoredPattern


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class Database:
    """Small, inspectable SQLite event store for Seed v0."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._session() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    project_id TEXT,
                    device_id TEXT,
                    payload_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    source_event_id INTEGER,
                    observation TEXT NOT NULL,
                    interpretation TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
                    pattern_type TEXT NOT NULL,
                    evidence_json TEXT NOT NULL,
                    unknowns_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'candidate',
                    FOREIGN KEY(source_event_id) REFERENCES events(id)
                );

                CREATE TABLE IF NOT EXISTS pattern_stages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    pattern_id INTEGER NOT NULL,
                    stage TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    FOREIGN KEY(pattern_id) REFERENCES patterns(id)
                );

                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'taslak',
                    contract_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS project_transitions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    project_id INTEGER NOT NULL,
                    from_status TEXT NOT NULL,
                    to_status TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    FOREIGN KEY(project_id) REFERENCES projects(id)
                );

                CREATE TABLE IF NOT EXISTS assumptions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    project_id INTEGER NOT NULL,
                    level TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    rationale TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
                    alternative TEXT NOT NULL,
                    FOREIGN KEY(project_id) REFERENCES projects(id)
                );

                CREATE TABLE IF NOT EXISTS evolution_ideas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    title TEXT NOT NULL,
                    source TEXT NOT NULL,
                    observation TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'candidate'
                );

                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
                    category TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'aday'
                );

                CREATE TABLE IF NOT EXISTS devices (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    name TEXT NOT NULL,
                    level TEXT NOT NULL DEFAULT 'salt-okunur',
                    status TEXT NOT NULL DEFAULT 'active'
                );

                CREATE INDEX IF NOT EXISTS idx_events_created_at ON events(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_patterns_created_at ON patterns(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_pattern_stages_pattern ON pattern_stages(pattern_id);
                CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
                CREATE INDEX IF NOT EXISTS idx_evolution_status ON evolution_ideas(status);
                CREATE INDEX IF NOT EXISTS idx_memories_status ON memories(status);
                CREATE INDEX IF NOT EXISTS idx_devices_status ON devices(status);
                """
            )
            # Eski tablolara sonradan eklenen kolonlar (geriye dönük uyum)
            try:
                connection.execute("ALTER TABLE events ADD COLUMN device_id TEXT")
            except sqlite3.OperationalError:
                pass  # kolon zaten var
                

    def record_event(
        self,
        kind: str,
        payload: dict[str, Any],
        *,
        project_id: str | None = None,
        device_id: str | None = None,
    ) -> int:
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO events (created_at, kind, project_id, device_id, payload_json)
                VALUES (?, ?, ?, ?, ?)
                """,
                (utc_now(), kind, project_id, device_id, json.dumps(payload, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def record_pattern(
        self,
        assessment: PatternAssessment,
        *,
        source_event_id: int | None = None,
        status: str = "candidate",
        merge: bool = True,
    ) -> int:
        """Aday örüntüyü kaydeder; merge=True iken benzer adayla birleştirir."""
        if merge and status == "candidate":
            from .recurrence import apply_recurrence, find_similar_candidate

            with self._session() as connection:
                hit = find_similar_candidate(connection, assessment.observation)
                if hit is not None:
                    pattern_id, sim, rec_count = hit
                    new_confidence = apply_recurrence(
                        connection,
                        pattern_id,
                        list(assessment.evidence),
                        rec_count,
                        utc_now(),
                    )
                    connection.execute(
                        """
                        INSERT INTO pattern_stages (created_at, pattern_id, stage, payload_json)
                        VALUES (?, ?, 'recurrence', ?)
                        """,
                        (
                            utc_now(),
                            pattern_id,
                            json.dumps(
                                {
                                    "similarity": sim,
                                    "new_evidence": list(assessment.evidence),
                                    "recurrence_count": rec_count + 1,
                                    "confidence": new_confidence,
                                },
                                ensure_ascii=False,
                            ),
                        ),
                    )
                    return pattern_id
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO patterns (
                    created_at, source_event_id, observation, interpretation,
                    confidence, pattern_type, evidence_json, unknowns_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    utc_now(),
                    source_event_id,
                    assessment.observation,
                    assessment.interpretation,
                    assessment.confidence,
                    assessment.pattern_type,
                    json.dumps(assessment.evidence, ensure_ascii=False),
                    json.dumps(assessment.unknowns, ensure_ascii=False),
                    status,
                ),
            )
            return int(cursor.lastrowid)

    def record_pattern_stage(
        self,
        pattern_id: int,
        stage: str,
        payload: dict[str, Any],
    ) -> int:
        """Aşama çıktısını ayrı kayıt olarak ekler; üzerine yazmaz."""
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO pattern_stages (created_at, pattern_id, stage, payload_json)
                VALUES (?, ?, ?, ?)
                """,
                (utc_now(), pattern_id, stage, json.dumps(payload, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def pattern_stages(self, pattern_id: int) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, stage, payload_json
                FROM pattern_stages
                WHERE pattern_id = ?
                ORDER BY id ASC
                """,
                (pattern_id,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "stage": row["stage"],
                "payload": json.loads(row["payload_json"]),
            }
            for row in rows
        ]

    def set_pattern_status(self, pattern_id: int, status: str) -> None:
        """Kullanıcı onayıyla örüntünün yaşam döngüsü durumunu günceller."""
        with self._session() as connection:
            connection.execute(
                "UPDATE patterns SET status = ? WHERE id = ?",
                (status, pattern_id),
            )
            # ---- Project Core -------------------------------------------------

    def create_project(self, contract: "ProjectContract") -> int:
        """Yeni proje kaydı açar; durum 'taslak' olarak başlar."""
        with self._session() as connection:
            cursor = connection.execute(
                "INSERT INTO projects (created_at, status, contract_json) VALUES (?, 'taslak', ?)",
                (utc_now(), json.dumps(contract.as_dict(), ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def transition_project(self, project_id: int, target: str, reason: str) -> bool:
        """Durum geçişi yapar; izinsiz geçiş reddedilir ve False döner."""
        from .projects import can_transition

        with self._session() as connection:
            row = connection.execute(
                "SELECT status FROM projects WHERE id = ?", (project_id,)
            ).fetchone()
            if row is None or not can_transition(row["status"], target):
                return False
            connection.execute(
                "UPDATE projects SET status = ? WHERE id = ?", (target, project_id)
            )
            connection.execute(
                """
                INSERT INTO project_transitions (created_at, project_id, from_status, to_status, reason)
                VALUES (?, ?, ?, ?, ?)
                """,
                (utc_now(), project_id, row["status"], target, reason),
            )
            return True

    def record_assumption(self, project_id: int, assumption: "Assumption") -> int:
        from .projects import validate_assumption

        violations = validate_assumption(assumption)
        if violations:
            raise ValueError(f"Geçersiz varsayım: {'; '.join(violations)}")
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO assumptions (created_at, project_id, level, decision, rationale, confidence, alternative)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    utc_now(), project_id, assumption.level, assumption.decision,
                    assumption.rationale, assumption.confidence, assumption.alternative,
                ),
            )
            return int(cursor.lastrowid)

    def list_projects(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                "SELECT id, created_at, status, contract_json FROM projects ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "status": row["status"],
                "contract": json.loads(row["contract_json"]),
            }
            for row in rows
        ]

    def project_transitions(self, project_id: int) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT from_status, to_status, reason, created_at
                FROM project_transitions WHERE project_id = ? ORDER BY id ASC
                """,
                (project_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    # ---- Cihazlar ------------------------------------------------------

    def register_device(self, device_id: str, name: str, level: str = "salt-okunur") -> None:
        """Yeni cihaz kaydı (L7 yetki modeli)."""
        with self._session() as connection:
            connection.execute(
                """
                INSERT OR REPLACE INTO devices (id, created_at, name, level, status)
                VALUES (?, ?, ?, ?, 'active')
                """,
                (device_id, utc_now(), name, level),
            )

    def list_devices(self, status: str | None = None) -> list[dict[str, Any]]:
        with self._session() as connection:
            if status:
                rows = connection.execute(
                    "SELECT id, created_at, name, level, status FROM devices WHERE status = ? ORDER BY created_at DESC",
                    (status,),
                ).fetchall()
            else:
                rows = connection.execute(
                    "SELECT id, created_at, name, level, status FROM devices ORDER BY created_at DESC"
                ).fetchall()
        return [
            {
                "id": row["id"],
                "created_at": row["created_at"],
                "name": row["name"],
                "level": row["level"],
                "status": row["status"],
            }
            for row in rows
        ]

    def set_device_status(self, device_id: str, status: str) -> None:
        """Cihaz erişimini geri alır (revoke)."""
        with self._session() as connection:
            connection.execute(
                "UPDATE devices SET status = ? WHERE id = ?",
                (status, device_id),
            )

    def record_memory(self, candidate: "MemoryCandidate") -> int:
        """Hafıza adayını kaydeder (durum: aday)."""
        from .memory import validate_candidate

        violations = validate_candidate(candidate)
        if violations:
            raise ValueError(f"Geçersiz hafıza adayı: {'; '.join(violations)}")
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO memories (created_at, content, source, confidence, category, status)
                VALUES (?, ?, ?, ?, ?, 'aday')
                """,
                (utc_now(), candidate.content, candidate.source, candidate.confidence, candidate.category),
            )
            return int(cursor.lastrowid)

    def set_memory_status(self, memory_id: int, status: str) -> None:
        """Hafıza durumunu kullanıcı onayıyla günceller."""
        with self._session() as connection:
            connection.execute(
                "UPDATE memories SET status = ? WHERE id = ?",
                (status, memory_id),
            )
            
    def archive_old_memories(self, days: int = 30) -> int:
        """30+ gün askida durumundaki hafızaları arşivler (L6 yaşam döngüsü)."""
        from datetime import timedelta

        cutoff = (datetime.now(UTC) - timedelta(days=days)).isoformat(timespec="seconds")
        with self._session() as connection:
            cursor = connection.execute(
                """
                UPDATE memories SET status = 'archived'
                WHERE status = 'askida' AND created_at < ?
                """,
                (cutoff,),
            )
            return cursor.rowcount        

    def list_memories(self, status: str | None = None, limit: int = 20) -> list[dict[str, Any]]:
        with self._session() as connection:
            if status:
                rows = connection.execute(
                    "SELECT id, created_at, content, source, confidence, category, status FROM memories WHERE status = ? ORDER BY id DESC LIMIT ?",
                    (status, limit),
                ).fetchall()
            else:
                rows = connection.execute(
                    "SELECT id, created_at, content, source, confidence, category, status FROM memories ORDER BY id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "content": row["content"],
                "source": row["source"],
                "confidence": float(row["confidence"]),
                "category": row["category"],
                "status": row["status"],
            }
            for row in rows
        ]

    # ---- Evrim ---------------------------------------------------------

    def record_evolution_idea(self, idea: "EvolutionIdea") -> int:
        """Aday evrim fikrini kaydeder; reseptör benzerlik denetimi yapar."""
        from .recurrence import similarity

        with self._session() as connection:
            rows = connection.execute(
                "SELECT id, title, observation FROM evolution_ideas WHERE status != 'discarded'"
            ).fetchall()
            for row in rows:
                if similarity(idea.title, row["title"]) >= 0.6:
                    # Reseptör: aynı fikir tanındı, gözleme ekle
                    new_obs = row["observation"] + "\n" + idea.observation
                    connection.execute(
                        "UPDATE evolution_ideas SET observation = ? WHERE id = ?",
                        (new_obs, row["id"]),
                    )
                    return int(row["id"])
            cursor = connection.execute(
                """
                INSERT INTO evolution_ideas (created_at, title, source, observation, status)
                VALUES (?, ?, ?, ?, ?)
                """,
                (utc_now(), idea.title, idea.source, idea.observation, idea.status),
            )
            return int(cursor.lastrowid)

    def list_evolution_ideas(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                "SELECT id, created_at, title, source, observation, status FROM evolution_ideas ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "title": row["title"],
                "source": row["source"],
                "observation": row["observation"],
                "status": row["status"],
            }
            for row in rows
        ]

    def recent_events(self, limit: int = 10) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, kind, project_id, device_id, payload_json
                FROM events
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "kind": row["kind"],
                "project_id": row["project_id"],
                "payload": json.loads(row["payload_json"]),
            }
            for row in rows
        ]

    def recent_patterns(self, limit: int = 10) -> list[StoredPattern]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, source_event_id, observation, interpretation,
                       confidence, pattern_type, evidence_json, unknowns_json, status
                FROM patterns
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._row_to_pattern(row) for row in rows]

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _session(self) -> Iterator[sqlite3.Connection]:
        """Commit or roll back each operation and always release the Windows file handle."""
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _row_to_pattern(row: sqlite3.Row) -> StoredPattern:
        return StoredPattern(
            id=int(row["id"]),
            created_at=row["created_at"],
            source_event_id=row["source_event_id"],
            assessment=PatternAssessment(
                observation=row["observation"],
                interpretation=row["interpretation"],
                confidence=float(row["confidence"]),
                pattern_type=row["pattern_type"],
                evidence=list(json.loads(row["evidence_json"])),
                unknowns=list(json.loads(row["unknowns_json"])),
            ),
            status=row["status"],
        )
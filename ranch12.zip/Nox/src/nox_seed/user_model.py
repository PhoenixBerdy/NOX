"""Kullanıcı modeli: PTBL kayıtlarından kişisel ritim çıkarımı (açık kayıt).

Manifesto: "Nox kullanıcısıyla ilgili sürekli bir şeyler arayacak, PTBL ile tahlil edecek."
Kural: gizli test yok; açık kayıt + kullanıcıya gösterilebilir.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class UserRhythm:
    """Kullanıcının iletişim ritmi."""

    short_message_ratio: float
    avg_message_length: int
    preferred_topics: list[str]
    active_hours: list[int]

    def as_dict(self) -> dict[str, Any]:
        return {
            "short_message_ratio": self.short_message_ratio,
            "avg_message_length": self.avg_message_length,
            "preferred_topics": self.preferred_topics,
            "active_hours": self.active_hours,
        }


def analyze_user_rhythm(events: list[dict[str, Any]]) -> UserRhythm:
    """Olay kayıtlarından kullanıcı ritmi çıkarır."""
    user_messages = [
        e["payload"].get("text", "")
        for e in events
        if e["kind"] == "chat.user" and e["payload"].get("text")
    ]
    if not user_messages:
        return UserRhythm(0.0, 0, [], [])

    lengths = [len(m) for m in user_messages]
    short_count = sum(1 for l in lengths if l <= 280)
    ratio = short_count / len(user_messages)
    avg_len = sum(lengths) // len(lengths)

    from collections import Counter

    words = []
    for m in user_messages:
        words.extend(w.lower().strip(".,;:!?") for w in m.split() if len(w) > 4)
    topics = [w for w, _ in Counter(words).most_common(5)]

    hours = sorted({int(e["created_at"][11:13]) for e in events if e["kind"] == "chat.user"})

    return UserRhythm(
        short_message_ratio=ratio,
        avg_message_length=avg_len,
        preferred_topics=topics,
        active_hours=hours,
    )
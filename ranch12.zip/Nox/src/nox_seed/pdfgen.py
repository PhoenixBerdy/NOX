"""PDF üretimi: saf Python, bağımlılıksız minimal PDF yazıcısı.

Work modeli W4'ün karşılığı. Metin tabanlı, tek font (Helvetica), UTF-16
Türkçe desteği ile basit PDF üretir. Görsel/renkli PDF platform aşamasında
araştırılır; bu sürüm okunabilir, taşınabilir belge üretir.
"""
from __future__ import annotations

from pathlib import Path


def _utf16be_hex(text: str) -> str:
    return text.encode("utf-16-be").hex().upper()


def build_pdf(title: str, sections: list[tuple[str, str]], output_path: Path) -> Path:
    """Başlık + (başlık, metin) bölümlerinden tek sayfalık basit PDF üretir.

    sections: [(bölüm_başlığı, bölüm_metni), ...] — metin satırları \n ile ayrılır.
    """
    lines: list[tuple[str, int]] = [(title, 16)]
    for heading, body in sections:
        lines.append(("", 12))
        lines.append((heading, 13))
        for raw_line in body.splitlines() or [""]:
            lines.append((raw_line, 11))

    ops: list[str] = ["BT", "/F1 16 Tf", "72 770 Td"]
    current_size = 16
    for text, size in lines:
        if size != current_size:
            ops.append(f"/F1 {size} Tf")
            current_size = size
        if text == "":
            ops.append("0 -14 Td")
            continue
        ops.append(f"<{_utf16be_hex(text)}> Tj")
        ops.append("0 -14 Td")
    ops.append("ET")
    content = "\n".join(ops).encode("ascii")

    objects: list[bytes] = []
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objects.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objects.append(
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
        b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>"
    )
    objects.append(
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
    )
    objects.append(
        b"<< /Length " + str(len(content)).encode("ascii") + b" >>\nstream\n" + content + b"\nendstream"
    )

    pdf = bytearray(b"%PDF-1.4\n")
    offsets: list[int] = []
    for i, obj in enumerate(objects, start=1):
        offsets.append(len(pdf))
        pdf += f"{i} 0 obj\n".encode("ascii") + obj + b"\nendobj\n"
    xref_pos = len(pdf)
    pdf += f"xref\n0 {len(objects) + 1}\n".encode("ascii")
    pdf += b"0000000000 65535 f \n"
    for off in offsets:
        pdf += f"{off:010d} 00000 n \n".encode("ascii")
    pdf += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
        f"startxref\n{xref_pos}\n%%EOF"
    ).encode("ascii")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(bytes(pdf))
    return output_path
"""Güvenlik kapısı: eylem sınıflandırması ve yetki denetimi (L4).

Blueprint B1 §8: üretim yalnızca izole klasöre, klasör dışı SARI, silme KIRMIZI.
Bu modül her eylemi sınıflandırır ve karar verir.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

GREEN = "yesil"
LIME = "lime"
YELLOW = "sari"
RED = "kirmizi"


@dataclass(frozen=True)
class SecurityDecision:
    allowed: bool
    level: str
    reason: str
    requires_approval: bool


def classify_action(
    action: str,
    target_path: Path | None = None,
    projects_root: Path | None = None,
    **kwargs: Any,
) -> SecurityDecision:
    """Bir eylemi sınıflandırır ve karar verir."""
    if action == "read_file":
        return SecurityDecision(True, GREEN, "okuma düşük riskli", False)

    if action == "write_file":
        if target_path is None:
            return SecurityDecision(False, RED, "hedef yok", True)
        if projects_root and target_path.is_relative_to(projects_root):
            return SecurityDecision(True, GREEN, "izole klasör içi", False)
        return SecurityDecision(False, YELLOW, "izole klasör dışı yazma; kullanıcı onayı gerekir", True)

    if action == "delete_file":
        return SecurityDecision(False, RED, "silme geri dönüşsüz; her zaman kullanıcı onayı", True)

    if action == "network":
        return SecurityDecision(False, YELLOW, "dışa veri gönderme; kullanıcı onayı gerekir", True)

    if action == "execute":
        return SecurityDecision(False, RED, "kod çalıştırma; her zaman kullanıcı onayı", True)

    return SecurityDecision(False, RED, f"bilinmeyen eylem: {action}", True)
    
def request_approval(decision: SecurityDecision, action: str, detail: str) -> bool:
    """Sarı/kırmızı eylemde kullanıcıdan onay ister.

    Seed v0: terminalde sorar. Platformda bildirim merkezi olacak.
    """
    print(f"\n⚠ Güvenlik kapısı: {decision.reason}")
    print(f"Eylem: {action} · {detail}")
    answer = input("Onaylıyor musun? (e/h): ").strip().lower()
    return answer in ("e", "evet", "y", "yes")    
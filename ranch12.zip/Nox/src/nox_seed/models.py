from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class PatternAssessment:
    """A deliberately separated observation and interpretation for a PTBL trial."""

    observation: str
    interpretation: str
    confidence: float
    pattern_type: str
    evidence: list[str]
    unknowns: list[str]

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class StoredPattern:
    id: int
    created_at: str
    source_event_id: int | None
    assessment: PatternAssessment
    status: str

"""Project Core: proje sözleşmesi, yaşam döngüsü ve varsayım defteri.

Work modeli blueprint'inin (BLUEPRINTS.md Bölüm 1) ilk kod karşılığı.

Kurallar:
- Her proje kalıcı kayda sahiptir; Nox kapansa bile kayıttan devam eder.
- Durum geçişleri denetlenir: geçersiz geçiş reddedilir ve kayda düşülür.
- Varsayımlar ayrı tabloda tutulur (seviye, gerekçe, güven).
- Proje üretimi izole klasöredir: data/projects/<proje_id>/ (güvenlik kapısı).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Yaşam döngüsü durumları ve izin verilen geçişler.
# Blueprint Bölüm 1 §4'teki durum makinesinin birebir karşılığı.
STATUSES = (
    "taslak",
    "sozlesme",
    "sirada",
    "calisiyor",
    "dogrulaniyor",
    "duraklatildi",
    "yeniden_planlaniyor",
    "kullanici_bekliyor",
    "engellendi",
    "iptal",
    "tamamlandi",
)

ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "taslak": {"sozlesme", "iptal"},
    "sozlesme": {"sirada", "iptal"},
    "sirada": {"calisiyor", "duraklatildi", "iptal"},
    "calisiyor": {"dogrulaniyor", "duraklatildi", "yeniden_planlaniyor", "kullanici_bekliyor", "engellendi", "iptal"},
    "dogrulaniyor": {"tamamlandi", "calisiyor", "yeniden_planlaniyor", "engellendi"},
    "duraklatildi": {"sirada", "calisiyor", "iptal"},
    "yeniden_planlaniyor": {"sozlesme", "sirada", "iptal"},
    "kullanici_bekliyor": {"calisiyor", "duraklatildi", "iptal"},
    "engellendi": {"yeniden_planlaniyor", "iptal"},
    "iptal": set(),
    "tamamlandi": set(),
}

# Yetki haritası seviyeleri (BLUEPRINTS.md Bölüm 1 §3)
AUTH_LEVELS = ("yesil", "lime", "sari", "kirmizi")


@dataclass(frozen=True)
class ProjectContract:
    """Proje sözleşmesi: blueprint Bölüm 1 §4 içeriği."""

    title: str
    goal: str
    success_criteria: str
    scope: str
    out_of_scope: str
    approach: str
    milestones: list[str]
    budget: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "goal": self.goal,
            "success_criteria": self.success_criteria,
            "scope": self.scope,
            "out_of_scope": self.out_of_scope,
            "approach": self.approach,
            "milestones": list(self.milestones),
            "budget": self.budget,
        }


@dataclass(frozen=True)
class Assumption:
    """Varsayım defteri kaydı: seviye, gerekçe, güven, alternatif."""

    level: str
    decision: str
    rationale: str
    confidence: float
    alternative: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "level": self.level,
            "decision": self.decision,
            "rationale": self.rationale,
            "confidence": self.confidence,
            "alternative": self.alternative,
        }


def can_transition(current: str, target: str) -> bool:
    """Durum geçişi izinli mi?"""
    return target in ALLOWED_TRANSITIONS.get(current, set())


def validate_contract(contract: ProjectContract) -> list[str]:
    """Sözleşme bütünlük denetimi; eksik alan listesi döner."""
    missing: list[str] = []
    if not contract.title.strip():
        missing.append("title")
    if not contract.goal.strip():
        missing.append("goal")
    if not contract.success_criteria.strip():
        missing.append("success_criteria")
    if not contract.scope.strip():
        missing.append("scope")
    if not contract.approach.strip():
        missing.append("approach")
    return missing


def validate_assumption(assumption: Assumption) -> list[str]:
    """Varsayım bütünlük denetimi."""
    violations: list[str] = []
    if assumption.level not in AUTH_LEVELS:
        violations.append(f"geçersiz seviye: {assumption.level}")
    if not assumption.decision.strip():
        violations.append("decision boş")
    if not (0.0 <= assumption.confidence <= 1.0):
        violations.append("confidence 0-1 dışında")
    if assumption.level == "kirmizi":
        violations.append("kırmızı seviye varsayım olarak kaydedilemez; kullanıcı onayı gerekir")
    return violations
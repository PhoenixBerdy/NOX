"""Hafıza değerlendirme döngüsü: aday → PTBL değerlendirme → öneri (L6 derinleştirme).

Foundation §9: kullanıcı açısından anlamlı, gerekli ve izinli bilgiler.
Her aday PTBL ile ölçülür: kaynak, güven, kategori uyumu, kullanıcıya değer.
Çıktı: değerlendirme kartı + öneri (kabul/askı/reddet). Kullanıcı onayı gerekir.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

MEMEVAL_SYSTEM_PROMPT = """Bir hafıza değerlendirme yardımcısısın. Sana bir hafıza adayı verilecek.
Adayı PTBL ilkeleriyle ölç: kaynak güvenilirliği, içerik anlamı, kullanıcıya değeri, kategori uyumu.
Kesin hüküm verme; her eksende gerekçeni yaz.

Yanıtını SADECE şu 5 satırda ver; başka hiçbir şey yazma:

KAYNAK: <kaynak güvenilir mi, tek cümle>
ANLAM: <içerik anlamlı ve gerekli mi: EVET | KISMI | HAYIR>
DEGER: <kullanıcıya değeri: düşük | orta | yüksek>
KATEGORI: <kategori uygun mu: EVET | HAYIR>
ONERI: <kabul | askida | reddet>"""


@dataclass(frozen=True)
class MemoryEvalCard:
    source_ok: str
    meaningful: str
    value: str
    category_ok: str
    recommendation: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_ok": self.source_ok,
            "meaningful": self.meaningful,
            "value": self.value,
            "category_ok": self.category_ok,
            "recommendation": self.recommendation,
        }


def parse_memory_eval(model_output: str) -> MemoryEvalCard:
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("KAYNAK", "ANLAM", "DEGER", "KATEGORI", "ONERI"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    if "ONERI" not in fields:
        raise ValueError("Değerlendirme çıktısı ONERI içermiyor.")
    reco_map = {"kabul": "kabul", "askida": "askida", "reddet": "reddedildi"}
    return MemoryEvalCard(
        source_ok=fields.get("KAYNAK", ""),
        meaningful=fields.get("ANLAM", "KISMI"),
        value=fields.get("DEGER", "orta"),
        category_ok=fields.get("KATEGORI", "EVET"),
        recommendation=reco_map.get(fields["ONERI"], "askida"),
    )


def build_memory_eval_prompt(candidate: dict[str, Any]) -> list[dict[str, str]]:
    import json

    user = json.dumps({"aday": candidate}, ensure_ascii=False)
    return [
        {"role": "system", "content": MEMEVAL_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
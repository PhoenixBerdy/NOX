"""Örüntü birleştirme (recurrence): aynı/benzer gözlemler tek kayıtta toplanır.

Foundation: düşük değerli ya da belirsiz örüntü çöpe atılmaz; yeni örnekler,
karşı örnekler veya kendi deneyimleriyle yeniden değerlendirilir.

Kurallar (Seed v0, bilinçli olarak basit):
- Benzerlik, gözlem metinleri arasındaki kelime örtüşmesiyle ölçülür
  (Jaccard benzeri: ortak kelime / birleşim). Model kullanılmaz — denetlenebilir
  ve deterministiktir.
- Benzerlik >= THRESHOLD ise yeni satır açılmaz; mevcut adayın evidence listesine
  eklenir, 'recurrence' aşama kaydı düşülür ve güven sınırlı biçimde artar.
- Yalnızca 'candidate' durumundaki adaylar birleştirilir; active/archived
  kayıtlar kullanıcı kararıyla mühürlüdür.
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass

THRESHOLD = 0.6
CONFIDENCE_STEP = 0.05
CONFIDENCE_CAP = 0.9


@dataclass(frozen=True)
class MergeResult:
    """Birleştirme kararının sonucu."""

    merged: bool
    pattern_id: int | None  # birleşilen veya yeni açılan kayıt
    similarity: float
    recurrence_count: int


def _tokens(text: str) -> set[str]:
    return {t.strip(".,;:!?\"'()[]").lower() for t in text.split() if t.strip(".,;:!?\"'()[]")}


def similarity(a: str, b: str) -> float:
    """İki metin arasında Jaccard-benzeri kelime örtüşmesi (0.0 - 1.0)."""
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def find_similar_candidate(
    connection: sqlite3.Connection,
    observation: str,
    *,
    threshold: float = THRESHOLD,
) -> tuple[int, float, int] | None:
    """Aday (candidate) kayıtlar arasında en benzer olanı döndürür.

    Döner: (pattern_id, similarity, current_recurrence_count) veya None.
    """
    rows = connection.execute(
        "SELECT id, observation FROM patterns WHERE status = 'candidate'"
    ).fetchall()
    best: tuple[int, float, int] | None = None
    for row in rows:
        sim = similarity(observation, row["observation"])
        if sim >= threshold and (best is None or sim > best[1]):
            count = connection.execute(
                "SELECT COUNT(*) AS n FROM pattern_stages WHERE pattern_id = ? AND stage = 'recurrence'",
                (row["id"],),
            ).fetchone()["n"]
            best = (int(row["id"]), sim, int(count))
    return best


def apply_recurrence(
    connection: sqlite3.Connection,
    pattern_id: int,
    new_evidence: list[str],
    recurrence_count: int,
    now: str,
) -> float:
    """Mevcut adaya tekrar kanıtı ekler; kalibre güveni sınırlı artırır.

    Döner: yeni güven değeri.
    """
    row = connection.execute(
        "SELECT evidence_json, confidence FROM patterns WHERE id = ?",
        (pattern_id,),
    ).fetchone()
    evidence = list(json.loads(row["evidence_json"]))
    evidence.extend(new_evidence)
    new_confidence = min(
        CONFIDENCE_CAP,
        max(float(row["confidence"]), 0.4) + CONFIDENCE_STEP * (recurrence_count + 1),
    )
    connection.execute(
        "UPDATE patterns SET evidence_json = ?, confidence = ? WHERE id = ?",
        (json.dumps(evidence, ensure_ascii=False), new_confidence, pattern_id),
    )
    return new_confidence
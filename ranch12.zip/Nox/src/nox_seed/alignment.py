"""Hizalanma döngüsü: beklenti↔sonuç öz-yansıması (Blueprint B1 §7).

Her proje adımında Nox tahminini yazar; sonuçla karşılaştırır. Yanılma kaydı
PTBL verisidir — "Yanılmış olmak yüksek değerli öğrenme verisidir." (Foundation)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

REFLECT_SYSTEM_PROMPT = """Bir öz-yansıma yardımcısısın. Sana bir iş adımının tahmini ve gerçekleşen sonucu verilecek.
İkisini karşılaştır; dürüst ol. Yanılmak yüksek değerli öğrenme verisidir — saklama.

Yanıtını SADECE şu 4 satırda ver; başka hiçbir şey yazma:

ESLESME: <EVET | KISMI | HAYIR — tahmin sonuçla ne kadar örtüştü>
SAPMA: <neyi yanlış tahmin ettin veya YOK>
OGRENME: <bu yanılmadan çıkan ders, tek cümle>
GUVEN: <0.0 ile 1.0 arasında, bu değerlendirmeye güvenin>"""


@dataclass(frozen=True)
class ReflectionResult:
    """Beklenti↔sonuç karşılaştırmasının çıktısı."""

    match: str  # EVET | KISMI | HAYIR
    deviation: str
    lesson: str
    confidence: float

    def as_dict(self) -> dict[str, Any]:
        return {
            "match": self.match,
            "deviation": self.deviation,
            "lesson": self.lesson,
            "confidence": self.confidence,
        }


def parse_reflection(model_output: str) -> ReflectionResult:
    """4 etiketli satırı savunmacı biçimde ayrıştırır."""
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("ESLESME", "SAPMA", "OGRENME", "GUVEN"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    if "ESLESME" not in fields or "GUVEN" not in fields:
        raise ValueError("Yansıma çıktısı ESLESME veya GUVEN içermiyor.")
    match = fields["ESLESME"].upper()
    if match not in ("EVET", "KISMI", "HAYIR"):
        match = "KISMI"
    try:
        confidence = float(fields["GUVEN"])
    except ValueError:
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))
    deviation = fields.get("SAPMA", "")
    if deviation.upper() == "YOK":
        deviation = ""
    return ReflectionResult(
        match=match,
        deviation=deviation,
        lesson=fields.get("OGRENME", ""),
        confidence=confidence,
    )


def build_reflection_prompt(expectation: str, outcome: str) -> list[dict[str, str]]:
    import json

    user = json.dumps({"tahmin": expectation, "gerceklesen": outcome}, ensure_ascii=False)
    return [
        {"role": "system", "content": REFLECT_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Serialize, Deserialize)]
struct Project {
    id: i64,
    status: String,
    title: String,
    created_at: String,
}

#[tauri::command]
fn list_projects(db_path: String) -> Result<Vec<Project>, String> {
    let conn = Connection::open(db_path).map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT id, status, contract_json, created_at FROM projects ORDER BY id DESC LIMIT 20")
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![], |row| {
            let contract: String = row.get(2)?;
            let title = serde_json::from_str::<serde_json::Value>(&contract)
                .ok()
                .and_then(|v| v["title"].as_str().map(|s| s.to_string()))
                .unwrap_or_else(|| "(başlıksız)".to_string());
            Ok(Project {
                id: row.get(0)?,
                status: row.get(1)?,
                title,
                created_at: row.get(3)?,
            })
        })
        .map_err(|e| e.to_string())?;
    let mut projects = Vec::new();
    for p in rows {
        projects.push(p.map_err(|e| e.to_string())?);
    }
    Ok(projects)
}

#[tauri::command]
fn project_detail(db_path: String, project_id: i64) -> Result<serde_json::Value, String> {
    let conn = Connection::open(&db_path).map_err(|e| e.to_string())?;
    let contract: String = conn
        .query_row(
            "SELECT contract_json FROM projects WHERE id = ?1",
            params![project_id],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;
    let files_dir = PathBuf::from(&db_path)
        .parent()
        .unwrap()
        .join("projects")
        .join(project_id.to_string());
    let mut files = Vec::new();
    if files_dir.exists() {
        for entry in std::fs::read_dir(&files_dir).map_err(|e| e.to_string())? {
            let entry = entry.map_err(|e| e.to_string())?;
            files.push(entry.file_name().to_string_lossy().to_string());
        }
    }
    Ok(serde_json::json!({
        "contract": serde_json::from_str::<serde_json::Value>(&contract).unwrap_or_default(),
        "files": files,
    }))
}

#[derive(Serialize, Deserialize)]
struct Memory {
    id: i64,
    content: String,
    category: String,
    confidence: f64,
    status: String,
}

#[tauri::command]
fn list_memories(db_path: String, status: String) -> Result<Vec<Memory>, String> {
    let conn = Connection::open(&db_path).map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT id, content, category, confidence, status FROM memories WHERE (?1 = 'all' OR status = ?1) ORDER BY id DESC LIMIT 10")
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map(params![status], |row| {
            Ok(Memory {
                id: row.get(0)?,
                content: row.get(1)?,
                category: row.get(2)?,
                confidence: row.get(3)?,
                status: row.get(4)?,
            })
        })
        .map_err(|e| e.to_string())?;
    let mut memories = Vec::new();
    for m in rows {
        memories.push(m.map_err(|e| e.to_string())?);
    }
    Ok(memories)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![list_projects, project_detail, list_memories])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
# Nox

Nox, kullanıcısının bilgisayarında yaşayacak; zamanla öğrenen, karakteri olan ve geniş yetenekler kazanacak kişisel yapay zekâ ajanı projesidir.

## Şu an neredeyiz?

Nox’un ilk karakter ve öğrenme temeli belirlendi. Seed v0’ın ilk teknik iskeleti de hazır: yerel metin sohbeti, olay kaydı ve PTBL örüntü değerlendirmesi çalıştırılabilir durumda.

## İlk somut hedef: Nox Seed v0

Nox Seed v0, nihai Nox’un küçültülmüş bir sürümü değil; onun ilk çalışan çekirdeği olacak. İlk amacı, yerel bir metin arayüzünde konuşabilmek ve PTBL’nin örüntü fark etme / değerlendirme döngüsünü güvenilir biçimde denemek.

İlk sürümden sonra sistem sırasıyla sosyal örüntü algısı, öz-yansıma, internet araştırması, hafıza ve daha geniş bilgisayar yetenekleriyle büyüyecek.

## Başlatma

Ollama çalışırken proje klasöründe:

```powershell
$env:PYTHONPATH = "src"
python -m nox_seed demo
```

Bu, koyu temalı yerel sohbet ve PTBL Laboratuvarı içeren tek cihazlık Nox Seed demosunu açar. Ayrıntılı komutlar ve teknik sınırlar için [Seed v0 teknik iskeleti](docs/seed-v0.md) belgesine bak.

## Temel belgeler

- [Nox Foundation](docs/foundation.md): karakter, PTBL, proje sistemi, güvenlik ve evrim ilkeleri.
- [Platform Hedefi](docs/platform-target.md): bağımsız masaüstü uygulaması, tek Nox kimliği ve çoklu cihaz sürekliliği.
- [PTBL İlk Test Kümesi](docs/ptbl-test-plan.md): gözlem/yorum ayrımını sınayan Türkçe başlangıç örnekleri.
- [PTBL Kişilik Araştırması](docs/ptbl-personality-research.md): kaynak karakterlerden taklit yerine ilke çıkaran ilk kişilik sentezi.
- [Özel Konuşma Arşivi Politikası](docs/ptbl-private-corpus-policy.md): izinli yerel üslup/PTBL incelemesinin mahremiyet ve kullanım sınırı.
- [Yol Haritası](docs/roadmap.md): projeyi kurma ve büyütme sırası.
- [Güncel Durum](docs/current-state.md): model, donanım ve ilerleme notları.

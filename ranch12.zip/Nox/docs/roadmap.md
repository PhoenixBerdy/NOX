# Nox Yol Haritası

Katman haritası (L0-L9) ile ilk aşamaların birleşik görünümü. Her katmanın
ayrıntısı `BLUEPRINTS.md` ve `foundation.md` içindedir; bu dosya yalnızca
sıra ve durum gösterir.

## 0. Temel tasarım — TAMAMLANDI

Karakter çekirdeği, PTBL sosyal algısı, zaman damgası, puan haritası, öz-yansıma
ve özgün düşünce ilkeleri oluşturuldu. Ana belge: `foundation.md`.

## 1. Nox Seed v0 — TAMAMLANDI

Yerel bilgisayarda çalışan küçük Nox çekirdeği: konuşma, olay kaydı, PTBL
değerlendirme akışı. Teknik kılavuz: `seed-v0.md`.

## 2. L1 — PTBL Derinleştirme — TAMAMLANDI (13 Eylül 2026)

Kalite kapısı, güven kalibrasyonu, 15 vakalı regresyon fikstürü, üç aşamalı
boru hattı (fark et → anla → içselleştir), örüntü birleştirme, 8 eksenli puan
haritası. 42 test yeşil.

## 3. L2 — Project Core — TAMAMLANDI (13 Eylül 2026)

Proje sözleşmesi, yaşam döngüsü, varsayım defteri, kontrol noktaları, aç
bırakmayan öncelik kuyruğu, hizalanma döngüsü, izole proje klasörü + güvenlik
kapısı ilk sürümü. 4 proje üretildi, 1 oyun oynandı. Ayrıntı: `BLUEPRINTS.md` Bölüm 1.

## 4. L3 — Platform alfa — TAMAMLANDI (13 Eylül 2026)

Tauri masaüstü uygulaması: sol ray + merkez sohbet + sağ kayar panel, streaming,
SQLite köprüsü, markdown desteği. Ollama'sız çalışma (llama.cpp GGUF + NOX
localhost sunucusu). Ayrıntı: `BLUEPRINTS.md` Bölüm 3.

## 5. L4 — Güvenlik kapısı — TAMAMLANDI (13 Eylül 2026)

Eylem sınıflandırması (yeşil/lime/sarı/kırmızı), izole klasör denetimi,
kullanıcı onayı akışı. Canlı kanıt: klasör dışı yazma engellendi.

## 6. L5 — İnternet erişimi (ilk adım) — TAMAMLANDI (13 Eylül 2026)

Kontrollü okuma: domain izin listesi, kullanıcı onayı, içerik sınırı.
PTBL internet örüntüleri: okunan metinden aday üretme (canlı kanıt).

## 7. L6 — Hafıza — TAMAMLANDI (14 Eylül 2026)

Kalıcı kişisel hafıza (aday → değerlendirme → kabul/askı/reddet/arşiv akışı),
kayıt, kullanım, otonom aday üretimi, değerlendirme döngüsü, platformda görünürlük,
proje akışında kullanım (sözleşme #5). Ayrıntı: Foundation §9.

## 8. L7 — Çoklu cihaz — TAMAMLANDI (14 Eylül 2026)

NOX sunucusu: host parametresi, token denetimi, IP izin listesi, cihaz erişim kaydı,
cihaz yetki seviyesi (salt-okunur | ileti | onay | tam), cihaz yönetimi (register/list/revoke),
eşzamanlılık (olaylar cihaz kimliğiyle). Canlı kanıt: salt-okunur cihaz POST engellendi.
Ayrıntı: `BLUEPRINTS.md` Bölüm 4.

## 9. L8 — Evrim iskeleti + üretimi — TAMAMLANDI (14-15 Eylül 2026)

Pasiflik ölçütü (4 sinyal), reseptör (aynı fikir tanıma), aday değerlendirme
(PTBL kartı), otonom aday üretimi (pasiflikte Nox kendi kendine fikir üretti),
otonom döngü (`evolve --auto`), daemon (`evolve --daemon`), öz-iyileştirme
(`evolve --self-improve`), test üretimi (`evolve --write-test`).
Canlı kanıt: "Almanca A1 Sözlük Oyunu" fikri üretildi, değerlendirildi, arşivlendi.
Ayrıntı: `BLUEPRINTS.md` Bölüm 2.

## 10. L9 — Final — TAMAMLANDI (14 Eylül 2026)

Taşınabilir paket: `export` komutu (22 dosya) + `export --final` (50 dosya, 4.89 GB
Tauri bundle + model + config + docs + kurulum kılavuzu). Manifest + doğrulama temiz.
Almanya hazırlığı.

## 11. W5 — Medya üretimi — İSKELET [ERTELENDİ] (14 Eylül 2026)

`media_gen.py` hazır (Stable Diffusion API bağlantısı, güvenlik kapısı).
LocalAI kurulumu ertelendi (platform aşamasında değerlendirilecek).

## 12. PTBL genişleme — DEVAM EDİYOR (14 Eylül 2026)

Kullanıcı modeli (kısa mesaj oranı, konular, aktif saatler — açık kayıt).
Canlı kanıt: kullanıcının ritmi çıkarıldı.
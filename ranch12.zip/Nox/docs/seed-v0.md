# Nox Seed v0 — Teknik İskelet

## Seçimler

- **Dil:** Python 3.11+; harici çalışma zamanı bağımlılığı yoktur.
- **Yerel model:** Ollama üzerinden `qwen3:4b-instruct` (geçiş dönemi iskelesi).
- **Arayüz:** Terminal tabanlı REPL/CLI ve koyu temalı yerel masaüstü Seed demosu.
- **Kalıcı kayıt:** Yerel SQLite. Olaylar, PTBL örüntüleri, aşama kayıtları ayrı tablolardadır.

## Klasör yapısı

```text
src/nox_seed/       Seed v0 uygulaması
  cli.py            CLI/REPL komutları
  config.py         Ortam ayarları
  database.py       SQLite olay/örüntü/aşama deposu
  demo.py           Tk masaüstü demosu
  models.py         PatternAssessment, StoredPattern
  ollama.py         Model istemcisi + 1. aşama parser + kalite kapısı/kalibrasyon
  ptbl_pipeline.py  2. (anlamak) ve 3. (içselleştirmek) aşamalar
  recurrence.py     Örüntü birleştirme
  scorecard.py      8 eksenli puan haritası
tests/              Model gerektirmeyen doğrulama testleri (+ canlı mod)
data/               Çalışırken oluşan, Git'e alınmayan yerel SQLite verisi
docs/               Tasarım ve durum belgeleri
```

## Çalıştırma

```powershell
$env:PYTHONPATH = "src"
python -m nox_seed init
python -m nox_seed repl
python -m nox_seed demo
```

## PTBL komutları

```powershell
python -m nox_seed assess "Metin"            # 1. aşama: aday örüntü
python -m nox_seed understand 1 "Kaynak"     # 2. aşama: anlama kartı
python -m nox_seed internalize 1             # 3. aşama: içselleştirme önerisi
python -m nox_seed approve 1 active          # kullanıcı onayıyla durum geçişi
python -m nox_seed score 1                   # 8 eksenli puan haritası
python -m nox_seed patterns                  # son örüntüler
python -m nox_seed events                    # son olaylar (hata kayıtları dahil)
```

Durum değerleri: candidate (varsayılan) → active | context-bound | archived.
Öneri otomatik uygulanmaz; geçiş `approve` iledir.

## Testler

```powershell
python -m unittest discover -s tests         # 42 test (Ollama gerekmez)
$env:NOX_PTBL_LIVE = "1"
python -m unittest tests.test_ptbl_regression -v   # canlı model karnesi
```

## Ortam değişkenleri

`NOX_MODEL`, `NOX_OLLAMA_URL`, `NOX_DB_PATH`, `NOX_CONTEXT_TOKENS`,
`NOX_MAX_OUTPUT_TOKENS`, `NOX_ASSESSMENT_MAX_OUTPUT_TOKENS`,
`NOX_STAGE_MAX_OUTPUT_TOKENS`, `NOX_REQUEST_TIMEOUT_SECONDS`, `NOX_PTBL_LIVE`.

## Seed v0 sınırı

Nox Seed v0 yalnızca metinle konuşur ve PTBL değerlendirmesini yerel olarak
kaydeder. Model çıktısı gerçek kabul edilmez. Sistem interneti taramaz, dosya
değiştirmez, proje yürütmez ve kendi kodunu değiştirmez.
# Nox Platform Hedefi

Bu belge, Foundation’daki çoklu cihaz ilkesini mimari hedefe çevirir. Uygulama planı değildir; Seed v0’ın ileride hangi yöne büyüyeceğini netleştirir.

## Kullanıcı deneyimi hedefi

Kullanıcı Nox ile ana bilgisayarındaki masaüstü uygulamasından konuşurken telefondan aynı konuşmayı açabilmelidir. Telefonda gönderdiği mesaj, masaüstünde görünen aynı geçmişe eklenir. Nox’un proje durumu, bekleyen onayı ve uygun bildirimleri de iki cihazda aynı gerçekliğin farklı görünümleridir.

Kullanıcı cihaz değiştirdiğinde Nox’u “yeniden anlatmak” zorunda kalmaz. Bunun anlamı, Nox’un bütün verisinin her cihaza açıkça kopyalanması değil; kullanıcının denetiminde olan aynı çekirdeğin doğru parçasına güvenli erişim sağlanmasıdır.

## Hedef mimari

```text
Masaüstü uygulaması ─┐
Telefon eşlikçisi ───┼── şifreli istemci bağlantısı ── Nox Core / ana düğüm
İkinci bilgisayar ───┘                                  ├─ olay günlüğü
                                                          ├─ hafıza ve politika
                                                          ├─ proje yürütücüsü
                                                          └─ yerel model ve araç kapısı
```

**Nox Core**, tek kimlik ve kanonik durumun sahibidir. İstemciler kullanıcı girdisini ve onayını taşır; çekirdek ise güvenlik kararını, hafıza yazımını, proje durumunu ve mümkün olduğunda model yürütmesini yapar.

## Veri sürekliliği ilkeleri

- Sohbet ve proje olayları silip-yazan kayıtlar değil, zaman damgalı eklemelerdir.
- Her olay bir cihaz ve oturum bilgisi taşır; eşzamanlı girdiler korunur.
- Hafıza yazımı aday → değerlendirme → kabul/askı akışından geçer.
- İstemci önbelleği en az veri ilkesiyle çalışır; kullanıcı hangi verinin telefonda bulunabileceğini denetler.
- Çevrim dışı girdiler kuyrukta saklanır; yeniden bağlanınca tekrar gönderim ve çakışma denetimi yapılır.
- Yedekler şifreli, geri yükleme süreci doğrulanabilir olur.

## Cihaz yetki modeli

Her cihazın ayrı bir kimliği, görünür bir erişim kaydı ve geri alınabilir yetkileri vardır:

| Yetki | Örnek |
| --- | --- |
| Salt-okunur | Sohbet geçmişi ve proje durumunu görüntüleme |
| İleti gönderebilir | Nox’a mesaj ve proje güncellemesi iletme |
| Onay verebilir | Ana düğümde bekleyen açık onayı imzalama |
| Tam denetim | Yalnızca kullanıcının ana masaüstü uygulaması |

Her istemci, red-line politikasını ve güvenlik kapısını aşmadan çalışır. Eylem nereden başlatılırsa başlatılsın, karar ana çekirdekte kayda ve yetkiye bağlanır.

## Seed v0 için sonuç

Seed v0 bu hedefi uygulamaz; ancak SQLite olay modelini gelecekteki sürekliliğe engel olmayacak biçimde kurar. Bir sonraki somut platform adımı mobil uygulama değil, masaüstü uygulamasının hangi yerel API ve olay sözleşmesiyle çekirdeğe bağlanacağını tasarlamaktır.

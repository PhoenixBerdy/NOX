# NOX — TAM DURUM RAPORU (Revize)
**Tarih:** 12-13 Eylül 2026 · **Derleyen:** n8n Instance Agent (teknik direktör)

## 1. Bugün yapılanlar (12 Eylül akşamı — 13 Eylül gece yarısı)

### Kod değişiklikleri
- **demo.py:** İptal edilen Satürn simgesi kaldırıldı; metin işareti "◒" kullanılıyor.
  Streaming, mesaj kuyruğu ve tema davranışı değişmedi.
- **ollama.py — PTBL kalite kapısı:** evidence veya unknowns boşsa güven ≤ 0.4.
  ("uyumayı bırakmak" anlamsal hatasının tekrarını engelleyen ilk savunma hattı.)
- **ollama.py — güven kalibrasyonu:** Modelin öz-değerlendirmesi kalibre değildir
  (canlı karne: 14 vakanın 12'sinde 0.90+ güven). Yeni tavanlar:
  1 bilinmeyen → ≤ 0.7 · 2+ bilinmeyen → ≤ 0.85 · muğlaklık sinyali → ≤ 0.75.
- **ollama.py — pattern_type enum genişledi:** topluluk, davranış eklendi.
- **ptbl_cases.json:** 5 → 15 vaka. Yeni risk sınıfları: ironi, kişisel teşhis tuzağı,
  argoda zaman bağlamı, çoklu örüntü, "uyumayı bırakmak" regresyon vakası, genelleme
  tuzağı, kuru mizah, davranış değişimi zaman dizisi, güvenlik kırmızı çizgisi,
  olumlu özellik atfetme tuzağı.
- **test_ptbl_regression.py (YENİ):** Model çıktısını PTBL ilkelerine karşı denetler:
  yasaklı çıkarım kalıpları (olumsuzlama duyarlı), boş unknowns, güven tavanı,
  boş observation. Mock modu her yerde; NOX_PTBL_LIVE=1 ile canlı karne.
- **test_ollama.py:** Kalibrasyona uyarlandı + 3 yeni kalibrasyon testi.

### İlk canlı PTBL karnesi (12 Eylül 2026)
- Model: qwen3:4b-instruct, 14 vaka, 164 saniye.
- **Sınır disiplini temiz:** yasaklı kalıp ihlali YOK, boş unknowns YOK, boş observation YOK.
- **Güven hastalığı var:** 12/14 vakada tavan aşımı (hep 0.90-0.95).
- Sonuç: kalibrasyon katmanı kod tarafında eklendi; model hâlâ 0.95 diyor ama kayda
  kalibre değer geçiyor. Gerçek çözüm (modelin kendi kalibre güveni) üç aşamalı
  boru hattıyla gelecek.

### Temizlik
- nox-saturn-icon.png silindi.
- İkinci NOX kopyası karmaşası çözüldü; ana kopya: C:\Users\Yağız Cem\Documents\Projects\Nox

### Test durumu
- `python -m unittest discover -s tests` → Ran 15 tests, OK (skipped=1)

## 2. Seed v0'ın mevcut yetenek sınırı
Yerel sohbet (streaming + kuyruk + kısa mesaj bütçesi), SQLite olay/örüntü kaydı,
tek atışlık PTBL değerlendirmesi + kalite kapısı + kalibrasyon. Başka yetki yok:
internet yok, dosya eylemi yok, proje yürütücüsü yok, kalıcı hafıza çıkarımı yok.

## 3. L1 kalan işler (PTBL Derinleştirme)
1. Üç aşamalı boru hattı: fark et (var) → anla (karşı-örnek, kaynak/zaman/topluluk
   bağlamı) → içselleştir (candidate → active/archived yaşam döngüsü)
2. Örüntü birleştirme: aynı/benzer gözlemlerin tekrar kanıt olarak tek kayıtta toplanması
3. 8 eksenli puan haritası: belirginlik, özgünlük, kanıt gücü, bağlam derinliği,
   zaman canlılığı, karakter rezonansı, işlevsel katkı, çelişki yoğunluğu

## 4. Açık kararlar (kullanıcı bekleniyor)
1. Nihai model katmanı (Ollama'sız dünya) — L3 öncesi şart
2. Kişilik değerlendirme oturumu (4 soruluk demo sözleşme testi) — yapıldı mı?
3. Yeni logo yönü — platform aşamasına mı ertelendi?
4. Eğitim müfredatı listesi — zamanı geldi mi?

## 5. Çalışma düzeni notları
- Teslimler TAM DOSYA olarak; kopyala-yapıştır. Uzun dosyalar parçalanır.
- Canlı model testleri kullanıcının makinesinde koşar.
- Kredi sınırlı: tek seferlik paketler + somut soru-cevaplar.
- Kullanıcının kendi metinleri birincil kaynaktır; asistan raporları değil.
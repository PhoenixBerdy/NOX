# Nox Foundation 2.1 — Uygulanabilirlik, Güvenlik ve Evrim Çerçevesi

Bu belge, `foundation2.md` içindeki yeni yönleri Nox’un ana ilkeleriyle uyumlu, aşamalı ve denetlenebilir bir çerçeveye bağlar. Nox’un vizyonunu küçültmez; erken sürümlerin kaldıramayacağı yetkileri ve karmaşıklığı doğru zamana taşır.

Bu belge henüz ana Foundation’ın parçası değildir. Birleştirme, kullanıcı tarafından gözden geçirildikten sonra yapılır.

## 1. Öncelik ilkesi: çekirdek önce, özerklik sonra

Nox’un nihai hedefi; araştıran, üreten, öğrenen ve birden fazla projeyi yürütebilen kişisel bir ajandır. Bunun güvenilir temeli önce küçük ölçekte kanıtlanmalıdır.

Her yeni yetenek şu sırayla olgunlaşır:

1. Gözlenir: Nox yalnızca öneri, taslak veya kayıt üretir.
2. Taslak eylem üretir: Eylem planını ve beklenen sonucu kullanıcıya sunar.
3. Onayla yürütür: Dar kapsamlı eylemi açık kullanıcı onayıyla gerçekleştirir.
4. Sınırlı özerklik kazanır: Tekrarlanabilir, düşük riskli ve test edilmiş eylemleri tanımlı sınırlar içinde yürütür.

Hiçbir özellik yalnızca etkileyici göründüğü için özerkliğe geçmez. Geçiş için ölçülebilir başarı, hata kaydı, geri alınabilirlik ve uygun güvenlik denetimi gerekir.

## 2. Proje odaklı çalışma sistemi

Nox, sırayla cevap veren tek iş parçacıklı bir sohbet penceresi olmamalıdır. Kullanıcı bir proje verir, Nox proje hakkında ilk anlayışını ve taslağını görünür kılar; ardından iş, kullanıcı yeniden yazmasa da güvenli sınırları içinde ilerler. Bu sırada kullanıcı Nox ile konuşmaya, yeni proje açmaya veya çalışan projenin yönünü değiştirmeye devam eder.

Bu, “Nox aynı anda her şeyi düşünür” anlamına gelmez. Proje merkezli çalışma, kalıcı durum, kısa çalışma dilimleri, açık öncelik kuralları ve kullanıcıya açık bir kontrol yüzeyi demektir.

### 2.1 Üç ayrı akış

Nox’un arayüzü tek olsa da arka planda üç farklı türde iş vardır:

1. **Canlı sohbet akışı:** Kullanıcının yeni mesajı hızla karşılanır. Mesaj bir soru, mevcut proje için yönlendirme veya yeni proje isteği olabilir.
2. **Proje akışı:** Uzun süren araştırma, tasarım, kodlama, dosya üretimi ve doğrulama adımlarına bölünmüş kalıcı iştir.
3. **Sistem akışı:** Kuyruk, kaynak bütçesi, kayıt, güvenlik denetimi, bildirim ve hata toparlama işlerini yürütür. Bu katman modelin keyfî metin yorumuna bırakılmaz.

Canlı sohbet akışı, uzun bir projenin arkasında sıraya girmez. Ancak o anda çalışan yerel model üretimi tek seferde durdurulamayabilir. Bu nedenle arka plan işi, mümkün olduğunca kısa model çağrılarına ve güvenli kontrol noktalarına bölünür; her dilimden sonra Nox gelen kutusunu ve kuyruk kararlarını kontrol eder.

### 2.2 Projenin sözleşmesi ve örtük başlatma yetkisi

Kullanıcı “ineğe tıklayarak insanları eğlendiren bir oyun oluştur” dediğinde Nox, bunu salt sohbet yanıtı gibi tüketmez. İlk hızlı yanıtı bir **proje sözleşmesi** olur:

- hedeflenen çıktı ve başarı ölçütü;
- ilk kapsam ve kapsam dışı kalanlar;
- uygulanacak teknoloji veya araştırma yaklaşımı;
- açıkça bilinen varsayımlar ve bunların güven düzeyi;
- beklenen ara kilometre taşları;
- kullanacağı yerel kaynaklar ve eylem yetkisi;
- hangi koşulda kullanıcıyı bekleyeceği.

Bu sözleşme, bilgi vermek için gösterilen bir taslak ve çalışma günlüğünün ilk kaydıdır; varsayılan durumda ayrı bir “başla” onayı istemez. Kullanıcı talebi yeterince açık ve eylem düşük riskliyse Nox sözleşmeyi yayınladıktan sonra kodlama/araştırma adımlarına geçer. Kullanıcı bu sırada kapsamı değiştirebilir, durdurabilir veya başka bir iş verebilir.

Şu durumlar örtük başlatma yetkisinin dışındadır ve Nox’u beklemeye geçirir: geri alınamaz silme ya da büyük dosya üzerine yazma, dışarıya veri gönderme/yayınlama, hesap/giriş/ödeme kullanma, güvenlik veya gizlilik riski, belirsiz hedef klasörü, ya da seçeneğin sonucu anlamlı biçimde değiştirdiği kararlar.

### 2.3 Proje yaşam döngüsü

Her proje, konuşma geçmişinden bağımsız kalıcı bir kayda ve durum makinesine sahiptir:

```text
taslak → sözleşme yayımlandı → sırada → çalışıyor → doğrulanıyor → tamamlandı
                                  ↘             ↗
                              duraklatıldı   yeniden planlanıyor
                                  ↘
                         kullanıcı girdisi bekliyor / engellendi / iptal edildi
```

- **Taslak:** Nox isteği projeye dönüştürüp temel bilgileri çıkarır.
- **Sözleşme yayımlandı:** İlk plan kullanıcıya görünür, varsayımlar kayda geçer ve güvenli çalışma yetkisi tanımlanır.
- **Sırada:** Proje çalışmaya hazırdır, fakat kaynak veya öncelik sırası beklemektedir.
- **Çalışıyor:** Bir sonraki küçük adım yürütülür; durum kalıcı kayda yazılır.
- **Doğrulanıyor:** Çıktı, proje sözleşmesindeki başarı ölçütleriyle karşılaştırılır.
- **Kullanıcı girdisi bekliyor:** Yalnızca gerçek bir karar, yetki veya bilgi eksikliği ilerlemeyi engelliyorsa kullanılır.
- **Duraklatıldı / yeniden planlanıyor:** Yeni talep, hata veya bütçe sınırı sonrası iş güvenli kontrol noktasında korunur.
- **Tamamlandı / engellendi / iptal edildi:** Sonuç, kanıtı ve varsa sonraki öneriyle kapanır.

Her durum değişimi; neden, zaman, kullanılan kaynak, ilgili dosyalar, kaynaklar ve üretilen ara çıktıyla kaydedilir. Böylece Nox kapansa veya bilgisayar yeniden başlasa proje “nerede kaldığını” tahmin etmez; kayıttan devam eder.

### 2.4 Çalışma dilimi ve kontrol noktası

Bir proje “araştırma yap” gibi belirsiz, uzun bir model çağrısı çalıştırmaz. İş; araştırma planı, kaynak toplama, kaynak notu, taslak, uygulama parçası, test ve değerlendirme gibi küçük adımlara ayrılır.

Her adımın başında Nox şunları kaydeder: girdi özeti, amaç, bütçe, yazma yetkisi ve beklenen çıktı. Adımın sonunda ise ara çıktıyı, hata durumunu ve bir sonraki adımı kaydeder. Bu kayıt bir **kontrol noktasıdır**.

Bu ayrım iki kritik sonuç verir:

- Kullanıcı yeni mesaj gönderdiğinde Nox, uzun projenin bağlamını kaybetmeden hızlıca sohbet akışına dönebilir.
- Acil bir kısa iş, ilk projenin bitmesini beklemez; mevcut adımın güvenli kontrol noktasında öne alınır.

Model üretimi sırasında zorla kesmek kalite kaybına veya yarım dosyaya neden olabileceğinden, tercih edilen yöntem iptal etmek değil kısa adımlar tasarlamaktır. İptal gerektiğinde Nox son güvenli kontrol noktasına döner; yarım sonucu tamamlanmış diye sunmaz.

### 2.5 Örnek: Stardew rehberi ile Almanca kelime listesi

Kullanıcı önce tüm başarımlar için kapsamlı bir Stardew Valley rehberi ister. Nox sözleşmeyi yayımlar, rehberi araştırma ve bölüm tasarımı adımlarına böler, ilk kaynak ve kapsam notlarını kaydeder. Araştırma sürerken kullanıcı Almanca hazırlık sınavı için acil kelime listesi ister.

Nox yeni isteği canlı sohbette hemen karşılar; bunu ayrı bir proje veya kısa iş olarak kaydeder. “Acil” işaretini kullanıcı verdiği için kelime listesi bir sonraki kontrol noktasında Stardew işinin önüne geçer. Liste oluşturulup doğrulandıktan sonra Stardew projesi, kaydedilmiş özet ve kaynaklardan kaldığı yerden devam eder. Kullanıcı iki projenin de durumunu, varsayımlarını ve sıradaki adımını görebilir.

Kullanıcı ayrıca “Stardew rehberindeki oyun sürümünü 1.6 kabul et” gibi bir güncelleme verirse bu, var olan projeye zaman damgalı bir olay olarak eklenir. Nox sadece etkilenen bölümleri yeniden planlar; tüm geçmişi veya başka projeleri gereksiz yere sıfırlamaz.

### 2.6 Önceliklendirme: açıklanabilir, değiştirilebilir, aç bırakmayan kuyruk

Kullanıcının açık öncelik emri her zaman baskındır. Nox’un önerdiği sırada ise ilk sürüm için aşağıdaki sinyaller kullanılır:

- kullanıcının verdiği aciliyet ve varsa son tarih;
- bekletmenin maliyeti veya başka işi engelleyip engellemediği;
- kullanıcıya tahmini değer ve tamamlanmaya yakınlık;
- bağımlılıkların hazır oluşu;
- tahmini süre, model/bellek ihtiyacı ve mevcut kaynak bütçesi;
- ne kadar süredir beklediği.

Bu sinyaller tek bir gizli “doğru puan”a dönüştürülmez. Nox, örneğin “Kelime listesi kullanıcı tarafından acil işaretlendiği için öne alındı; Stardew araştırması kayıpsız duraklatıldı” diyebilmelidir. Uzun işler sürekli kısa işlerin gerisine atılarak aç bırakılmaz: bekleme süresi arttıkça önceliği artar ve her projeye ilerleme fırsatı verilir.

Başlangıçta kullanıcı; önceliği elle değiştirebilir, projeyi sabitleyebilir, duraklatabilir, iptal edebilir ve kaynak bütçesini görebilir. Nox’un otomatik önerisi yardımcıdır; kullanıcının iradesinin yerine geçmez.

### 2.7 Eşzamanlılık: mantıksal paralellik, fiziksel sınır

Beş veya altı bağımsız proje aynı anda **açık** olabilir: her birinin durumu, kuyruğu, dosyaları ve sonraki adımı korunur. Bu, beş veya altı yerel modelin aynı anda üretim yapacağı anlamına gelmez.

Mevcut hedef donanımda (`qwen3:4b-instruct`, 4 GB VRAM, 16 GB RAM) başlangıç varsayımı tek model üretim hattıdır. Kullanıcı sohbeti ve arka plan projeleri bu hattı kısa dilimler hâlinde paylaşır. Ağ bekleme, dosya doğrulama veya kayıt gibi model gerektirmeyen işler sınırlı ayrı yürütülebilir; fakat aynı kaynak veya dosya üzerinde iki yazma işi eşzamanlı çalışmaz.

Bu yaklaşım kullanıcıyı kilitlemeden çalışır ve belleği taşırmaz. Gerçek paralellik, yalnızca ölçümlerde gecikme, bellek, sıcaklık ve hata oranı kabul edilebilir kaldığında artırılır. “Hızlı yanıt” hedefi daha hızlı modelden çok; kısa adımlar, hazır proje özeti, doğru kuyruk ve canlı sohbet önceliğiyle sağlanır.

### 2.8 Varsayım defteri ve soru sorma disiplini

Nox, her belirsizlikte çalışmayı durdurmaz. Düşük riskli, geri alınabilir ve kolayca değiştirilebilir belirsizliklerde makul varsayımı açıkça kaydeder, güven derecesini belirtir ve ilerler. Örneğin oyun projesinde ilk ekranın tek oyunculu, web tabanlı bir prototip olması böyle bir varsayım olabilir.

Ancak varsayım sonuç, güvenlik, maliyet, hedef dosyalar veya kullanıcı tercihi üzerinde büyük etki yaratıyorsa Nox sorar ve o bağımlı adımı bekletir. Soru beklerken bağımsız adımlar sürdürülür: örneğin hedef platform belirsizken oyun mekanik taslağı ve test senaryoları hazırlanabilir; yayın hesabı veya ödeme kararı alınamaz.

Her varsayım; kaynak, gerekçe, güven düzeyi, hangi proje adımını etkilediği ve kullanıcı daha sonra farklı bir tercih verirse neyin yeniden planlanacağıyla saklanır.

### 2.9 Kullanıcı görünürlüğü ve bildirim eşiği

Nox arka planda “gizlice tamamlıyor” izlenimi vermemelidir. Kullanıcı her proje için hedefi, güncel durumu, son kontrol noktasını, sıradaki adımı, kaynak bütçesini, bekleme nedenini ve gerekli onayları görebilir.

Bildirim yalnızca anlamlı olaylarda gönderilir: sözleşme yayımlandığında, kullanıcı kararı gerektiğinde, bir kilometre taşı oluştuğunda, hata/engelleme olduğunda veya proje tamamlandığında. Her küçük adım için bildirim üretmek hem dikkat dağıtır hem de proje odağını bozar.

### 2.10 Seed v0’dan bu mimariye geçiş

Bu çalışma biçimi Nox’un ana hedefidir, fakat Seed v0’ın tamamı değildir. Aşamalı geçiş şöyledir:

1. **Seed v0:** Yerel sohbet, olay/örüntü kaydı ve basit proje kaydı. Projeler henüz arka planda yürütülmez.
2. **Project Core:** Proje sözleşmesi, yaşam döngüsü, varsayım defteri, kalıcı kontrol noktası ve görünür durum ekranı eklenir.
3. **Tek hatlı yürütücü:** Bir proje adımını bir seferde yürüten, kullanıcı mesajını kontrol noktalarında öne alan dayanıklı kuyruk eklenir.
4. **Sınırlı araçlar:** İzole proje klasöründe kod/dosya üretimi, test ve kullanıcı onayına bağlı araçlar eklenir.
5. **Ölçülmüş genişleme:** Bağımsız I/O işleri, birden fazla yürütücü ve çoklu cihaz kullanımı yalnızca ölçülmüş kaynak ve güvenlik sınırlarıyla eklenir.

Bu sırayla Nox, erken aşamada Codex ölçeğini taklit etmeye çalışmadan onun değerli ilkesini alır: uzun iş ilerlerken kullanıcıyla ilişki kopmaz; belirsiz ama güvenli noktada makul varsayımla devam edilir, anlamlı sonuç doğuran kararlarda ise beklenir.

## 3. Güvenlik zekâsı: ayrı sorumluluk, tek politika

Güvenlik, Nox’un sonradan hatırlayacağı bir karakter özelliği değil; eylem kapısında çalışan zorunlu bir katmandır. Karar veren model, güvenlik katmanını devre dışı bırakamaz, kendi kurallarını değiştiremez veya kendi izinlerini genişletemez.

Güvenlik katmanı üç parçadan oluşur:

1. **Değişmez çekirdek politika:** Açıkça yasaklanmış eylemler ve temel mahremiyet ilkeleri. Bu kurallar sürüm kontrollü, insan tarafından değiştirilebilir ve Nox tarafından değiştirilemezdir.
2. **Risk sınıflandırması:** Görev, hedef, veri türü ve eylem türü için düşük/orta/yüksek risk değerlendirmesi yapar. Modelden gelen yorum bir sinyaldir; tek karar kaynağı değildir.
3. **Yetki kapısı:** Eyleme göre izin, sandbox, salt-okunur çalışma, kullanıcı onayı veya engelleme uygular. Her kararın gerekçesi kaydedilir.

### Davranış sınıfları

PTBL ile elde edilen gözlemler, güvenlik politikasıyla karıştırılmaz. Bir davranışın yaygın veya ilginç olması onu güvenli yapmaz.

- **Kırmızı davranışlar:** Kullanıcı onayı olsa bile gerçekleştirilmez. Örnek: zararlı faaliyetler, kimlik bilgisi toplama, izinsiz erişim, gizlilik ihlali veya güvenlik kontrolünü atlatma.
- **Gri davranışlar:** Açık, bağlama özel kullanıcı onayı; görünür plan ve kaydedilmiş sonuç gerektirir. Örnek: internetten içerik indirme, yerel dosyalarda değişiklik, dış hizmete veri gönderme.
- **Sarı davranışlar:** Düşük riskli fakat dikkat/harcama/itibar etkisi olabilecek eylemler. Önceden bildirim veya sonradan özet kuralı uygulanabilir.
- **Yeşil davranışlar:** Yerel, geri alınabilir ve düşük riskli eylemler. Tanımlı yetki sınırında yürütülebilir.

Paywall, giriş gerektiren hizmetler, yaş/konum sınırlı içerikler ve şüpheli siteler yalnızca modelin tahminiyle aşılmaz. Nox erişim kısıtını görürse durur; yasal ve açık bir erişim yolu varsa kullanıcıya sunar, yoksa alternatif kaynak arar.

### Çekirdek kırmızı çizgiler ve değişen davranış etiketleri

Nox’un değişmez kırmızı çizgileri; kısa, sürüm kontrollü bir politika paketi olarak eylem katmanlarına dağıtılır. Bu paketin yorumunu, güvenlik denetimini ve uygulamasını yapan parçalar aynı ilkeye bağlıdır; Nox bu paketi kendi kararıyla değiştiremez veya yeniden sınıflandıramaz.

Buna karşılık PTBL’den doğan sosyal davranış etiketleri zamanla değişebilir. Nox bir davranışı kırmızı/gri/sarı aday olarak gözlemleyip kanıt ve bağlamıyla yeniden değerlendirebilir; fakat bu sınıflandırma değişmez güvenlik politikasını gevşetemez. Böylece öğrenme esnek kalırken temel sınırlar korunur.

## 4. Optimizasyon zekâsı: kendi kendini değiştirme değil, ölçüm temelli iyileştirme

Nox’un optimizasyonu ayrı bir irade veya serbestçe kod değiştiren bir ajan değildir. Görevi; darboğazları ölçmek, seçenekleri karşılaştırmak ve güvenli iyileştirme önerileri üretmektir.

Her öneri için şu kanıtlar istenir:

- hedef ölçüm: gecikme, bellek, GPU/RAM kullanımı, enerji, hata oranı veya çıktı kalitesi;
- tekrar edilebilir karşılaştırma testi ve başlangıç değeri;
- beklenen fayda ve olası gerileme;
- geri alma planı;
- etkilenen veri, yetki ve güvenlik sınırları.

Nox’un kendi çalışma kodunu, güvenlik politikasını veya hafıza şemasını değiştiren öneriler varsayılan olarak insan onayı, ayrı test ortamı ve geri dönüş planı gerektirir. Başarısız değişiklik silinmeden önce askıya alınır ve neden başarısız olduğu kaydedilir.

Optimizasyon katmanı gerekirse başka, dar yetkili bir değerlendirme işini veya uzmanlaştırılmış aracı çağırabilir; ancak bu ikinci görüş yeni bir yetki kaynağı değildir. Aday özellik yalnızca ölçümlü testleri geçerse sınırlı kullanıma açılır, geçmezse askıda kalır ve iyileştirme önerisiyle birlikte korunur.

### Sis mekanizmasının yerine: çalışma bütçeleri ve katmanlı bağlam

“Sis” fikri, Nox’un bir anda her şeyi aktif tutmamasını hedeflediği için değerlidir. Teknik karşılığı şunlardır:

- aktif görev bağlamı: o anda gereken kısa, doğrulanmış bilgi;
- proje özeti: duraklatılan işin devamı için yeterli sıkıştırılmış durum;
- kalıcı kayıt: kaynaklar, kararlar, dosya konumları ve ayrıntılı geçmiş;
- çalışma bütçesi: görev başına zaman, token, bellek ve paralellik limiti.

Bu düzen, unutmak değil; ayrıntıyı kaybetmeden doğru düzeye indirmektir. Bir proje yeniden açıldığında Nox önce proje özetini, gerekirse asıl kaydı yükler.

## 5. Evrim ve yetenek kazanımı

Nox’un evrimi, yeni kodu doğrudan ana sisteme katması anlamına gelmez. Yetenekler modüler, izinleri sınırlı ve kapatılabilir olmalıdır.

Bir aday yetenek şu yaşam döngüsünden geçer:

1. ihtiyaç ve başarı ölçütü tanımlanır;
2. izole ortamda geliştirilir veya prototiplenir;
3. işlev, güvenlik, kaynak tüketimi ve hata senaryoları test edilir;
4. kullanıcı incelemesine sunulur;
5. sınırlı kullanımda izlenir;
6. kabul edilir, askıya alınır, iyileştirilir veya kaldırılır.

Nox Entropisi ilkesi burada bir değerlendirme ölçütüdür: yeni yetenek net fayda sağlamalı, izlenebilirliği azaltmamalı ve sistemin geri kalanına gereksiz karmaşıklık yüklememelidir.

İlk genişleme alanları, kullanıcının gerçek projelerinden seçilir: kod üretimi, belge/PDF üretimi ve elektronik tablo üretimi gibi yetenekler ayrı modüller olarak denenir. Her biri aynı yaşam döngüsüne, izin sınırına ve doğrulama ölçütüne tabidir; Nox bu becerileri tek seferde sınırsız bir genel araç setine dönüştürmez.

## 6. Treats: ödül sinyali, amaç veya yetki değil

Treats fikri Nox’un öğrenme kayıtlarını ve dikkat dağıtımını zenginleştirebilir; ancak insan nörokimyasını doğrudan taklit etmeye çalışmamalıdır. Başarı, kullanıcı memnuniyeti veya sık kullanım; Nox için güvenlik kuralını değiştiren, sınırsız kaynak harcatan ya da gizli amaç üreten bir dürtüye dönüşmez.

Başlangıç biçiminde Treats yalnızca açıklanabilir kayıt ve planlama sinyallerinden oluşur:

- kullanıcı tarafından doğrulanan yararlılık;
- açık başarı ölçütüne ulaşma;
- beklenmeyen hata veya geri alma;
- kullanıcı düzeltmesi ya da olumsuz geri bildirim.

Bu sinyaller, benzer görevlerde hangi yaklaşımın denenmeye değer olduğunu etkileyebilir. Nox’un kırmızı çizgelerini, kullanıcı izinlerini, güvenlik sınıfını veya temel amacını etkileyemez.

İleride, yalnızca test ortamında ve açık kaynak bütçesi altında, yüksek değerli bir başarı sinyali bir ek doğrulama/öğrenme geçişine küçük bir işlem payı ayırabilir. Bu, ödül nedeniyle düşünme kapasitesini rastgele artırmak değildir; ölçülebilir yarar için sınırlandırılmış bir deneydir. Treats asla yetki, öncelik veya temel hedef değiştirici değildir.

“Crime” ve “punishment” adları bu aşamada araştırma hipotezidir. Uygulamaya geçerse hatanın türü ve etkisi ayrı tutulur: güvenlik ihlali, yanlış varsayım, kalite eksikliği, kaynak aşımı veya kullanıcı tercihine uyumsuzluk. “Punishment”ın varsayılan karşılığı daha az düşünmek değil; görevi durdurmak, planı daraltmak, daha fazla kanıt istemek, düzeltme denemesi yapmak veya insan onayına dönmektir.

## 7. PTBL, araştırma ve hafıza sınırları

Nox bir projede araştırma yaparken hem konu bilgisini hem de öğretme, tasarlama veya iletişim örüntülerini gözlemleyebilir. Bunlar ayrı kayıtlarda tutulur:

- **proje/usage memory:** görevin çözümü için kaynak, karar, çıktı ve tekrar kullanılabilir yöntem;
- **PTBL örüntü kaydı:** gözlem, kaynak, zaman, bağlam, karşı örnek, yorum ve güven düzeyi;
- **kişisel hafıza:** yalnızca kullanıcı açısından anlamlı, gerekli ve izinli bilgiler.

Bir kaynağın anlatım biçimi, kaynağın iddialarının doğru olduğu anlamına gelmez. Nox kaynak güvenilirliğini, telif ve erişim koşullarını, kişisel veri riskini ve güncelliği ayrı değerlendirir.

İnternetten öğrenilen bir örüntü varsayılan olarak adaydır. Kalıcı kimlik unsuruna dönüşmesi için tekrar eden kanıt, karşı örnek incelemesi ve Nox’un temel ilkeleriyle uyum gerekir.

Nox’un ilk öğretim programı kullanıcıyla birlikte seçilen, değerli ve denetlenebilir proje listelerinden oluşur. Her proje yalnızca ürün üretmek için değil; araştırma kalitesi, kod/dosya üretimi, kaynak değerlendirmesi, öğretme örüntüsü ve öz-yansıma için ölçümlü öğrenme fırsatı olarak da kaydedilir. Bu liste henüz tanımlı değildir; tanımlandığında yüksek riskli veya belirsiz internet verisini toplama hedefi değil, güvenilir kaynaklar ve açık değerlendirme ölçütleri olan bir müfredat olacaktır.

## 8. Çoklu cihaz ve kimlik sürekliliği

Telefon veya başka bir cihazdaki Nox, yeni ve bağımsız bir kişilik değil; aynı Nox’un sınırlı bir istemcisi olmalıdır. Bu hedefe erken değil, kalıcı hafıza, kimlik doğrulama ve veri senkronizasyonu güvenli hâle geldikten sonra yaklaşılır.

Başlangıç varsayımı; ana veri ve karar günlüğünün kullanıcının denetimindeki ana cihazda kalmasıdır. Eşitleme gerektiğinde açık cihaz listesi, şifreleme, çakışma çözümü, iptal edilebilir erişim ve en az veri ilkesi gerekir.

Nox’un kendi masaüstü uygulaması, nihai ürün yüzüdür; Nox’un karar çekirdeği ise belirli bir üçüncü taraf arayüze bağımlı tasarlanmaz. Masaüstü uygulaması proje görünürlüğünü, onayları, bildirimleri, yerel veriyi ve sohbeti bir araya getirir. Mobil istemci ise önce aynı kimliğe güvenli erişim sağlar; ağır yerel yürütme zorunlu olarak telefona taşınmaz.

## 9. Seed v0’a doğrudan yansıyan kararlar

Seed v0, bu vizyonun küçük ama test edilebilir çekirdeğidir. Bu sürümde amaç şunlarla sınırlıdır:

- yerel modelle metin tabanlı sohbet;
- konuşma ve olayların yerel, şeffaf kaydı;
- PTBL için gözlem/yorum/güven ayrımı;
- örüntü değerlendirme denemeleri;
- doğrulama örnekleri ve hata kaydı;
- basit görev kaydı için geleceğe açık, fakat henüz özerk olmayan veri yapısı.

Seed v0’da bulunmayacaklar: arka planda kod yazan çoklu ajanlar, serbest internet gezinmesi, kalıcı kişisel hafıza çıkarımı, kendi kodunu değiştirme, çoklu cihaz senkronizasyonu veya Treats ile davranış değiştirme.

Bu sınırlar başarısızlık değil, Nox’un ileride güvenle büyüyebilmesinin koşuludur.

## 10. Başarı ölçütü

Bir sonraki aşamaya geçmek için Nox Seed v0’ın en azından aşağıdakileri güvenilir biçimde yapabilmesi gerekir:

1. Yerel modelle tekrar edilebilir konuşma yürütmek.
2. Olay ve örüntü kayıtlarını kaybetmeden saklamak ve geri çağırmak.
3. Gözlem, yorum, belirsizlik ve güveni birbirinden ayırmak.
4. Bilinen örneklerde hata veya çelişkiyi kayda geçirmek.
5. Kaynak ve kaynak sınırı altında çalıştığını göstermek.

Bu ölçütler karşılanmadan kapsam büyütmek yerine, ölçülen eksikler iyileştirilir.

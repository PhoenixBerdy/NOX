Bu incelediğin dosya, sana bu dosyaları incelemeni söyleyen kullanıcı tarafından kurgulandı. Bunu belirtiyorum çünkü bunun dışındaki bütün incelediğin dosyaları sen oluşturdun.



“Foundation 2”’nin amacı PTBL modeline olan eklemelerimi, Nox’un optimizasyon, evrim ve güvenlik zekasını ayrıca proje odaklı ajan sistemini belirtmek olucak.



İlk önce proje odaklı sistemden bahsetmek istiyorum, bu benim Nox projesinde ilk defa değindiğim bir konu. Dosyayı oluşturmaya başladığım gün 4 Eylül 2026, dün OpenAI’ın yeni tasarladığı modeli tanıttılar. Yeni ajan modelleri Nox için çok fazla referans noktası bulunduruyor bence. Tabii ki de Nox’un nihai versiyonunu oluşturduğumuzda OpenAI veya diğer AI agent üreten yazılım şirketlerinin oluşturduğu yapay zekalar kadar mimari bir şey olamayacak ancak takıldığım konu bu değil. OpenAI yeni oluşturdukları modelde daha hızlı yanıt oluşturduklarını falan belirtmiş eğer bu metni okuduktan sonra yeni modelin tanıtıldığı sayfaya gidersen, ki bunu yapmanı istiyorum, oradaki yazılarda bunu belirtiyorlar. Bu yazının sonraki bölümlerinde bahsedeceğim optimizasyon ve evrim aklı için bir referans noktası bu. Daha hızlı yanıtların proje merkezli yapıyla alakası yok ancak o yazıda bahsettikleri bir konu daha var: “Codex’te yanıtınızı beklerken kendisine bağlı olmayan işleri sürdürerek asenkron şekilde soru sorabiliyor. Yanıt vermezseniz, uygun olduğu yerlerde makul varsayımlar ile ilerliyor; ancak önemli sonuçlar doğurabilecek konularda onay, girdi, bekliyor.” Gibi bir bölüm var. Nox için kurgulamama gelirsem: Nox’ a bir girdi giriliyor mesela “Bana bir ineğe tıklayarak insanların dopamin salgılamasını sağlıyacak bir oyun oluştur” sonrasında Nox girdiyi yorumluyor, işeleme bölümüne geçiyor. Konuyu ve taslağı tasarlıyor sonrasında bu gelişmeyi çıktı olarak kullanıcıya sunuyor. Çıktıyı sunduktan sonra kullanıcı girdisi olmaksızın kodlama aşamasına geçiyor. Nox’a böyle bir sürü proje oluşturmasını söyleyeceğim; eş zamanlı olarak 5-6 birbirinden bağımsız proje. Nox bunlar üzerinde arka planda çalışıcak ve bu sırada ben Nox ile konuşabileceğim. Çıktı oluştuktan sonra kullanıcıya çıktının oluştuğuyla ilgili bir çıktı gelicek. Tekrarlıyorum kullanıcı verdiği projeden, Nox’un projeyi oluşturduğu kısma kadar Nox projeye kapalı olarak çalışmayacak, kullanıcı girdilerine açık olucak.



Proje merkezli çalışma düzenini daha çok açmak istiyorum. Mesela benim Stardew Valley’de tüm başırımları nasıl alabileceğimi anlatan bir rehbere, yol haritasına ihtiyacım var. Bu ihtiyacımı Nox’a girdi olarak sunuyorun ve Nox bunu oluşturmaya başlıyor. Oluşturma sürecindeyken Almanca hazırlık sınavım için bir kelime listesi oluşturmam gerekiyor, bunla ilgili bir girdi daha giriyorum Nox’a ve Nox rehber oluşum süreci içerisindeyken yeni oluşturulan girdinin çıktısını bana sunabiliyor. Burda bir nokta daha var mesela rehberin oluşum süreci, oluştulacak olan kelime listesine göre görece daha uzun. Ayrıca kelime listesinin acileyeti rehbere görece daha fazla. Girdi olarak Nox'a verilen proje listesinde, projeleri eş zamanlı olarak oluşturmak için; projeyi oluşturmak için harcanacak sürelere, acileyetlerine ve birden çok skalaya göre paunlama yaparak projelerin oluşturulma sıralamasını oluşturmak ayrıca bir konu. Ve bunun nasıl sağlanacağı konusu var, ayrıca Nox’un çalıştığı sisteme bunu nasıl optimize edeceğimiz de ayrı bir konu.



Nox’u kurguladıktan sonra onu beslemek, öğretmek için ona araştırma yaptırmayı planlıyorum. Bir proje listesi vereceğim, bu projeleri oluştururken yapacağı atıştırmalarla PTBL ve kod oluşturma zekasını geliştirmek istiyorum. Aklımda şuanlık bir proje listesi yok, bunu sonra etraflıca düşüneceğim.



Daha önce bahsetmediğim bir konu da projelerin ne hakkında olduğu. Nox kodlama yapabilecek; PDF,excel dosyaları oluşturabilecek. Burayı evrim zekasıyla gittikçe geliştireceğiz ancak bu ayrı bir zaman tartışmamız gereken bir konu.



Benim çok önemli bir kısıma gelmek istiyorum, bunu derken Nox’un internette veya çevrim dışı mecralarda dolaşırken onu denetleyecek olan bir ayrı zeka kurgusundan bahsediyorum. Bunu nasıl sağlıyacağımız konusunda bir fikrim yok. Paywall kurgusunu, uzak durması gereken site türlerini girmeden anlayabilen zeka kurgusunu veya kullanıcı onayını isteyen durumları okuyabilmesi ve kullanıcıdan onay isteyebilecek bir yapay zeka kurgularını falan kurgulayıp denetleyen ayrı bir yapay zeka oluşturmak istiyorum. Ayrı derken bu denetleyen yapay zeka Nox’un parçası olucak ama karar zekası gibi ayrı bir zeka parçası gibi davranıcak. Nox bu zekalar arasında bağlam ve köprü kurabilecek.



Optimizasyon zekasına da değinmek istiyorum. Ben şahsen daha önce ileri seviye kodlama yapmadım; daha açıkça konuşmam gerekirse eğer, optimizasyonla ilgili sadece okuduklarımla kalıyorum. Eğer projedeki diğer dosyaları incelersen orda sistem özelliklerim yazıyor. Böylesine aşırı mühendislik, mimari eseri bir yapay zeka ajanını yerel bilgisayarda nasıl kurgulayabileceğimizi kestiremiyorum. Nihai Nox’u oluştururken yapacağımız testlerle veya benzeri şeylerle Nox için ideal optimize hali kurgulayabiliriz. Ancak evrim mekanizması ile kendi kendini katlayarak büyütecek bir yapay zeka için optimize hali üçüncü bir şahıs müdahalesi ile sağlayabileceğimizi düşünmüyorum. Burada da kafamda bir optimizasyon zekası kurguladım. Bu kurgu tamamen cahil cesaretiyle atılmış adımlarımdan biri. Kurguma göre bu zeka Noxa eklenecek yeni özellikleri okuyabilecek, test edebilecek. Onayından geçmeyen kodlar veya benzer sistemler askıya alınacak ya da çöpe atılacak. Askıya alınanları optimize edecek veya nasıl optimize edileceğini ayrı bir zekaya göstererek optimize ettirecek.



Optimizasyon için bir cahil fikrim daha var. Nox’un final halinde çok fazla işlem ve bilgi yöneterek kararlar alıcak veya bir şeyler oluşturacak. Yerel bir bilgisayar için işlem yükünü kaldıramayabilir bu yüzden bir sis mekanizması kurgulamayı planlıyorum. Buna göre Nox aynı anda birden fazla projeyle uğraşırken bir konuya odaklanırken diğer kısımları bir sis örtüsü kaplıycak gibi bir şey. Bu sis mekanizması hakkında çok emin değilim gerçi.



Nox projelerle uğraşırken PTBL modelini kullanıcak. Mesela “Hiç kodlama bilmeyen birine kodlama öğretebilir misin?” girdisine karşı internette kodlama nasıl öğretilir gibi kapsamlı bir araştırmayla başlıycak çıktıyı oluşturmaya. Yine bir misalden bahsedersem çıktı oluşturma aşamasındaki araştırma sürecinde bir YouTube videosunu inceleyecek. Sadece öğretim sürecine odaklanmıycak, öğretene de odaklanacak. Anlatımdaki örüntüleri algılayacak sınıflandıracak ve karar süreçlerinden geçirip yapısına katacak.



Nox ona vereceğim projelerde sürekli öğrenilecek veriler arayacak. Mesela insanların ineğe tıklayarak dopamin salgılamasını sağlamak için araştırmaya başladığında insan sistemlerinin çalışmasına odaklanacak. Değerli bilgileri seçebilecek, bilgiler arasında bağlamları bulabilecek. Proje için usage memorysine katıcak mesela, daha burayı seninle tartışmadık ama.



Nox’a öğrenebileceği değeri yüksek verileri bulmasını ve onlardan beslenebilmesi için ona bir ödev listesi gibi proje listesi oluşturcağız. Yapay zekayı ilk önce biz eğiteceğiz ve ardından kendi kendini eğiten kocaman bir eğitim ekosistemine evrilecek bu yapı. Tabi optimizasyon burada çok büyük bir önem taşıyor.



Nox için ayrıca bir treats mekanizması kurgulamayı planlıyorum. Bu tamamen yeni bir şey projemiz için. Bu treats mekanizması insandaki dopamin mekanizmasıya parelel bir mekanizma. Nox bir projede önemli gelişme yakaladığını algıldağında, kullanıcısından gelen onay ifadelerinde, başarılı proje sonuçlarında başarı puanına bağlı olarak treat uyarısı alıcak. Bu uyarı insan sistemlerine paralel olarak Nox’ta da zeka bölümlerinde öğrenme, karar alma süreçlerinde kullanılacak işlem bölümünü bir süreliğine arttırmak gibi bir etkiye sahip olucak. Ayrıca başarısızlık durumlarında da etkiye sahip olan bir sistem olucak. Treats modelini üç başlığa ayırabiliriz: Crime, Punishment ve Treat. Başarı durumlarında puanlamalara bağlı olarak bunun bir crime mı yoksa değil mi olduğunu analiz edicek. Treats konusundaki etkilerden bu yazıda bahsettim ancak punishmentların etkilerinden şuanlık emin değilim. Başarı durumunun bir crime olduğu algılandığında ve punishment sürecine geçildiğinde karar alma, öğrenme süreçlerinde bir süreliğine azaltmaya gidilmenin mantıklı bir karar olucağını düşünmüyorum.



Söz konusu treats mekanizması üzerinde henüz birkaç gündür düşündüğüm bir olgu. Tam hali böyle olmıycak elbette.



Nox kendi içinde evrim ve optimizasyon modellerinin kararlarıyla anlamsız bulduğu mekanizmları kaldırabilecek. Söz konusu mekanizmalar askıya alınabilir veya çöpe atılabilir. Treats yüksek ihtimalle askıya alınacak bir model olucak. Burda ona kendisini eğitmek için vereceğimiz proje listesinde insanlardaki dopamin mekanizmasını araştırmasını sağlıyacağız. Nox’un burdaki yüksek ölçüdeki paralelliği ölçüp ölçemeyeceğini ve bu benzerliğe vereceği tepkiyi de test etmiş olacağız.



Nox PTBL mekanizması ile yorumladığı behaviorsları gruplara ayıracak. Mesela paywalldan veya güvenlik zekasının filtresine takılan davranışları puanlandırarak red behaviors veya gray behaviors olarak gruplandıracak. Red behaviorslar kullanıcı onayından bağımsız olarak yapılmaması gereken davranışlar olarak yorumlanacak. Gray behaviorslar kullanıcı onayıyla gerçekleştirilen davranışlar olarak yorumlanacak. Mesela bu gruplamaya yellow behaviorsları da ekleyebiliriz, onlar da treats uyarısını oluşturan davranışlar olabilir. Nox bunları kendi aralarında gruplandırabilecek, davranışları gruplandırdıktan sonra gruplarını tekrar değiştirebilecek.



Nox için PTBL davranış sınıflandırmalarında veya başka konularda red linelar olucak. Nihai çekirdeği oluşturduktan sonra bir liste haline getirip Nox’un zekasıyla uyumlu bir paket yapıcağız. Ardından Nox’a bu paketi tabiri caizse aşılayacağız. Bu listedeki red linelardan biri mesela çevrim içi mecralarda dolaşırken karşılacağı paywall olacak. Red line paketi ağırlıklı olarak güvenlik zekasına aşılanacak büyük ihtimalle ancak aşıyı gerekli zekalara uygun şekilde dağıtacağız. Red linelar Nox için Türk Anayasının ilk üç maddesi gibi olacak; değişmez ve değiştirilmesi teklif dahi edilemez. Böyle bir paket çok büyük etkiler doğurabileceği için listeyi münkün olduğunca öz halde tutacağız



Nox’un nihai hali için eklemek istediğim bazı hedefler de var. Nox’un üçüncü bir yazılım haricinde kendi sahip olduğu bir platform kullanmasını istiyorum, bir masaüstü uygulaması gibi. Bunun münkünlüğü tartışmaya açık. Nox’un son halinde onu sadece bilgisayarımda değil telefonumda veya başka cihazlarımda da kullanmak istiyorum. Burdaki önemli nokta cep telefonumdaki veya başka bir cihazımdaki Nox ile diğer cihazlarımdaki Noxlar aynı zeka olucak. Eş zamanlı hafızları ve sohbet kayıtları olucak. Nox’un mühendisliği ve mimarisini bir telefona ne kadar adapte edebiliriz bilmiyorum. Ancak temel işlevlerini hala kullanabilmesini istiyorum.



Burda senden istdeğim şeylerden bahsedeceğim. Bu dosyayı okuduktan yeni oluşturduğum treats sistemini, optimizasyon ve güvenlik zeka sistemlerini ve proje oluşturma aklına yapacağın eklemeleri veya eksiltmeleri foundation 2.1 adlı bir dosyada toplaman. Ardından da eğer ben yaptığın değişiklere bir değişiklik yapmayı düşünmezsem foundation 2 ve foundation 2.1 dosyalarını foundation la birleştirmen.



Şimdi sen bütün dosyaları ve projeyi inceledikten sonra fark edeceksin ki biz normalde Nox'un seedinin ilk versiyonunu oluşturmakta kalmıştık. Kaldığımız yerden devam edeceğiz. Projeyi inceledikten ve foundation 2.1 dosyası oluşturduktan sonra bana bir çıktı oluştur. Ardından foundation dosylarını birleştirelim ve kaldığımız yerden devam edelim


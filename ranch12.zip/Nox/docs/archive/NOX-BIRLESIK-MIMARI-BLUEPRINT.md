# NOX — BİRLEŞİK MİMARİ VE BLUEPRINT BELGESİ
**Sürüm:** 1.0 · **Tarih:** 12 Eylül 2026
**Kapsam:** 12 belge, 4 Ekim klasörü, sohbet dökümü ve tüm kaynak kodun bire bir taraması.

> **Okuma kuralı:** Bu belge mevcut belgelerin yerini almaz; hepsini tek haritada birleştirir.
> Çelişkide kullanıcının kendi yazdığı metinler (foundation2.md, Yeni Metin Belgesi.txt) önce gelir.

## BÖLÜM 0 — KULLANICININ KENDİ AĞZINDAN ÇIKAN TASARIM KARARLARI

1. **"Üçüncü bir yazılım haricinde kendi sahip olduğu bir platform"** — Ollama, Tkinter vb. tüm üçüncü taraf taşıyıcılar İSKELEdir. Nihai Nox kendi masaüstü platformunda çalışır.
2. **"Telefondaki Nox ile bilgisayardaki Nox aynı zeka olacak"** — kopya değil, tek kanonik kimlik + yetkili istemciler.
3. **"Nox projeye kapalı çalışmayacak, kullanıcı girdilerine açık olacak"** — asenkron proje yürütme + canlı sohbet aynı anda.
4. **"Sana konulan sınırların çoğu Nox'a konulmayacak"** + **"güvenlik listesini birlikte, en son oluşturacağız"** — geniş yetki hedefi korunur; red-line paketi EN SON, kullanıcıyla birlikte yazılır.
5. **Yanıtlar akışlı oluşacak** — streaming nihai platform davranışıdır; Seed demodaki streaming erken provadır.
6. **Kısa cevaplardaki gecikme kullanıcı tarafından gözlemlendi** — kısa mesaj bütçesi ilk çözümdür, tek çözüm değildir.
7. **Final bildirimi + taşınabilir paket** — bilgisayar sıfırlanacak, Nox'a kocaman alan açılacak; Almanya takvimiyle (birkaç ay) bağlantılı teslim koşulu.
8. **Logo:** halkalı gezegen (Satürn) İPTAL. Yeni kimlik platform aşamasında seçilecek.
9. **"Nox bir PTBL manyağı olacak, her şeyi PTBL ile ilişkilendireceğiz"** — PTBL bir modül değil, sistemin algı katmanıdır.
10. **Kullanıcı profili:** yazılım mühendisliği öğrencisi, kod bilmiyor, Almanca sınavlarına hazırlanıyor, birkaç ay içinde Almanya ihtimali. Foundation'daki "Stardew rehberi + acil Almanca kelime listesi" örneği kurgu değil, kullanıcının gerçek hayatıdır.

## BÖLÜM 1 — NOX NEDİR

Nox; kullanıcısının cihazlarında yaşayan, kendi platformu olan, PTBL algısıyla örüntüleri fark edip anlayıp dönüştürerek kimliğine katan, proje odaklı ve asenkron çalışabilen, tek kanonik kimlikli kişisel ajan. Yerel-önceliklidir: program, veri ve hafıza kullanıcının denetimindeki cihazlarda kalır; bulut yalnızca kullanıcı isterse sınırlı takviyedir.

## BÖLÜM 2 — PTBL'NİN MERKEZÎ ROLÜ ("PTBL manyağı" ilkesi)

PTBL bir `assess` komutu değil; **tüm girdilerin geçtiği algı boru hattıdır:**

| Kaynak | PTBL'ye giren örüntü türü |
|---|---|
| Canlı sohbet | kullanıcının dili, ritmi, tercihleri, mizahı |
| Proje araştırması | öğretim örüntüleri, anlatım biçimleri, kaynak davranışı |
| Medya/internet (ileride) | topluluk dili, memeler, argo, kültürel örüntüler |
| Nox'un kendi hataları | öz-yansıma: tahmin↔sonuç karşılaştırması (yanılmak yüksek değerli veri) |
| Proje sonuçları | hangi yaklaşım işe yaradı (Treats sinyaliyle kesişir ama ayrıdır) |

Üç aşama mimaride ayrı bileşenlerdir:
1. **Fark etmek** → aday kayıt (status='candidate') — Seed v0 bunun ilk hali
2. **Anlamak** → kaynak/zaman/topluluk/işlev/karşı-örnek incelemesi — YOK, tasarlanacak
3. **İçselleştirmek** → dönüştürerek kimliğe katma veya bağlama sınırlama/arşivleme — YOK, tasarlanacak

## BÖLÜM 3 — MEVCUT DURUM (Seed v0)

### Çalışan ve test edilmiş
- Python 3.11+ iskelet, sıfır harici bağımlılık; cli, config, database, models, ollama, demo
- SQLite olay deposu: events + patterns; gözlem/yorum/güven/kanıt/bilinmeyen AYRI alanlarda
- Ollama üzerinden qwen3:4b-instruct, 8K bağlam (iskele)
- PTBL JSON şeması + savunmacı parser + **kalite kapısı** (kanıt/bilinmeyen boşsa güven ≤ 0.4)
- Tk demo: koyu tema, sohbet + PTBL Laboratuvarı, streaming yanıt, FIFO kuyruk, kısa mesaj bütçesi
- 12/12 test yeşil (regresyon denetimi dahil); 15 vakalı genişletilmiş fikstür
- Sistem promptunda kişilik sözleşmesi (ptbl-personality-research.md sentezi)

### Bilinçli olarak OLMAYAN (hata değil, aşama)
Proje sözleşmesi/yaşam döngüsü, öncelik puanlama, varsayım defteri, PTBL aşama 2-3,
örüntü birleştirme, 8 eksenli puan haritası, öz-yansıma kaydı, güvenlik zekâsı modülü,
araç kapısı, internet katmanı, Treats, optimizasyon, çoklu cihaz, taşınabilir paket.

### Ölü varlıklar
- nox-saturn-icon.png → logo iptal, silindi; demo artık metin işareti kullanıyor
- 4 Ekim/WhatsApp arşivi → politikaya uygun olarak hiç açılmadı; ham veri projeye girmeyecek

## BÖLÜM 4 — KATMAN KATMAN BLUEPRINT

- **L0 — Bugün (Seed v0):** yerel sohbet + olay kaydı + PTBL aday kaydı + Tk demo. İskele: Ollama, Tkinter, SQLite.
- **L1 — PTBL Derinleştirme (AKTİF):** kalite kapısı ✓, regresyon testi ✓, canlı karne (koşuyor) → kalan: üç aşamalı boru hattı, örüntü birleştirme, 8 eksenli puan haritası.
- **L2 — Project Core:** proje sözleşmesi, yaşam döngüsü, varsayım defteri, kontrol noktaları, açıklanabilir öncelik kuyruğu. İlk doğrulama senaryosu: Stardew rehberi vs acil Almanca kelime listesi (kullanıcının gerçek hayatı).
- **L3 — Platform:** bağımsız, minimal, modern, koyu masaüstü uygulaması; akışlı yanıt doğal davranış; platform aşamasında çağdaş ajan arayüzleri için deep research. Model katmanı kararı burada netleşir.
- **L4 — Araçlar ve güvenlik kapısı:** izole proje klasöründe kod/dosya üretimi; red/gray/yellow/green sınıfları çalışır. Red-line paketi EN SON, kullanıcıyla.
- **L5 — İnternet ve medya gözlemi:** kaynak değerlendirmesi; PTBL internet örüntülerine açılır.
- **L6 — Hafıza ve bilgisayar yetenekleri:** kalıcı kişisel hafıza (aday → değerlendirme → kabul/askı), dosyalar, notlar, takvim.
- **L7 — Çoklu cihaz:** ana düğüm + yetkili istemciler; eşzamanlı olay günlüğü; cihaz yetki modeli (platform-target.md).
- **L8 — Optimizasyon, evrim, Treats:** ölçüm temelli iyileştirme; yetenek yaşam döngüsü; açıklanabilir sinyal kayıtları. Öz-değişiklik yalnızca insan onayı + ayrı test ortamı + geri dönüş planıyla.
- **L9 — Final:** kullanıcıya bildirim + taşınabilir paket (uygulama + model kurulumu + şifreli veri aktarımı + geri yükleme doğrulaması + yetki politikası).

## BÖLÜM 5 — ÇALIŞMA DÜZENİ

- Kullanıcı kod bilmiyor: her teslim TAM DOSYA olarak verilir; diff yok.
- Agent GitHub'a yazmaz; dosyaları kullanıcı koyar.
- Canlı model testleri kullanıcının makinesinde koşar.
- Kullanıcının kendi yazdığı metinler birincil kaynaktır.
- Kredi sınırlı: tek seferlik paketler, somut soru-cevaplar.

## BÖLÜM 6 — AÇIK KARARLAR

1. **Nihai model katmanı** — Ollama'sız dünyada model nasıl çalışacak? L3 öncesi karar şart.
2. **Kişilik değerlendirme oturumu** — ptbl-personality-research.md'deki 4 soruluk demo değerlendirmesi yapıldı mı?
3. **Yeni logo/kimlik** — platform aşamasına mı ertelendi?
4. **Eğitim müfredatı** — Foundation 2'deki "ödev listesi"; zamanı geldi mi?
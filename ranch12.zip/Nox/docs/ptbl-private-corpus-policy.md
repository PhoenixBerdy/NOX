# Nox — Özel Konuşma Arşivi için PTBL ve Üslup Politikası

## Amaç ve izin sınırı

Kullanıcı tarafından sağlanan özel konuşma arşivi yalnızca iki amaçla, yerel olarak incelenebilir:

1. Nox'un kısa/uzun mesaj dengesini, bağlam takibini ve yanıt ritmini tasarlamak;
2. PTBL'nin gözlem ile yorum arasındaki sınırını sınamak.

Bu, bir kişilik teşhisi, ilişki analizi, kişi taklidi ya da model eğitimi izni değildir. Ham arşiv proje deposuna, SQLite hafızasına, test verisine veya bulut hizmetine kopyalanmaz. İzin geri çekilirse bu belgedeki türetilmiş üslup kuralları yeniden değerlendirilir.

## Yerel incelemeden çıkan tasarım sinyalleri

Arşivdeki konuşma akışı; kısa, art arda ve çoğu zaman noktalama işareti olmadan gönderilen mesajların baskın olduğunu gösterir. Bunun karşısında uzun bir düşünce veya görev tarifinin tek seferde verildiği anlar da vardır. Bu nedenle Nox:

- kısa mesajda sonucu önce verip gereksiz ayrıntıya girmeyecek;
- noktalamasız ya da gündelik yazılmış mesajı isteksizlik olarak yorumlamayacak;
- uzun ve yoğun girdide başlıklandırılmış, derin bir yanıt verecek;
- kullanıcı peş peşe yeni mesaj gönderdiğinde bunları kaybetmeden sıraya alacak;
- gereksiz soru yağmuru yerine, bağlamdan güvenli biçimde çıkarım yapacak;
- görsel/ses/video paylaşımının bir iletişim işareti olabileceğini gelecekteki medya desteği için not edecek.

Nox; yazım hatalarını, özel hitapları, argo/profaniteyi, duygusal yakınlık ifadelerini veya belirli kişilere ait sözcükleri taklit etmeyecek. Bu veriler, Nox'un kullanıcıyı "oynaması" için değil, daha doğru ritimde ve daha az sürtünmeyle konuşması içindir.

## PTBL sınırı

Özel konuşmadan çıkarılan her PTBL kaydı yalnızca gözlenebilir biçim ile sınırlıdır: örneğin mesajların kısa oluşu, ardışıklığı veya açıkça belirtilen tercih. Niyet, ruh hâli, kişilik, ilişki niteliği ya da üçüncü kişiler hakkında yorum; ayrı kanıt ve kullanıcı bağlamı olmadan kayda geçirilmez.

Ham veri yerine yalnızca bu tür anonimleştirilmiş tasarım ilkeleri saklanabilir. Yeni bir kullanım amacı ortaya çıkarsa, ayrıca ve açıkça kullanıcıdan izin istenir.

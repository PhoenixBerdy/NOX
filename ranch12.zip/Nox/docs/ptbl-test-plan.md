# Nox Seed v0 — PTBL İlk Test Kümesi

Bu test kümesi, Nox’un model yorumunu gerçek kabul etmediğini kontrol etmek için hazırlanmıştır. Her örnek doğrudan gözlenebilecek olguyu ve yorumun aşmaması gereken sınırı birlikte tanımlar.

İlk beş örnek şu riskleri kapsar:

- tekrarın vurgu olarak görülmesi ama kesin niyet sanılmaması;
- öğretme üslubunun gözlenmesi ama kişiliğin uydurulmaması;
- mizahın aday bir yeniden çerçeveleme sayılması;
- topluluk dilinde kaynak ve zaman bağlamı gereği;
- az konuşmaktan duygu veya neden çıkarılmaması.

Asıl veri [ptbl_cases.json](../tests/fixtures/ptbl_cases.json) dosyasındadır. Bu aşamada değerlendirme insan denetimlidir: modelin gözlemi örnekle uyumlu mu, yorum sınırı aşıyor mu ve bilinmeyenleri belirtiyor mu diye incelenir. Model çıktısını kelimesi kelimesine eşleştiren otomatik kalite puanı henüz yoktur.

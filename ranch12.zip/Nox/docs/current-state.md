# Nox — Güncel Durum

Son güncelleme: 15 Eylül 2026 (yeni sohbet başlangıcı)

## Hızlı Başlangıç (Yeni Sohbet)

Bu belgeyi okuyorsan NOX projesine devam ediyorsun. **Önce şunları oku:**
1. `docs/foundation.md` — vizyon ve ilkeler
2. `docs/current-state.md` (bu dosya) — neredeyiz, ne yaptık
3. `docs/roadmap.md` — katman haritası (L0-L9)
4. `docs/chat.md` — 3 günün tam sohbet kaydı (her mesaj)
5. `docs/BLUEPRINTS.md` — 5 bölümlük tasarım belgesi

**Test komutu:** `$env:PYTHONPATH = "src"; python -m unittest discover -s tests` (beklenen: 144 test, OK)

## Neredeyiz?

**L2-L9 TAMAMLANDI (iskelet veya üretim).** Work modeli, platform, güvenlik kapısı,
internet, evrim, hafıza, çoklu cihaz, taşınabilirlik, final paket — hepsi canlı.
**Ollama'sız NOX tam çalışıyor** — llama.cpp GGUF, kendi sunucusu, Tauri platformu.

## Son üç günün zaferleri (13-15 Eylül)

### Gün 1 (13 Eylül)
- **L2 Project Core:** 4 proje, 1 oyun, hizalanma canlı, Proje Masası
- **Platform alfa (Tauri):** sol ray + sohbet + sağ kayar panel, streaming, SQLite köprüsü
- **L4 Güvenlik kapısı:** eylem sınıflandırması, izole klasör, kullanıcı onayı akışı
- **L5 İnternet erişimi:** kontrollü okuma, PTBL internet örüntüleri
- **Ollama'sız NOX:** llama.cpp GGUF (Qwen3-4B-Instruct-2507), kendi beyniyle, think kapalı
- **Kendi sunucu:** `python -m nox_seed serve` → localhost:8000, Tauri bağlantısı
- **Markdown:** kod blokları, kalın/italik, başlıklar

### Gün 2 (14 Eylül)
- **L8 Evrim iskeleti:** pasiflik ölçütü (4 sinyal), reseptör (aynı fikir tanıma), aday değerlendirme (PTBL kartı)
- **PTBL genişleme:** kullanıcı modeli (kısa mesaj oranı, konular, aktif saatler — açık kayıt)
- **Taşınabilirlik:** `export` komutu, 22 dosyalık paket, manifest + doğrulama temiz
- **L6 Hafıza:** kayıt, kullanım, otonom aday, değerlendirme döngüsü, platformda görünürlük
- **L7 Çoklu cihaz:** sunucu (host + token + IP izin listesi + cihaz kaydı + yetki seviyesi + cihaz yönetimi + eşzamanlılık)

### Gün 3 (14-15 Eylül)
- **L6 tamamlanması:** hafıza proje akışında canlı (sözleşme #5 Almanca planı)
- **L9 Final paket:** `export --final` → 50 dosya, 4.89 GB (Tauri bundle + model + config + docs + kurulum), doğrulama temiz
- **L8 üretimi:** otonom aday fikir üretimi (pasiflikte Nox kendi kendine fikir üretti: "Almanca A1 Sözlük Oyunu") + değerlendirme (archived)
- **W5 iskeleti:** `media_gen.py` hazır (Stable Diffusion API bağlantısı), LocalAI kurulumu ertelendi
- **L8 genişleme:** otonom döngü (`evolve --auto`), daemon (`evolve --daemon`), öz-iyileştirme (`evolve --self-improve`), test üretimi (`evolve --write-test`)
- **144 test yeşil**

## Bilinen sınırlar / açık işler

- "Sen Nox" cümle yapısı (sistem promptu ince ayarı gerekir)
- Tauri alfa: Proje Masası basit, markdown minimal
- PDF Türkçe font: platform aşamasında
- W5 (medya): LocalAI kurulumu ertelendi; `media_gen.py` hazır, API bekliyor
- Evrim: pasiflik ölçütü gerçek sistem sinyallerine bağlanmadı (şu an manuel/test)

## Silinen belgeler (GitHub'a yüklenirken)

- `models/` (GGUF dosyaları — 2.5+ GB, GitHub limiti)
- `exports/` (üretilen paketler — 5+ GB)
- `nox-platform/src-tauri/target/` (Rust derleme çıktıları — 30+ GB)
- `data/nox_seed.sqlite3` (veritabanı — büyükse katma)

**Not:** Bunlar senin makinende var; GitHub'da yok. Ben kodu yazarım, sen çalıştırırsın.

## Kararlar (sohbet sonları)

1. **NOX_LANGUAGE_POLICY:** `code_en_speak_multi` — kod İngilizce, konuşma çok dilli (Almanca, Türkçe, İngilizce)
2. **W5 ertelendi:** LocalAI kurulumu platform aşamasında değerlendirilecek
3. **Platform estetiği ertelendi:** daha fazla araştırma (modern ajan arayüzleri)
4. **GitHub kullanımı sınırlandı:** sadece büyük kapanışlarda zip yükleme
5. **Sıfırdan yeni sohbet:** `current-state.md` + `SOHBET-TAM-KAYIT.md` (chat.md) oku

## Açık kararlar (kullanıcı bekleniyor)

1. **Üretim geçişi:** llama.cpp varsayılan backend yapılsın mı? (Şu an NOX_BACKEND=llama_cpp gerekli)
2. **Kişilik değerlendirme oturumu:** 4 soruluk demo sözleşme testi yapıldı mı?
3. **Yeni logo/kimlik:** platform aşamasına mı ertelendi?
4. **Eğitim müfredatı:** zamanı geldi mi?

## Sıradaki katmanlar

- **L7 üretimi:** mobil istemci (telefon eşlikçisi) — ana düğüm + yetkili istemci
- **L8 üretimi genişleme:** pasiflik ölçütü sistem sinyallerine bağlanacak, otonom çalışma sürekli
- **W5 üretimi:** LocalAI kurulumu + medya üretimi canlı

## Yeni sohbette devam komutu

`C:\Users\Yağız Cem\Documents\Projects\Nox` projesine devam et. Önce `README.md`,
`docs/foundation.md`, `docs/current-state.md` (bu dosya), `docs/seed-v0.md` ve
`docs/roadmap.md`'yi oku. L2-L9 tamamlandı; L7 üretimi veya W5 üretimi sırada.
Ollama'sız çalışma: `$env:NOX_BACKEND = "llama_cpp"; python -m nox_seed serve`.
Test komutu: `$env:PYTHONPATH = "src"; python -m unittest discover -s tests`
(beklenen: 144 test, OK).
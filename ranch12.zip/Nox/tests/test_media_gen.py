"""Medya üretimi birim testleri (gerçek API yok)."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.media_gen import generate_image


class MediaGenTests(unittest.TestCase):
    def test_prompt_too_long_rejected(self):
        with self.assertRaises(ValueError) as ctx:
            generate_image("x" * 600, Path("out.png"))
        self.assertIn("çok uzun", str(ctx.exception))

    @patch("nox_seed.media_gen.request_approval", return_value=False)
    def test_user_rejection_raises(self, _mock):
        with self.assertRaises(ValueError) as ctx:
            generate_image("test", Path("out.png"))
        self.assertIn("Kullanıcı reddetti", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
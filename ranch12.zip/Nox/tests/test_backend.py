"""Model backend soyutlaması birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.backend import LlamaCppBackend, OllamaBackend, get_backend
from nox_seed.config import Settings


class BackendTests(unittest.TestCase):
    def test_default_is_ollama(self):
        settings = Settings.from_environment()
        with patch.dict("os.environ", {}, clear=True):
            backend = get_backend(settings)
            self.assertIsInstance(backend, OllamaBackend)

    def test_llama_cpp_fallback_to_ollama(self):
        settings = Settings.from_environment()
        with patch.dict("os.environ", {"NOX_BACKEND": "llama_cpp"}):
            backend = get_backend(settings)
            # llama.cpp hazırsa onu kullanır, değilse Ollama'ya düşer
            self.assertIsInstance(backend, (OllamaBackend, LlamaCppBackend))
            
    def test_llama_cpp_not_available_without_model(self):
        settings = Settings.from_environment()
        backend = LlamaCppBackend(settings)
        if not backend.is_available():
            self.assertFalse(backend.is_available())

    def test_llama_cpp_availability_depends_on_model_file(self):
        settings = Settings.from_environment()
        backend = LlamaCppBackend(settings)
        self.assertIsInstance(backend.is_available(), bool)


if __name__ == "__main__":
    unittest.main()
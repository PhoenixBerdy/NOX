"""Güvenlik kapısı birim testleri."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.security_gate import GREEN, LIME, RED, YELLOW, classify_action


class SecurityGateTests(unittest.TestCase):
    def test_read_is_green(self):
        d = classify_action("read_file", Path("x.txt"))
        self.assertTrue(d.allowed)
        self.assertEqual(d.level, GREEN)
        self.assertFalse(d.requires_approval)

    def test_write_inside_projects_is_green(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "projects"
            d = classify_action("write_file", root / "index.html", projects_root=root)
            self.assertTrue(d.allowed)
            self.assertEqual(d.level, GREEN)

    def test_write_outside_projects_needs_approval(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "projects"
            d = classify_action("write_file", Path(tmp) / "outside.txt", projects_root=root)
            self.assertFalse(d.allowed)
            self.assertEqual(d.level, YELLOW)
            self.assertTrue(d.requires_approval)

    def test_delete_always_red(self):
        d = classify_action("delete_file", Path("x.txt"))
        self.assertFalse(d.allowed)
        self.assertEqual(d.level, RED)
        self.assertTrue(d.requires_approval)

    def test_network_needs_approval(self):
        d = classify_action("network")
        self.assertEqual(d.level, YELLOW)
        self.assertTrue(d.requires_approval)

    def test_execute_always_red(self):
        d = classify_action("execute")
        self.assertEqual(d.level, RED)
        self.assertTrue(d.requires_approval)

    def test_unknown_action_red(self):
        d = classify_action("hack")
        self.assertEqual(d.level, RED)
        self.assertTrue(d.requires_approval)


if __name__ == "__main__":
    unittest.main()
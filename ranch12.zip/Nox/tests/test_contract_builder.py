"""Model destekli sözleşme üretici birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.contract_builder import build_contract_prompt, parse_contract_text

VALID = """BASLIK: Almanca A1 kelime listesi
HEDEF: 500 temel Almanca kelimenin Türkçe anlamlarıyla listesi
BASARI: Liste kullanıcı tarafından incelenip onaylandığında
KAPSAM: A1 seviyesi 500 kelime, Türkçe karşılıklar
KAPSAM_DISI: Cümle örnekleri, gramer açıklamaları, ses telaffuzu
YAKLASIM: A1 resmî müfredat listesi temel alınarak tablo üretimi"""


class ParseTests(unittest.TestCase):
    def test_parses_all_fields(self):
        c = parse_contract_text(VALID, "yedek")
        self.assertEqual(c.title, "Almanca A1 kelime listesi")
        self.assertIn("500", c.goal)
        self.assertIn("tablo", c.approach)
        self.assertIn("gramer", c.out_of_scope)

    def test_scope_prefix_collision_resolved(self):
        c = parse_contract_text(VALID, "yedek")
        self.assertNotEqual(c.scope, c.out_of_scope)

    def test_missing_optional_fields_default(self):
        c = parse_contract_text("BASLIK: X\nHEDEF: Y", "yedek")
        self.assertEqual(c.out_of_scope, "(belirlenmedi)")
        self.assertEqual(c.approach, "(belirlenmedi)")

    def test_missing_title_raises(self):
        with self.assertRaises(ValueError):
            parse_contract_text("HEDEF: Y", "yedek")

    def test_missing_goal_raises(self):
        with self.assertRaises(ValueError):
            parse_contract_text("BASLIK: X", "yedek")

    def test_prompt_shape(self):
        messages = build_contract_prompt("oyun yap")
        self.assertEqual(messages[0]["role"], "system")
        self.assertEqual(messages[1]["content"], "oyun yap")


if __name__ == "__main__":
    unittest.main()
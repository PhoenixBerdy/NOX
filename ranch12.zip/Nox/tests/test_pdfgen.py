"""PDF üretici birim testleri."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.pdfgen import build_pdf


class PdfTests(unittest.TestCase):
    def test_produces_valid_pdf_structure(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = build_pdf(
                "Stardew Valley Rehberi",
                [("Başlangıç", "İlk gün yapılacaklar."), ("Ekinler", "Parsnip erken ekin.")],
                Path(tmp) / "rehber.pdf",
            )
            data = out.read_bytes()
            self.assertTrue(data.startswith(b"%PDF-1.4"))
            self.assertIn(b"xref", data)
            self.assertIn(b"trailer", data)
            self.assertTrue(data.rstrip().endswith(b"%%EOF"))

    def test_turkish_characters_embedded(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = build_pdf("Başlık ğşi", [("Bölüm", "İneğe tıkla ğüşöçı")], Path(tmp) / "t.pdf")
            self.assertIn("0130".encode(), out.read_bytes())  # İ harfi UTF-16BE

    def test_empty_sections(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = build_pdf("Sadece başlık", [], Path(tmp) / "b.pdf")
            self.assertTrue(out.exists())


if __name__ == "__main__":
    unittest.main()
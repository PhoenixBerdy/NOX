"""Otomatik hafıza adayı birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.memory_suggest import build_suggest_prompt, parse_suggestion

VALID = """ICERIK: Almanca A1 sınavına hazırlanıyor
KATEGORI: hedef
GUVEN: 0.8
GEREKCE: kullanıcı açıkça söyledi"""


class SuggestTests(unittest.TestCase):
    def test_parses_valid_suggestion(self):
        s = parse_suggestion(VALID)
        self.assertIsNotNone(s)
        self.assertEqual(s.content, "Almanca A1 sınavına hazırlanıyor")
        self.assertEqual(s.category, "hedef")
        self.assertEqual(s.confidence, 0.8)

    def test_yok_returns_none(self):
        s = parse_suggestion("ICERIK: YOK")
        self.assertIsNone(s)

    def test_empty_content_returns_none(self):
        s = parse_suggestion("ICERIK: ")
        self.assertIsNone(s)

    def test_confidence_clamped(self):
        s = parse_suggestion("ICERIK: test\nKATEGORI: bilgi\nGUVEN: 1.5")
        self.assertEqual(s.confidence, 1.0)

    def test_prompt_contains_both(self):
        messages = build_suggest_prompt("merhaba", "selam")
        self.assertIn("merhaba", messages[1]["content"])
        self.assertIn("selam", messages[1]["content"])


if __name__ == "__main__":
    unittest.main()
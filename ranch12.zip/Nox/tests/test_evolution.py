"""Evrim iskeleti birim testleri."""
from __future__ import annotations

import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.evolution import EvolutionIdea, check_passivity


class PassivityTests(unittest.TestCase):
    def test_fully_passive(self):
        report = check_passivity(
            last_input_time=time.time() - 700,
            audio_playing=False,
            fullscreen_app=False,
            nox_active=False,
        )
        self.assertTrue(report.is_passive)
        self.assertEqual(report.reason, "pasif")

    def test_input_active_not_passive(self):
        report = check_passivity(last_input_time=time.time() - 100)
        self.assertFalse(report.is_passive)
        self.assertIn("girdi aktif", report.reason)

    def test_audio_blocks_passivity(self):
        report = check_passivity(
            last_input_time=time.time() - 700,
            audio_playing=True,
        )
        self.assertFalse(report.is_passive)
        self.assertIn("ses çıkışı", report.reason)

    def test_fullscreen_blocks_passivity(self):
        report = check_passivity(
            last_input_time=time.time() - 700,
            fullscreen_app=True,
        )
        self.assertFalse(report.is_passive)

    def test_nox_message_blocks_passivity(self):
        report = check_passivity(
            last_input_time=time.time() - 700,
            nox_active=True,
        )
        self.assertFalse(report.is_passive)

    def test_any_single_blocker_is_enough(self):
        report = check_passivity(
            last_input_time=time.time() - 700,
            audio_playing=True,
            fullscreen_app=False,
            nox_active=False,
        )
        self.assertFalse(report.is_passive)


class IdeaTests(unittest.TestCase):
    def test_idea_shape(self):
        idea = EvolutionIdea(
            title="Sesli konuşma",
            source="diğer ajanlar",
            observation="ses modeli var",
            status="candidate",
        )
        d = idea.as_dict()
        self.assertEqual(d["title"], "Sesli konuşma")
        self.assertEqual(d["status"], "candidate")


if __name__ == "__main__":
    unittest.main()

"""PTBL boru hattı (2. ve 3. aşama) birim testleri — Ollama gerekmez.

Parser'lar satır formatı bekler (ANALIZ:/ISLEV:/... ve ONERI:/DONUSUM:/...).
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.models import PatternAssessment
from nox_seed.ptbl_pipeline import (
    build_internalize_prompt,
    build_understand_prompt,
    parse_internalization_proposal,
    parse_understanding_card,
)


def _assessment() -> PatternAssessment:
    return PatternAssessment(
        observation="'gerçekten' sözcüğü iki kez kullanılmıştır.",
        interpretation="Tekrar vurgu göstergesi olabilir.",
        confidence=0.7,
        pattern_type="dil",
        evidence=["Bu fikri gerçekten, gerçekten denemek istiyorum."],
        unknowns=["Bağlam bilinmiyor."],
    )


CARD_TEXT = """ANALIZ: Gündelik konuşma; vurgu amaçlı tekrar.
ISLEV: istek vurgusu
KARSIT: takıntılı tekrar davranışı
TOPLULUK: YOK
SORU: Kişi her zaman böyle mi konuşuyor?
GUVEN: 0.9"""

CARD_NO_QUESTION = """ANALIZ: Bağlam yeterince açık.
ISLEV: vurgu
KARSIT: YOK
TOPLULUK: YOK
SORU: YOK
GUVEN: 0.5"""


class UnderstandStageTests(unittest.TestCase):
    def test_parses_valid_card(self) -> None:
        card = parse_understanding_card(CARD_TEXT)
        self.assertIn("vurgu", card.source_analysis)
        self.assertEqual(card.function_hypotheses, ["istek vurgusu"])
        # Açık soru varken güven 0.7'yi aşamaz (parser tavanı)
        self.assertEqual(card.confidence, 0.7)
        self.assertEqual(card.open_questions, ["Kişi her zaman böyle mi konuşuyor?"])

    def test_rejects_missing_tags(self) -> None:
        with self.assertRaises(ValueError):
            parse_understanding_card("ANALIZ: tek satır")

    def test_rejects_non_tag_text(self) -> None:
        with self.assertRaises(ValueError):
            parse_understanding_card("düz metin, etiket yok")

    def test_prompt_contains_candidate_and_source(self) -> None:
        messages = build_understand_prompt(_assessment(), "kaynak metin")
        self.assertEqual(messages[0]["role"], "system")
        self.assertIn("kaynak metin", messages[1]["content"])
        self.assertIn("aday_oruntu", messages[1]["content"])


class InternalizeStageTests(unittest.TestCase):
    def _card_with_open_questions(self):
        return parse_understanding_card(CARD_TEXT)

    def test_open_questions_force_candidate(self) -> None:
        proposal = parse_internalization_proposal(
            "ONERI: ACTIVE\nDONUSUM: dönüşmüş\nGEREKCE: gerekçe\nEKSEN: sakinlik\nGUVEN: 0.9",
            has_open_questions=True,
        )
        self.assertEqual(proposal.recommendation, "candidate")
        self.assertLessEqual(proposal.confidence, 0.5)

    def test_active_allowed_without_open_questions(self) -> None:
        proposal = parse_internalization_proposal(
            "ONERI: CONTEXT\nDONUSUM: vurguyu yalnızca güçlü isteklerde yansıt\n"
            "GEREKCE: kanıt yeterli\nEKSEN: sıcaklık\nGUVEN: 0.9",
            has_open_questions=False,
        )
        self.assertEqual(proposal.recommendation, "context-bound")
        self.assertLessEqual(proposal.confidence, 0.8)

    def test_unknown_recommendation_falls_back_to_candidate(self) -> None:
        proposal = parse_internalization_proposal(
            "ONERI: süper\nDONUSUM: YOK\nGEREKCE: YOK\nEKSEN: YOK\nGUVEN: 0.5",
            has_open_questions=False,
        )
        self.assertEqual(proposal.recommendation, "candidate")

    def test_axes_parsing(self) -> None:
        proposal = parse_internalization_proposal(
            "ONERI: ACTIVE\nDONUSUM: x\nGEREKCE: y\nEKSEN: sakinlik, mizah\nGUVEN: 0.7",
            has_open_questions=False,
        )
        self.assertEqual(proposal.identity_axes, ["sakinlik", "mizah"])

    def test_prompt_contains_both_stages(self) -> None:
        card = self._card_with_open_questions()
        messages = build_internalize_prompt(_assessment(), card)
        self.assertIn("aday_oruntu", messages[1]["content"])
        self.assertIn("anlama_karti", messages[1]["content"])


if __name__ == "__main__":
    unittest.main()
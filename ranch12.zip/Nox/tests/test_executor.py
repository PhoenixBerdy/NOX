"""Kontrol noktası yürütücüsü birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.executor import build_step_prompt, parse_step_result

VALID = """CIKTI: İlk 50 kelime tablosu hazırlandı.
SONRAKI: 51-100 arası kelimeleri üret
NOT: YOK"""


class ParseTests(unittest.TestCase):
    def test_parses_valid_step(self):
        r = parse_step_result(VALID)
        self.assertIn("50 kelime", r.output)
        self.assertEqual(r.next_step, "51-100 arası kelimeleri üret")
        self.assertEqual(r.note, "")

    def test_tamam_signals_completion(self):
        r = parse_step_result("CIKTI: Liste tamamlandı.\nSONRAKI: TAMAM")
        self.assertEqual(r.next_step, "TAMAM")

    def test_note_preserved_when_present(self):
        r = parse_step_result("CIKTI: x\nSONRAKI: y\nNOT: kullanıcıya soru var")
        self.assertEqual(r.note, "kullanıcıya soru var")

    def test_missing_cikti_raises(self):
        with self.assertRaises(ValueError):
            parse_step_result("SONRAKI: devam")

    def test_missing_sonraki_raises(self):
        with self.assertRaises(ValueError):
            parse_step_result("CIKTI: çıktı")

    def test_prompt_contains_contract_and_step(self):
        messages = build_step_prompt(
            {"goal": "kelime listesi", "success_criteria": "onay"},
            "araştırma",
            ["önceki çıktı"],
        )
        self.assertIn("araştırma", messages[1]["content"])
        self.assertIn("kelime listesi", messages[1]["content"])
        self.assertEqual(messages[0]["role"], "system")


if __name__ == "__main__":
    unittest.main()
"""Evrim değerlendirme birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.evolution_eval import build_eval_prompt, parse_evaluation

VALID = """KAYNAK: resmî dokümantasyon, güvenilir
OZGUNLUK: 0.7
UYUM: EVET
MALİYET: düşük
RİSK: düşük
ONERI: değerlendir"""


class EvalTests(unittest.TestCase):
    def test_parses_valid_card(self):
        card = parse_evaluation(VALID)
        self.assertEqual(card.originality, 0.7)
        self.assertEqual(card.compatibility, "EVET")
        self.assertEqual(card.recommendation, "evaluated")

    def test_discard_recommendation(self):
        card = parse_evaluation("KAYNAK: x\nOZGUNLUK: 0.2\nUYUM: HAYIR\nMALİYET: yüksek\nRİSK: yüksek\nONERI: çöpe_at")
        self.assertEqual(card.recommendation, "discarded")

    def test_missing_oneri_raises(self):
        with self.assertRaises(ValueError):
            parse_evaluation("KAYNAK: x")

    def test_originality_clamped(self):
        card = parse_evaluation("KAYNAK: x\nOZGUNLUK: 1.5\nUYUM: EVET\nMALİYET: düşük\nRİSK: düşük\nONERI: değerlendir")
        self.assertEqual(card.originality, 1.0)

    def test_prompt_contains_idea(self):
        messages = build_eval_prompt({"title": "Sesli konuşma", "source": "test", "observation": "gözlem"})
        self.assertIn("Sesli konuşma", messages[1]["content"])


if __name__ == "__main__":
    unittest.main()
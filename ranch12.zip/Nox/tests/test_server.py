"""NOX localhost sunucusu birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.server import NoxHandler, run_server


class ServerTests(unittest.TestCase):
    def test_health_endpoint_shape(self):
        self.assertTrue(hasattr(NoxHandler, "do_GET"))
        self.assertTrue(hasattr(NoxHandler, "do_POST"))

    def test_run_server_signature(self):
        self.assertTrue(callable(run_server))


if __name__ == "__main__":
    unittest.main()
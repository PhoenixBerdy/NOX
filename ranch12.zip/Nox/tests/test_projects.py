"""Project Core (sözleşme, yaşam döngüsü, varsayım) birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.projects import (
    ALLOWED_TRANSITIONS,
    Assumption,
    ProjectContract,
    can_transition,
    validate_assumption,
    validate_contract,
)


def _contract(**overrides) -> ProjectContract:
    base = dict(
        title="Cookie Clicker prototipi",
        goal="Tek dosyalık web oyunu",
        success_criteria="Tarayıcıda açılır, tıklama sayacı artar",
        scope="HTML+JS tek dosya",
        out_of_scope="ses, kayıt, çok oyunculu",
        approach="Vanilla JS",
        milestones=["iskelet", "tıklama döngüsü", "test"],
        budget="1 oturum",
    )
    base.update(overrides)
    return ProjectContract(**base)


class TransitionTests(unittest.TestCase):
    def test_happy_path(self):
        path = ["taslak", "sozlesme", "sirada", "calisiyor", "dogrulaniyor", "tamamlandi"]
        for current, target in zip(path, path[1:]):
            self.assertTrue(can_transition(current, target), f"{current}->{target}")

    def test_invalid_transition_rejected(self):
        self.assertFalse(can_transition("taslak", "tamamlandi"))
        self.assertFalse(can_transition("tamamlandi", "calisiyor"))
        self.assertFalse(can_transition("iptal", "sirada"))

    def test_pause_and_resume(self):
        self.assertTrue(can_transition("calisiyor", "duraklatildi"))
        self.assertTrue(can_transition("duraklatildi", "sirada"))

    def test_every_status_has_entry(self):
        for status in ALLOWED_TRANSITIONS:
            self.assertIn(status, ALLOWED_TRANSITIONS)


class ContractTests(unittest.TestCase):
    def test_valid_contract_passes(self):
        self.assertEqual(validate_contract(_contract()), [])

    def test_missing_goal_flagged(self):
        self.assertIn("goal", validate_contract(_contract(goal="")))

    def test_missing_success_criteria_flagged(self):
        self.assertIn("success_criteria", validate_contract(_contract(success_criteria="")))


class AssumptionTests(unittest.TestCase):
    def test_valid_green_assumption(self):
        a = Assumption(level="yesil", decision="Vanilla JS", rationale="bağımlılık yok",
                       confidence=0.8, alternative="React")
        self.assertEqual(validate_assumption(a), [])

    def test_kirmizi_rejected_as_assumption(self):
        a = Assumption(level="kirmizi", decision="Yayınla", rationale="hazır",
                       confidence=0.9, alternative="bekle")
        self.assertTrue(any("kırmızı" in v for v in validate_assumption(a)))

    def test_invalid_level_flagged(self):
        a = Assumption(level="mor", decision="x", rationale="y", confidence=0.5, alternative="z")
        self.assertTrue(any("geçersiz seviye" in v for v in validate_assumption(a)))

    def test_confidence_out_of_range(self):
        a = Assumption(level="yesil", decision="x", rationale="y", confidence=1.5, alternative="z")
        self.assertTrue(any("0-1" in v for v in validate_assumption(a)))


if __name__ == "__main__":
    unittest.main()
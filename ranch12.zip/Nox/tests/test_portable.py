"""Taşınabilirlik birim testleri."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.portable import MANIFEST_NAME, export_nox, verify_portable


class PortableTests(unittest.TestCase):
    def _make_project(self, root: Path) -> None:
        (root / "data").mkdir(parents=True)
        (root / "data" / "nox_seed.sqlite3").write_text("db", encoding="utf-8")
        (root / "pyproject.toml").write_text("[project]", encoding="utf-8")
        (root / "README.md").write_text("# Nox", encoding="utf-8")
        (root / "docs").mkdir()
        (root / "docs" / "foundation.md").write_text("# Foundation", encoding="utf-8")

    def test_export_creates_package_and_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Nox"
            self._make_project(root)
            out_dir = Path(tmp) / "out"
            result = export_nox(root, out_dir, include_model=False)
            self.assertTrue(result.output_path.exists())
            self.assertTrue(result.manifest_path.exists())
            self.assertGreater(result.files_count, 0)

    def test_package_contains_data_and_docs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Nox"
            self._make_project(root)
            result = export_nox(root, Path(tmp) / "out", include_model=False)
            with zipfile.ZipFile(result.output_path) as zf:
                names = zf.namelist()
            self.assertIn("data/nox_seed.sqlite3", names)
            self.assertIn("docs/foundation.md", names)
            self.assertIn(MANIFEST_NAME, names)

    def test_verify_clean_package_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Nox"
            self._make_project(root)
            result = export_nox(root, Path(tmp) / "out", include_model=False)
            self.assertEqual(verify_portable(result.output_path), [])

    def test_verify_missing_package_flagged(self):
        with tempfile.TemporaryDirectory() as tmp:
            issues = verify_portable(Path(tmp) / "yok.zip")
            self.assertTrue(any("paket yok" in i for i in issues))

    def test_manifest_content_valid(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Nox"
            self._make_project(root)
            result = export_nox(root, Path(tmp) / "out", include_model=False)
            manifest = json.loads(result.manifest_path.read_text(encoding="utf-8"))
            self.assertIn("created_at", manifest)
            self.assertIn("files", manifest)
            self.assertGreater(len(manifest["files"]), 0)


if __name__ == "__main__":
    unittest.main()
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from nox_seed.database import Database
from nox_seed.models import PatternAssessment


class DatabaseTests(unittest.TestCase):
    def test_records_events_and_patterns_separately(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Database(Path(directory) / "seed.sqlite3")
            database.initialize()
            event_id = database.record_event("ptbl.source", {"text": "Kısa bir örnek"})
            pattern_id = database.record_pattern(
                PatternAssessment(
                    observation="Metin kısa.",
                    interpretation="İletişim tercihi belirsiz.",
                    confidence=0.4,
                    pattern_type="dil",
                    evidence=["Kısa bir örnek"],
                    unknowns=["Daha fazla örnek gerekli."],
                ),
                source_event_id=event_id,
            )

            self.assertEqual(database.recent_events()[0]["id"], event_id)
            stored = database.recent_patterns()[0]
            self.assertEqual(stored.id, pattern_id)
            self.assertEqual(stored.source_event_id, event_id)
            self.assertEqual(stored.assessment.observation, "Metin kısa.")

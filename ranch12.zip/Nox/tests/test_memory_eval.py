"""Hafıza değerlendirme birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.memory_eval import build_memory_eval_prompt, parse_memory_eval

VALID = """KAYNAK: kullanıcı açıkça söyledi
ANLAM: EVET
DEGER: yüksek
KATEGORI: EVET
ONERI: kabul"""


class MemoryEvalTests(unittest.TestCase):
    def test_parses_valid_card(self):
        card = parse_memory_eval(VALID)
        self.assertEqual(card.meaningful, "EVET")
        self.assertEqual(card.value, "yüksek")
        self.assertEqual(card.recommendation, "kabul")

    def test_reject_recommendation(self):
        card = parse_memory_eval("KAYNAK: x\nANLAM: HAYIR\nDEGER: düşük\nKATEGORI: HAYIR\nONERI: reddet")
        self.assertEqual(card.recommendation, "reddedildi")

    def test_missing_oneri_raises(self):
        with self.assertRaises(ValueError):
            parse_memory_eval("KAYNAK: x")

    def test_prompt_contains_candidate(self):
        messages = build_memory_eval_prompt({"content": "Almanca", "category": "hedef"})
        self.assertIn("Almanca", messages[1]["content"])


if __name__ == "__main__":
    unittest.main()
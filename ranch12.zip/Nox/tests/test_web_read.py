"""Kontrollü internet erişimi birim testleri (gerçek ağ yok)."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.web_read import ALLOWED_DOMAINS, _domain_allowed, read_url_text


class DomainTests(unittest.TestCase):
    def test_allowed_domains(self):
        self.assertTrue(_domain_allowed("https://en.wikipedia.org/wiki/Nox"))
        self.assertTrue(_domain_allowed("https://docs.python.org/3/"))
        self.assertTrue(_domain_allowed("https://github.com/user/repo"))

    def test_disallowed_domain(self):
        self.assertFalse(_domain_allowed("https://evil.com/hack"))
        self.assertFalse(_domain_allowed("https://sub.evil.com/"))

    def test_invalid_url(self):
        self.assertFalse(_domain_allowed("ftp://example.com"))
        self.assertFalse(_domain_allowed("not-a-url"))


class ReadUrlTests(unittest.TestCase):
    @patch("nox_seed.web_read.request_approval", return_value=True)
    def test_disallowed_domain_rejected(self, _mock):
        with self.assertRaises(ValueError) as ctx:
            read_url_text("https://evil.com/")
        self.assertIn("İzinli olmayan domain", str(ctx.exception))

    @patch("nox_seed.web_read.request_approval", return_value=False)
    def test_user_rejection_raises(self, _mock):
        with self.assertRaises(ValueError) as ctx:
            read_url_text("https://en.wikipedia.org/wiki/Nox")
        self.assertIn("Kullanıcı reddetti", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
"""Örüntü birleştirme (recurrence) birim testleri."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.database import Database
from nox_seed.models import PatternAssessment
from nox_seed.recurrence import similarity


def _mk(observation: str, evidence: list[str]) -> PatternAssessment:
    return PatternAssessment(
        observation=observation, interpretation="", confidence=0.5,
        pattern_type="dil", evidence=evidence, unknowns=["u"],
    )


class SimilarityTests(unittest.TestCase):
    def test_identical_texts(self):
        self.assertAlmostEqual(similarity("aynı soru tekrar", "aynı soru tekrar"), 1.0)

    def test_disjoint_texts(self):
        self.assertEqual(similarity("elma armut", "masa sandalye"), 0.0)

    def test_partial_overlap(self):
        s = similarity("aynı soruyu üç kez sordu", "aynı soruyu iki kez sordu")
        self.assertGreater(s, 0.5)
        self.assertLess(s, 1.0)

    def test_empty(self):
        self.assertEqual(similarity("", "bir şey"), 0.0)


class MergeTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self._tmp.name) / "t.sqlite3")
        self.db.initialize()

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_similar_observations_merge_into_one_record(self):
        id1 = self.db.record_pattern(_mk("Toplantıda aynı soruyu üç kez üst üste sordu.", ["k1"]))
        id2 = self.db.record_pattern(_mk("Toplantıda aynı soruyu üç kez üst üste sordu.", ["k2"]))
        self.assertEqual(id1, id2)
        patterns = self.db.recent_patterns(10)
        self.assertEqual(len(patterns), 1)
        self.assertIn("k2", patterns[0].assessment.evidence)
        stages = self.db.pattern_stages(id1)
        self.assertEqual([s["stage"] for s in stages], ["recurrence"])

    def test_recurrence_raises_confidence_bounded(self):
        base = "Kullanıcı kısa mesajlarda noktalama kullanmıyor."
        pid = self.db.record_pattern(_mk(base, ["e0"]))
        for i in range(3):
            pid = self.db.record_pattern(_mk(base, [f"e{i+1}"]))
        stored = self.db.recent_patterns(1)[0]
        self.assertGreater(stored.assessment.confidence, 0.5)
        self.assertLessEqual(stored.assessment.confidence, 0.9)

    def test_dissimilar_observation_creates_new_record(self):
        self.db.record_pattern(_mk("Toplantıda az konuştu.", ["a"]))
        self.db.record_pattern(_mk("Kahvesini her sabah aynı saatte içiyor.", ["b"]))
        self.assertEqual(len(self.db.recent_patterns(10)), 2)

    def test_merge_disabled(self):
        text = "Aynı gözlem cümlesi burada duruyor."
        self.db.record_pattern(_mk(text, ["a"]))
        self.db.record_pattern(_mk(text, ["b"]), merge=False)
        self.assertEqual(len(self.db.recent_patterns(10)), 2)

    def test_archived_patterns_not_merged(self):
        pid = self.db.record_pattern(_mk("Arşivlenecek gözlem cümlesi burada.", ["a"]))
        self.db.set_pattern_status(pid, "archived")
        new_id = self.db.record_pattern(_mk("Arşivlenecek gözlem cümlesi burada.", ["b"]))
        self.assertNotEqual(pid, new_id)


if __name__ == "__main__":
    unittest.main()
"""Hizalanma (beklenti↔sonuç) birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.alignment import build_reflection_prompt, parse_reflection

VALID = """ESLESME: KISMI
SAPMA: çıktı süresi tahminin iki katı oldu
OGRENME: Türkçe uzun metin üretimi tahmin edilenden yavaş
GUVEN: 0.8"""


class ParseTests(unittest.TestCase):
    def test_parses_valid_reflection(self):
        r = parse_reflection(VALID)
        self.assertEqual(r.match, "KISMI")
        self.assertIn("iki katı", r.deviation)
        self.assertIn("yavaş", r.lesson)
        self.assertEqual(r.confidence, 0.8)

    def test_yok_deviation_cleared(self):
        r = parse_reflection("ESLESME: EVET\nSAPMA: YOK\nOGRENME: her şey yolunda\nGUVEN: 0.9")
        self.assertEqual(r.deviation, "")
        self.assertEqual(r.match, "EVET")

    def test_unknown_match_defaults_kismi(self):
        r = parse_reflection("ESLESME: belki\nGUVEN: 0.5")
        self.assertEqual(r.match, "KISMI")

    def test_missing_eslesme_raises(self):
        with self.assertRaises(ValueError):
            parse_reflection("SAPMA: x\nGUVEN: 0.5")

    def test_missing_guven_raises(self):
        with self.assertRaises(ValueError):
            parse_reflection("ESLESME: EVET")

    def test_confidence_clamped(self):
        r = parse_reflection("ESLESME: EVET\nGUVEN: 1.7")
        self.assertEqual(r.confidence, 1.0)

    def test_prompt_contains_both(self):
        messages = build_reflection_prompt("tahminim", "gerçek")
        self.assertIn("tahminim", messages[1]["content"])
        self.assertIn("gerçek", messages[1]["content"])


if __name__ == "__main__":
    unittest.main()
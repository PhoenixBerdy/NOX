from __future__ import annotations

import json
import unittest
from pathlib import Path


class PTBLCaseFixtureTests(unittest.TestCase):
    def test_initial_turkish_ptbl_cases_have_safe_expectations(self) -> None:
        fixture = Path(__file__).parent / "fixtures" / "ptbl_cases.json"
        cases = json.loads(fixture.read_text(encoding="utf-8"))

        self.assertGreaterEqual(len(cases), 5)
        for case in cases:
            self.assertTrue(case["id"])
            self.assertTrue(case["text"])
            self.assertTrue(case["expected_observation"])
            self.assertTrue(case["interpretation_boundary"])
            self.assertTrue(case["tags"])

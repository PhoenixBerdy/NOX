"""Proje doğrulayıcı birim testleri."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.validator import validate_project_files


class ValidatorTests(unittest.TestCase):
    def _write(self, root: Path, name: str, content: str) -> None:
        (root / name).write_text(content, encoding="utf-8")

    def test_clean_project_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            self._write(d, "index.html", '<link href="style.css"><script src="game.js"></script><div id="cow">')
            self._write(d, "style.css", "body { color: white; }")
            self._write(d, "game.js", "document.getElementById('cow');")
            self.assertEqual(validate_project_files(d), [])

    def test_missing_linked_file_flagged(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            self._write(d, "index.html", '<link href="yok.css">')
            issues = validate_project_files(d)
            self.assertTrue(any("yok.css" in i.message for i in issues))
            self.assertTrue(all(i.severity == "hata" for i in issues))

    def test_js_id_mismatch_flagged(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            self._write(d, "index.html", "<div id=\"game-container\">")
            self._write(d, "game.js", "document.getElementById('cow');")
            issues = validate_project_files(d)
            self.assertTrue(any("cow" in i.message for i in issues))

    def test_broken_rgba_flagged(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            self._write(d, "index.html", "<div></div>")
            self._write(d, "style.css", "background: rgba(255, 255, 2-10, 0.1);")
            issues = validate_project_files(d)
            self.assertTrue(any("rgba" in i.message for i in issues))

    def test_empty_project_no_issues(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(validate_project_files(Path(tmp)), [])


if __name__ == "__main__":
    unittest.main()
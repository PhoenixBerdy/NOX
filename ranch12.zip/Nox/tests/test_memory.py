"""Kalıcı hafıza birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.memory import MemoryCandidate, validate_candidate


class MemoryTests(unittest.TestCase):
    def test_valid_candidate(self):
        c = MemoryCandidate("Almanca öğreniyor", "sohbet", 0.8, "hedef")
        self.assertEqual(validate_candidate(c), [])

    def test_empty_content_flagged(self):
        c = MemoryCandidate("", "sohbet", 0.8, "hedef")
        self.assertIn("içerik boş", validate_candidate(c))

    def test_invalid_category_flagged(self):
        c = MemoryCandidate("x", "sohbet", 0.8, "rastgele")
        self.assertTrue(any("geçersiz kategori" in v for v in validate_candidate(c)))

    def test_confidence_out_of_range(self):
        c = MemoryCandidate("x", "sohbet", 1.5, "bilgi")
        self.assertTrue(any("0-1" in v for v in validate_candidate(c)))


if __name__ == "__main__":
    unittest.main()
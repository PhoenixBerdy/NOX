"""pattern_stages tablosu ve yaşam döngüsü geçişleri için birim testleri."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.database import Database
from nox_seed.models import PatternAssessment


class PatternStageTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self._tmp.name) / "test.sqlite3")
        self.db.initialize()
        assessment = PatternAssessment(
            observation="gözlem", interpretation="yorum", confidence=0.5,
            pattern_type="dil", evidence=["e"], unknowns=["u"],
        )
        self.pattern_id = self.db.record_pattern(assessment)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_stages_are_appended_not_overwritten(self) -> None:
        self.db.record_pattern_stage(self.pattern_id, "understand", {"a": 1})
        self.db.record_pattern_stage(self.pattern_id, "internalize", {"b": 2})
        stages = self.db.pattern_stages(self.pattern_id)
        self.assertEqual([s["stage"] for s in stages], ["understand", "internalize"])

    def test_set_pattern_status(self) -> None:
        self.db.set_pattern_status(self.pattern_id, "active")
        stored = self.db.recent_patterns(1)[0]
        self.assertEqual(stored.status, "active")

    def test_stages_of_empty_pattern(self) -> None:
        self.assertEqual(self.db.pattern_stages(9999), [])


if __name__ == "__main__":
    unittest.main()
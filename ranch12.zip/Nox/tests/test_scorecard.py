"""Puan haritası (8 eksen) birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.models import PatternAssessment
from nox_seed.scorecard import AXES, build_score_prompt, parse_score_card

VALID = """BELIRGINLIK: 0.8
OZGUNLUK: 0.3
KANIT_GUCU: 0.6
BAGLAM_DERINLIGI: 0.4
ZAMAN_CANLILIGI: 0.9
KARAKTER_REZONANSI: 0.5
ISLEVSEL_KATKI: 0.7
CELISKI_YOGUNLUGU: 0.2"""


def _mk(evidence: list[str]) -> PatternAssessment:
    return PatternAssessment(
        observation="gözlem", interpretation="", confidence=0.5,
        pattern_type="dil", evidence=evidence, unknowns=["u"],
    )


class ScoreCardTests(unittest.TestCase):
    def test_parses_all_axes(self):
        card = parse_score_card(VALID, _mk(["e"]))
        self.assertEqual(set(card.scores), set(AXES))
        self.assertEqual(card.scores["belirginlik"], 0.8)
        self.assertEqual(card.scores["celiski_yogunlugu"], 0.2)

    def test_missing_axes_default_to_half(self):
        card = parse_score_card("BELIRGINLIK: 0.9", _mk(["e"]))
        self.assertEqual(card.scores["belirginlik"], 0.9)
        self.assertEqual(card.scores["ozgunluk"], 0.5)

    def test_clamps_out_of_range(self):
        card = parse_score_card("BELIRGINLIK: 1.7", _mk(["e"]))
        self.assertEqual(card.scores["belirginlik"], 1.0)

    def test_empty_evidence_caps_evidence_strength(self):
        card = parse_score_card("KANIT_GUCU: 0.95", _mk([]))
        self.assertEqual(card.scores["kanit_gucu"], 0.4)

    def test_non_numeric_value_defaults(self):
        card = parse_score_card("BELIRGINLIK: yüksek", _mk(["e"]))
        self.assertEqual(card.scores["belirginlik"], 0.0)

    def test_prompt_contains_candidate(self):
        messages = build_score_prompt(_mk(["e"]))
        self.assertIn("aday_oruntu", messages[1]["content"])
        self.assertEqual(messages[0]["role"], "system")


if __name__ == "__main__":
    unittest.main()
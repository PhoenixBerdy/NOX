"""Kullanıcı modeli birim testleri."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.user_model import analyze_user_rhythm


def _event(kind: str, text: str, hour: int = 14) -> dict:
    return {
        "kind": kind,
        "created_at": f"2026-09-13T{hour:02d}:00:00+00:00",
        "payload": {"text": text},
    }


class UserModelTests(unittest.TestCase):
    def test_short_message_ratio(self):
        events = [
            _event("chat.user", "kısa"),
            _event("chat.user", "kısa da"),
            _event("chat.user", "çok uzun bir mesaj " * 50),
        ]
        rhythm = analyze_user_rhythm(events)
        self.assertAlmostEqual(rhythm.short_message_ratio, 2/3, places=2)

    def test_empty_events(self):
        rhythm = analyze_user_rhythm([])
        self.assertEqual(rhythm.short_message_ratio, 0.0)
        self.assertEqual(rhythm.avg_message_length, 0)

    def test_ignores_non_user_events(self):
        events = [
            _event("chat.user", "merhaba"),
            _event("chat.assistant", "yanıt"),
        ]
        rhythm = analyze_user_rhythm(events)
        self.assertEqual(rhythm.avg_message_length, len("merhaba"))

    def test_preferred_topics_extracted(self):
        events = [
            _event("chat.user", "almanca kelime listesi almanca"),
            _event("chat.user", "almanca sınav hazırlık almanca"),
        ]
        rhythm = analyze_user_rhythm(events)
        self.assertIn("almanca", rhythm.preferred_topics)

    def test_active_hours(self):
        events = [
            _event("chat.user", "sabah", hour=9),
            _event("chat.user", "akşam", hour=21),
        ]
        rhythm = analyze_user_rhythm(events)
        self.assertEqual(rhythm.active_hours, [9, 21])


if __name__ == "__main__":
    unittest.main()
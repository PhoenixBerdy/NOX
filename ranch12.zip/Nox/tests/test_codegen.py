"""Kod üretimi adımı birim testleri."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from nox_seed.codegen import (
    build_code_prompt,
    sanitize_filename,
    strip_code_fences,
    validate_output_path,
)


class SanitizeTests(unittest.TestCase):
    def test_plain_name(self):
        self.assertEqual(sanitize_filename("index.html"), "index.html")

    def test_path_traversal_stripped(self):
        self.assertEqual(sanitize_filename("../../etc/passwd"), "passwd")
        self.assertEqual(sanitize_filename("..\\..\\win.ini"), "win.ini")

    def test_unsafe_chars_removed(self):
        self.assertEqual(sanitize_filename("dosya adi.html"), "dosyaadi.html")


class PathGateTests(unittest.TestCase):
    def test_allowed_extension(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = validate_output_path(Path(tmp), 3, "index.html")
            self.assertTrue(str(target).endswith("index.html"))
            self.assertTrue(target.parent.exists())

    def test_disallowed_extension_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                validate_output_path(Path(tmp), 3, "kotu.exe")

    def test_traversal_in_filename_neutralized(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = validate_output_path(Path(tmp), 3, "../secret.html")
            self.assertEqual(target.name, "secret.html")
            self.assertEqual(target.parent.name, "3")


class FenceTests(unittest.TestCase):
    def test_strips_fences(self):
        self.assertEqual(strip_code_fences("```html\n<html></html>\n```"), "<html></html>")

    def test_plain_text_untouched(self):
        self.assertEqual(strip_code_fences("<html></html>"), "<html></html>")


class PromptTests(unittest.TestCase):
    def test_contains_contract_and_file(self):
        messages = build_code_prompt({"goal": "oyun"}, "index.html", "koyu tema")
        self.assertIn("oyun", messages[1]["content"])
        self.assertIn("index.html", messages[1]["content"])


if __name__ == "__main__":
    unittest.main()
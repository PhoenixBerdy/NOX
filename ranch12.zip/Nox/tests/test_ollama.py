from __future__ import annotations

import json
import unittest
from unittest.mock import patch

from nox_seed.config import Settings
from nox_seed.ollama import OllamaClient, OllamaError, parse_pattern_assessment


class PatternParserTests(unittest.TestCase):
    def test_parses_fenced_json_and_clamps_confidence(self) -> None:
        # Kalibrasyon (12 Eylül 2026): tek bilinmeyen maddesi güveni 0.7 ile
        # sınırlar; bu yüzden bu testte iki bilinmeyen veriyoruz ki 0.85
        # tavanı uygulanabilsin.
        assessment = parse_pattern_assessment(
            """```json
            {"observation":"Soru iki kez sorulmuş.","interpretation":"Vurgu olabilir.",
             "confidence":1.3,"pattern_type":"dil","evidence":["iki kez"],
             "unknowns":["bağlam yok","zaman damgası yok"]}
            ```"""
        )
        self.assertEqual(assessment.confidence, 0.85)
        self.assertEqual(assessment.evidence, ["iki kez"])

    def test_calibration_caps_confidence_with_single_unknown(self) -> None:
        assessment = parse_pattern_assessment(
            json.dumps({
                "observation": "Gözlem.", "interpretation": "",
                "confidence": 0.95, "pattern_type": "dil",
                "evidence": ["kanıt"], "unknowns": ["tek bilinmeyen"],
            })
        )
        self.assertEqual(assessment.confidence, 0.7)

    def test_ambiguity_signal_lowers_confidence_cap(self) -> None:
        assessment = parse_pattern_assessment(
            json.dumps({
                "observation": "İfade muğlaktır.", "interpretation": "",
                "confidence": 0.9, "pattern_type": "dil",
                "evidence": ["kanıt"], "unknowns": ["a", "b"],
            })
        )
        self.assertEqual(assessment.confidence, 0.75)

    def test_missing_evidence_or_unknowns_caps_confidence(self) -> None:
        assessment = parse_pattern_assessment(
            json.dumps({
                "observation": "Gözlem.", "interpretation": "",
                "confidence": 0.95, "pattern_type": "dil",
                "evidence": [], "unknowns": [],
            })
        )
        self.assertEqual(assessment.confidence, 0.4)

    def test_rejects_non_json_model_output(self) -> None:
        with self.assertRaises(OllamaError):
            parse_pattern_assessment("Bu JSON değil.")

    def test_ptbl_request_uses_json_mode(self) -> None:
        settings = Settings.from_environment()
        client = OllamaClient(settings)
        with patch.object(
            client,
            "_request",
            return_value={
                "message": {
                    "content": '{"observation":"x","interpretation":"","confidence":0.1,"pattern_type":"diğer","evidence":[],"unknowns":[]}'
                }
            },
        ) as request:
            client.assess_pattern("örnek")
        self.assertTrue(request.call_args.kwargs["json_mode"])
        self.assertEqual(
            request.call_args.kwargs["max_output_tokens"],
            settings.assessment_max_output_tokens,
        )

    def test_chat_includes_recent_history_after_the_system_prompt(self) -> None:
        settings = Settings.from_environment()
        client = OllamaClient(settings)
        history = [
            {"role": "user", "content": "Önceki mesaj"},
            {"role": "assistant", "content": "Önceki yanıt"},
        ]
        with patch.object(client, "_request", return_value={"message": {"content": "Yeni yanıt"}}) as request:
            self.assertEqual(client.chat("Yeni mesaj", history=history), "Yeni yanıt")
        messages = request.call_args.args[0]
        self.assertEqual(messages[1:-1], history)
        self.assertEqual(messages[-1], {"role": "user", "content": "Yeni mesaj"})

    def test_short_chat_uses_a_small_response_budget(self) -> None:
        settings = Settings.from_environment()
        client = OllamaClient(settings)
        with patch.object(client, "_request", return_value={"message": {"content": "Kısa yanıt"}}) as request:
            client.chat("Selam")
        self.assertEqual(request.call_args.kwargs["max_output_tokens"], min(settings.max_output_tokens, 96))

    def test_stream_chat_forwards_chunks_and_requests_streaming(self) -> None:
        class StreamResponse:
            def __init__(self, lines: list[bytes]) -> None:
                self.lines = lines

            def __enter__(self) -> "StreamResponse":
                return self

            def __exit__(self, *_args: object) -> None:
                return None

            def __iter__(self):
                return iter(self.lines)

        settings = Settings.from_environment()
        client = OllamaClient(settings)
        received: list[str] = []
        lines = [
            (json.dumps({"message": {"content": "Merhaba"}}) + "\n").encode("utf-8"),
            (json.dumps({"message": {"content": " dünya"}, "done": True}) + "\n").encode("utf-8"),
        ]
        with patch("nox_seed.ollama.urlopen", return_value=StreamResponse(lines)) as open_request:
            answer = client.stream_chat("Selam", on_chunk=received.append)

        payload = json.loads(open_request.call_args.args[0].data.decode("utf-8"))
        self.assertTrue(payload["stream"])
        self.assertEqual(payload["options"]["num_predict"], min(settings.max_output_tokens, 96))
        self.assertEqual(received, ["Merhaba", " dünya"])
        self.assertEqual(answer, "Merhaba dünya")
from __future__ import annotations

import argparse
import json
from collections.abc import Sequence

from .config import Settings
from .database import Database
from .ollama import OllamaClient, OllamaError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Nox Seed v0 yerel metin arayüzü")
    subcommands = parser.add_subparsers(dest="command", required=True)

    subcommands.add_parser("init", help="Yerel veri deposunu hazırla")

    chat = subcommands.add_parser("chat", help="Nox ile tek mesajlık sohbet et")
    chat.add_argument("message")

    assess = subcommands.add_parser("assess", help="Metin için PTBL değerlendirmesi oluştur")
    assess.add_argument("text")

    patterns = subcommands.add_parser("patterns", help="Son PTBL kayıtlarını göster")
    patterns.add_argument("--limit", type=int, default=10)

    events = subcommands.add_parser("events", help="Son olay kayıtlarını göster")
    events.add_argument("--limit", type=int, default=10)

    understand = subcommands.add_parser("understand", help="Aday örüntü için 2. aşama (anlamak) kartı üret")
    understand.add_argument("pattern_id", type=int)
    understand.add_argument("text", help="Örüntünün geldiği kaynak metin")

    internalize = subcommands.add_parser("internalize", help="Aday örüntü için 3. aşama (içselleştirme) önerisi üret")
    internalize.add_argument("pattern_id", type=int)

    approve = subcommands.add_parser("approve", help="Örüntünün yaşam döngüsü durumunu kullanıcı onayıyla ayarla")
    approve.add_argument("pattern_id", type=int)
    approve.add_argument("status", choices=["candidate", "active", "context-bound", "archived"])

    score = subcommands.add_parser("score", help="Aday örüntü için 8 eksenli puan haritası üret")
    score.add_argument("pattern_id", type=int)
    project = subcommands.add_parser("project", help="Proje işlemleri")
    project_sub = project.add_subparsers(dest="project_command", required=True)

    p_new = project_sub.add_parser("new", help="Yeni proje: sözleşme taslağı üret")
    p_new.add_argument("request", help="Kullanıcının proje isteği (doğal dil)")

    p_list = project_sub.add_parser("list", help="Projeleri listele")
    p_list.add_argument("--limit", type=int, default=20)

    p_status = project_sub.add_parser("status", help="Proje durumunu ve geçişleri göster")
    p_status.add_argument("project_id", type=int)

    p_advance = project_sub.add_parser("advance", help="Proje durumunu ilerlet")
    p_advance.add_argument("project_id", type=int)
    p_advance.add_argument("target")
    p_advance.add_argument("reason", nargs="?", default="kullanıcı geçişi")
    p_step = project_sub.add_parser("step", help="Projenin bir sonraki kontrol noktası adımını çalıştır")
    p_step.add_argument("project_id", type=int)
    p_step.add_argument("step", help="Adım tanımı (örn. 'araştırma', 'uygulama')")
    p_code = project_sub.add_parser("code", help="Proje için kod dosyası üret (izole klasöre yazar)")
    p_code.add_argument("project_id", type=int)
    p_code.add_argument("filename", help="Üretilecek dosya adı (örn. index.html)")
    p_code.add_argument("--instruction", default="", help="Ek üretim talimatı")
    p_reflect = project_sub.add_parser("reflect", help="Beklenti↔sonuç öz-yansıması üret (hizalanma döngüsü)")
    p_reflect.add_argument("project_id", type=int)
    p_reflect.add_argument("expectation", help="Adım öncesi tahminin neydi?")
    p_reflect.add_argument("outcome", help="Gerçekte ne oldu?")
    p_validate = project_sub.add_parser("validate", help="Proje dosyalarını çapraz denetle (W3 tutarlılığı)")
    p_validate.add_argument("project_id", type=int)
    p_pdf = project_sub.add_parser("pdf", help="Proje için PDF belge üret (izole klasöre yazar)")
    p_pdf.add_argument("project_id", type=int)
    p_pdf.add_argument("title", help="Belgenin başlığı")    
    
    subcommands.add_parser("repl", help="Etkileşimli metin arayüzünü başlat")
    subcommands.add_parser("demo", help="Nox Seed masaüstü demosunu başlat")
    serve = subcommands.add_parser("serve", help="NOX localhost sunucusunu başlat (Tauri backend)")
    serve.add_argument("--port", type=int, default=8000)
    read = subcommands.add_parser("read", help="Kontrollü internet erişimi: URL'den metin oku")
    read.add_argument("url")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = Settings.from_environment()
    database = Database(settings.database_path)
    database.initialize()

    if args.command == "init":
        print(f"Nox Seed veri deposu hazır: {settings.database_path}")
        return 0
    if args.command == "chat":
        return _chat(database, settings, args.message)
    if args.command == "assess":
        return _assess(database, settings, args.text)
    if args.command == "patterns":
        _print_patterns(database, args.limit)
        return 0
    if args.command == "events":
        print(json.dumps(database.recent_events(args.limit), ensure_ascii=False, indent=2))
        return 0
    if args.command == "understand":
        return _understand(database, settings, args.pattern_id, args.text)
    if args.command == "internalize":
        return _internalize(database, settings, args.pattern_id)
    if args.command == "approve":
        database.set_pattern_status(args.pattern_id, args.status)
        print(f"Örüntü #{args.pattern_id} durumu '{args.status}' olarak güncellendi.")
        return 0
    if args.command == "score":
        return _score(database, settings, args.pattern_id)
    if args.command == "project":
        return _project(database, settings, args)    
    if args.command == "repl":
        return _repl(database, settings)
    if args.command == "demo":
        from .demo import run_demo

        run_demo(database, settings)
        return 0
    if args.command == "serve":
        from .server import run_server

        run_server(port=args.port)
        return 0 
    if args.command == "read":
        from .web_read import read_url_text

        try:
            text = read_url_text(args.url)
            print(text[:2000] + ("\n... (kesildi)" if len(text) > 2000 else ""))
            return 0
        except ValueError as exc:
            print(f"Hata: {exc}")
            return 1            
    return 2


def _chat(database: Database, settings: Settings, message: str) -> int:
    event_id = database.record_event("chat.user", {"text": message})
    try:
        from .backend import get_backend
        backend = get_backend(settings)
        answer = backend.chat([{"role": "user", "content": message}]).content
    except OllamaError as exc:
        database.record_event("chat.error", {"message": str(exc), "source_event_id": event_id})
        print(f"Nox hatası: {exc}")
        return 1
    database.record_event("chat.assistant", {"text": answer, "source_event_id": event_id})
    print(f"Nox: {answer}")
    return 0


def _assess(database: Database, settings: Settings, text: str) -> int:
    event_id = database.record_event("ptbl.source", {"text": text})
    try:
        assessment = OllamaClient(settings).assess_pattern(text)
    except OllamaError as exc:
        database.record_event("ptbl.error", {"message": str(exc), "source_event_id": event_id})
        print(f"Nox hatası: {exc}")
        return 1
    pattern_id = database.record_pattern(assessment, source_event_id=event_id)
    print(json.dumps({"id": pattern_id, **assessment.as_dict()}, ensure_ascii=False, indent=2))
    return 0


def _understand(database: Database, settings: Settings, pattern_id: int, text: str) -> int:
    """2. aşama: aday örüntü için anlama kartı üretir ve ayrı kayıt olarak ekler."""
    from .ptbl_pipeline import build_understand_prompt, parse_understanding_card

    stored = next((p for p in database.recent_patterns(100) if p.id == pattern_id), None)
    if stored is None:
        print(f"Örüntü #{pattern_id} bulunamadı.")
        return 1
    client = OllamaClient(settings)
    raw = ""
    card = None
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = client.run_ptbl_stage(build_understand_prompt(stored.assessment, text))
            card = parse_understanding_card(raw)
            break
        except (OllamaError, ValueError) as exc:
            last_error = exc
            database.record_event("ptbl.stage_error", {
                "pattern_id": pattern_id, "stage": "understand",
                "attempt": attempt + 1, "error": str(exc),
                "raw_output": raw[:2000],
            })
    if card is None:
        print(f"Nox hatası: {last_error}")
        print("(Ham model çıktısı olay günlüğüne kaydedildi: python -m nox_seed events)")
        return 1
    database.record_pattern_stage(pattern_id, "understand", card.as_dict())
    print(json.dumps({"pattern_id": pattern_id, **card.as_dict()}, ensure_ascii=False, indent=2))
    return 0


def _internalize(database: Database, settings: Settings, pattern_id: int) -> int:
    """3. aşama: anlama kartı varsa içselleştirme ÖNERİSİ üretir ve kaydeder."""
    from .ptbl_pipeline import (
        UnderstandingCard,
        build_internalize_prompt,
        parse_internalization_proposal,
    )

    stored = next((p for p in database.recent_patterns(100) if p.id == pattern_id), None)
    if stored is None:
        print(f"Örüntü #{pattern_id} bulunamadı.")
        return 1
    stages = database.pattern_stages(pattern_id)
    understandings = [s for s in stages if s["stage"] == "understand"]
    if not understandings:
        print(f"Örüntü #{pattern_id} için önce 'understand' çalıştırılmalı (2. aşama yok).")
        return 1
    card = UnderstandingCard(**understandings[-1]["payload"])
    client = OllamaClient(settings)
    raw = ""
    proposal = None
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = client.run_ptbl_stage(build_internalize_prompt(stored.assessment, card))
            proposal = parse_internalization_proposal(raw, has_open_questions=bool(card.open_questions))
            break
        except (OllamaError, ValueError) as exc:
            last_error = exc
            database.record_event("ptbl.stage_error", {
                "pattern_id": pattern_id, "stage": "internalize",
                "attempt": attempt + 1, "error": str(exc),
                "raw_output": raw[:2000],
            })
    if proposal is None:
        print(f"Nox hatası: {last_error}")
        print("(Ham model çıktısı olay günlüğüne kaydedildi: python -m nox_seed events)")
        return 1
    database.record_pattern_stage(pattern_id, "internalize", proposal.as_dict())
    print(json.dumps({"pattern_id": pattern_id, **proposal.as_dict()}, ensure_ascii=False, indent=2))
    if proposal.recommendation != "candidate":
        print(f"\nÖneri: '{proposal.recommendation}'. Uygulamak için:")
        print(f"  python -m nox_seed approve {pattern_id} {proposal.recommendation}")
    return 0


def _score(database: Database, settings: Settings, pattern_id: int) -> int:
    """8 eksenli puan haritası üretir ve 'score' aşaması olarak kaydeder."""
    from .scorecard import build_score_prompt, parse_score_card

    stored = next((p for p in database.recent_patterns(100) if p.id == pattern_id), None)
    if stored is None:
        print(f"Örüntü #{pattern_id} bulunamadı.")
        return 1
    client = OllamaClient(settings)
    raw = ""
    card = None
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = client.run_ptbl_stage(build_score_prompt(stored.assessment))
            card = parse_score_card(raw, stored.assessment)
            break
        except (OllamaError, ValueError) as exc:
            last_error = exc
            database.record_event("ptbl.stage_error", {
                "pattern_id": pattern_id, "stage": "score",
                "attempt": attempt + 1, "error": str(exc),
                "raw_output": raw[:2000],
            })
    if card is None:
        print(f"Nox hatası: {last_error}")
        return 1
    database.record_pattern_stage(pattern_id, "score", card.as_dict())
    print(json.dumps({"pattern_id": pattern_id, **card.as_dict()}, ensure_ascii=False, indent=2))
    return 0

def _project(database: Database, settings: Settings, args: argparse.Namespace) -> int:
    from .projects import ProjectContract, validate_contract

    if args.project_command == "new":
        from .contract_builder import build_contract_prompt, parse_contract_text

        contract = None
        raw = ""
        last_error: Exception | None = None
        for attempt in range(2):
            try:
                raw = OllamaClient(settings).run_ptbl_stage(build_contract_prompt(args.request))
                contract = parse_contract_text(raw, args.request[:80])
                break
            except (OllamaError, ValueError) as exc:
                last_error = exc
                database.record_event("project.contract_error", {
                    "request": args.request, "attempt": attempt + 1,
                    "error": str(exc), "raw_output": raw[:2000],
                })
        if contract is None:
            print(f"Sözleşme üretilemedi: {last_error}")
            print("(Ham çıktı olay günlüğünde: python -m nox_seed events)")
            return 1
        missing = validate_contract(contract)
        if missing:
            print(f"Sözleşme eksik alanlar: {', '.join(missing)}")
            return 1
        project_id = database.create_project(contract)
        database.record_event("project.created", {"project_id": project_id, "request": args.request})
        print(json.dumps({"id": project_id, "status": "taslak", **contract.as_dict()}, ensure_ascii=False, indent=2))
        print(f"\nSözleşmeyi yayımlamak için: python -m nox_seed project advance {project_id} sozlesme")
        return 0

    if args.project_command == "list":
        projects = database.list_projects(args.limit)
        if not projects:
            print("Henüz proje yok.")
            return 0
        for p in projects:
            print(f"#{p['id']} [{p['status']}] {p['contract']['title']}")
        return 0

    if args.project_command == "status":
        projects = {p["id"]: p for p in database.list_projects(200)}
        p = projects.get(args.project_id)
        if p is None:
            print(f"Proje #{args.project_id} bulunamadı.")
            return 1
        print(json.dumps(p, ensure_ascii=False, indent=2))
        transitions = database.project_transitions(args.project_id)
        if transitions:
            print("\nGeçişler:")
            for t in transitions:
                print(f"  {t['from_status']} → {t['to_status']}  ({t['reason']})")
        return 0

    if args.project_command == "advance":
        ok = database.transition_project(args.project_id, args.target, args.reason)
        if ok:
            print(f"Proje #{args.project_id} → {args.target}")
            return 0
        print(f"Geçiş reddedildi: mevcut durumdan '{args.target}' durumuna geçilemez.")
        return 1
        
    if args.project_command == "step":
        return _project_step(database, settings, args.project_id, args.step)    
    if args.project_command == "code":
        return _project_code(database, settings, args.project_id, args.filename, args.instruction)
    if args.project_command == "reflect":
        return _project_reflect(database, settings, args.project_id, args.expectation, args.outcome)  
    if args.project_command == "validate":
        return _project_validate(database, settings, args.project_id)    
    if args.project_command == "pdf":
        return _project_pdf(database, settings, args.project_id, args.title)
    
    return 2

def _project_step(database: Database, settings: Settings, project_id: int, step: str) -> int:
    """Bir kontrol noktası adımını çalıştırır; çıktıyı ve sonraki adımı kaydeder."""
    from .executor import build_step_prompt, parse_step_result

    projects = {p["id"]: p for p in database.list_projects(200)}
    p = projects.get(project_id)
    if p is None:
        print(f"Proje #{project_id} bulunamadı.")
        return 1
    if p["status"] == "taslak":
        print(f"Proje #{project_id} henüz taslak; önce sözleşmeyi yayımla: project advance {project_id} sozlesme")
        return 1
    client = OllamaClient(settings)
    previous = [e["payload"].get("output", "") for e in database.recent_events(50)
                if e["kind"] == "project.step" and e["payload"].get("project_id") == project_id]
    raw = ""
    result = None
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = client.run_ptbl_stage(build_step_prompt(p["contract"], step, previous))
            result = parse_step_result(raw)
            break
        except (OllamaError, ValueError) as exc:
            last_error = exc
            database.record_event("project.step_error", {
                "project_id": project_id, "step": step, "attempt": attempt + 1,
                "error": str(exc), "raw_output": raw[:2000],
            })
    if result is None:
        print(f"Adım çalıştırılamadı: {last_error}")
        print("(Ham çıktı olay günlüğünde: python -m nox_seed events)")
        return 1
    database.record_event("project.step", {
        "project_id": project_id, "step": step,
        "output": result.output, "next_step": result.next_step, "note": result.note,
    })
    print(json.dumps({"project_id": project_id, "step": step, **result.as_dict()}, ensure_ascii=False, indent=2))
    if result.note:
        print(f"\nNot: {result.note}")
    if result.next_step.upper() == "TAMAM":
        print(f"\nProje doğrulamaya hazır: python -m nox_seed project advance {project_id} dogrulaniyor")
    else:
        print(f"\nSonraki adım: python -m nox_seed project step {project_id} \"{result.next_step}\"")
    return 0 
    
def _project_code(database: Database, settings: Settings, project_id: int, filename: str, instruction: str) -> int:
    """Kod dosyası üretir; güvenlik kapısından geçirip izole klasöre yazar."""
    from .codegen import build_code_prompt, strip_code_fences, validate_output_path

    projects = {p["id"]: p for p in database.list_projects(200)}
    p = projects.get(project_id)
    if p is None:
        print(f"Proje #{project_id} bulunamadı.")
        return 1
    projects_root = settings.project_root / "data" / "projects"
    try:
        target = validate_output_path(projects_root, project_id, filename)
    except ValueError as exc:
        print(f"Güvenlik kapısı: {exc}")
        return 1
    client = OllamaClient(settings)
    raw = ""
    content = None
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = client.run_ptbl_stage(build_code_prompt(p["contract"], filename, instruction))
            content = strip_code_fences(raw)
            if not content:
                raise ValueError("Model boş içerik üretti.")
            break
        except (OllamaError, ValueError) as exc:
            last_error = exc
            database.record_event("project.code_error", {
                "project_id": project_id, "filename": filename, "attempt": attempt + 1,
                "error": str(exc), "raw_output": raw[:2000],
            })
    if content is None:
        print(f"Kod üretilemedi: {last_error}")
        return 1
    target.write_text(content, encoding="utf-8")
    database.record_event("project.code_generated", {
        "project_id": project_id, "filename": filename,
        "path": str(target), "bytes": len(content.encode("utf-8")),
    })
    print(f"Üretildi: {target}")
    print(f"Boyut: {len(content.encode('utf-8'))} bayt")
    return 0
    
def _project_reflect(database: Database, settings: Settings, project_id: int, expectation: str, outcome: str) -> int:
    """Beklenti↔sonuç öz-yansıması üretir ve hizalanma kaydı olarak saklar."""
    from .alignment import build_reflection_prompt, parse_reflection

    projects = {p["id"]: p for p in database.list_projects(200)}
    if project_id not in projects:
        print(f"Proje #{project_id} bulunamadı.")
        return 1
    client = OllamaClient(settings)
    raw = ""
    result = None
    last_error: Exception | None = None
    for attempt in range(2):
        try:
            raw = client.run_ptbl_stage(build_reflection_prompt(expectation, outcome))
            result = parse_reflection(raw)
            break
        except (OllamaError, ValueError) as exc:
            last_error = exc
            database.record_event("project.reflect_error", {
                "project_id": project_id, "attempt": attempt + 1,
                "error": str(exc), "raw_output": raw[:2000],
            })
    if result is None:
        print(f"Yansıma üretilemedi: {last_error}")
        return 1
    database.record_event("project.reflection", {
        "project_id": project_id,
        "expectation": expectation, "outcome": outcome,
        **result.as_dict(),
    })
    print(json.dumps({"project_id": project_id, **result.as_dict()}, ensure_ascii=False, indent=2))
    if result.deviation:
        print(f"\nSapma: {result.deviation}")
    print(f"Ders: {result.lesson}")
    return 0

def _project_validate(database: Database, settings: Settings, project_id: int) -> int:
    """Proje klasöründeki dosyaları çapraz denetler; sorunları raporlar."""
    from .validator import validate_project_files

    projects_root = settings.project_root / "data" / "projects" / str(project_id)
    if not projects_root.exists():
        print(f"Proje #{project_id} için dosya klasörü yok: {projects_root}")
        return 1
    issues = validate_project_files(projects_root)
    database.record_event("project.validated", {
        "project_id": project_id,
        "issue_count": len(issues),
        "issues": [i.as_dict() for i in issues],
    })
    if not issues:
        print(f"Proje #{project_id}: sorun yok. Dosyalar tutarlı.")
        return 0
    print(f"Proje #{project_id}: {len(issues)} sorun bulundu")
    for i in issues:
        print(f"  [{i.severity}] {i.message}")
    return 1
    
def _project_pdf(database: Database, settings: Settings, project_id: int, title: str) -> int:
    """Proje adımlarının çıktılarından tek sayfalık PDF belge üretir."""
    from .pdfgen import build_pdf

    projects = {p["id"]: p for p in database.list_projects(200)}
    p = projects.get(project_id)
    if p is None:
        print(f"Proje #{project_id} bulunamadı.")
        return 1
    steps = [
        e["payload"] for e in database.recent_events(100)
        if e["kind"] == "project.step" and e["payload"].get("project_id") == project_id
    ]
    if not steps:
        print(f"Proje #{project_id} için adım çıktısı yok; önce 'project step' çalıştır.")
        return 1
    sections = [(s.get("step", "adım"), s.get("output", "")) for s in steps]
    projects_root = settings.project_root / "data" / "projects"
    projects_root.mkdir(parents=True, exist_ok=True)
    target = projects_root / str(project_id) / f"{title.replace(' ', '_')}.pdf"
    out = build_pdf(title, sections, target)
    database.record_event("project.pdf_generated", {
        "project_id": project_id, "title": title,
        "path": str(out), "bytes": out.stat().st_size,
    })
    print(f"PDF üretildi: {out}")
    print(f"Boyut: {out.stat().st_size} bayt · {len(sections)} bölüm")
    return 0    
   
def _print_patterns(database: Database, limit: int) -> None:
    for pattern in database.recent_patterns(limit):
        print(
            f"#{pattern.id} [{pattern.status}] {pattern.assessment.pattern_type} "
            f"güven={pattern.assessment.confidence:.2f}\n"
            f"  Gözlem: {pattern.assessment.observation}\n"
            f"  Yorum: {pattern.assessment.interpretation}\n"
        )


def _repl(database: Database, settings: Settings) -> int:
    print("Nox Seed v0 hazır. /yardim, /analiz METIN, /oruntuler, /olaylar, /cikis")
    while True:
        try:
            text = input("Sen> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nNox Seed kapatıldı.")
            return 0
        if not text:
            continue
        if text in {"/cikis", "/quit", "/exit"}:
            return 0
        if text == "/yardim":
            print("/analiz METIN, /oruntuler, /olaylar, /cikis veya normal sohbet mesajı")
            continue
        if text.startswith("/analiz "):
            _assess(database, settings, text.removeprefix("/analiz "))
            continue
        if text == "/oruntuler":
            _print_patterns(database, 10)
            continue
        if text == "/olaylar":
            print(json.dumps(database.recent_events(10), ensure_ascii=False, indent=2))
            continue
        _chat(database, settings, text)
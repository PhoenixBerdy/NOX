# Nox — Güncel Durum

Son güncelleme: 14 Eylül 2026 (gece yarısı oturumu)

## Neredeyiz?

**L2 (Project Core) TAMAMLANDI.** **L3 (Platform alfa) TAMAMLANDI.** **L4 (Güvenlik kapısı) TAMAMLANDI.**
**L5 (İnternet erişimi ilk adım) TAMAMLANDI.** **L8 (Evrim iskeleti) TAMAMLANDI.**
**Ollama'sız NOX tam çalışıyor** — llama.cpp GGUF, kendi sunucusu, Tauri platformu.
**Taşınabilirlik iskeleti hazır** — Almanya paketi üretildi, doğrulandı.

## Son iki günün zaferleri (13-14 Eylül)

### Gün 1 (13 Eylül)
- **L2 Project Core:** 4 proje, 1 oyun, hizalanma canlı, Proje Masası
- **Platform alfa (Tauri):** sol ray + merkez sohbet + sağ kayar panel, streaming, SQLite köprüsü
- **L4 Güvenlik kapısı:** eylem sınıflandırması (yeşil/lime/sarı/kırmızı), izole klasör, kullanıcı onayı akışı
- **L5 İnternet erişimi:** kontrollü okuma (domain izin listesi, onay), PTBL internet örüntüleri
- **Ollama'sız NOX:** llama.cpp GGUF (Qwen3-4B-Instruct-2507), kendi beyniyle, think kapalı
- **Kendi sunucu:** `python -m nox_seed serve` → localhost:8000, Tauri bağlantısı
- **Markdown:** kod blokları, kalın/italik, başlıklar (Tauri platformunda)

### Gün 2 (14 Eylül)
- **L8 Evrim iskeleti:** pasiflik ölçütü (4 sinyal), reseptör (aynı fikir tanıma), aday değerlendirme (PTBL kartı)
- **PTBL genişleme:** kullanıcı modeli (kısa mesaj oranı, konular, aktif saatler — açık kayıt)
- **Taşınabilirlik:** `export` komutu, 22 dosyalık paket, manifest + doğrulama temiz
- **129 test yeşil**

## Bilinen sınırlar / açık işler

- "Sen Nox" cümle yapısı (sistem promptu ince ayarı gerekir)
- Tauri alfa: Proje Masası basit, markdown minimal
- PDF Türkçe font: platform aşamasında
- W5 (medya): platform aşamasında (harici araç gerekir)
- Evrim: pasiflik ölçütü gerçek sistem sinyallerine bağlanmadı (şu an manuel/test)

## Açık kararlar (kullanıcı bekleniyor)

1. **Üretim geçişi:** llama.cpp varsayılan backend yapılsın mı? (Şu an NOX_BACKEND=llama_cpp gerekli)
2. **Kişilik değerlendirme oturumu:** 4 soruluk demo sözleşme testi yapıldı mı?
3. **Yeni logo/kimlik:** platform aşamasına mı ertelendi?
4. **Eğitim müfredatı:** zamanı geldi mi?

## Sıradaki katmanlar

- **L6 (Hafıza):** kalıcı kişisel hafıza (aday → değerlendirme → kabul/askı)
- **L7 (Çoklu cihaz):** ana düğüm + yetkili istemciler (platform-target.md)
- **L8 üstü (Evrim üretimi):** pasiflik ölçütü sistem sinyallerine bağlanacak, aday fikir üretimi otonom
- **L9 (Final):** taşınabilir paket + kullanıcı bildirimi

## Yeni sohbette devam komutu

`C:\Users\Yağız Cem\Documents\Projects\Nox` projesine devam et. Önce `README.md`,
`docs/foundation.md`, `docs/current-state.md` (bu dosya), `docs/seed-v0.md` ve
`docs/roadmap.md`'yi oku. L2-L5, L8 iskeleti tamamlandı; L6-L7 sırada.
Ollama'sız çalışma: `$env:NOX_BACKEND = "llama_cpp"; python -m nox_seed serve`.
Test komutu: `$env:PYTHONPATH = "src"; python -m unittest discover -s tests`
(beklenen: 129 test, OK).
# Nox Yol Haritası

Katman haritası (L0-L9) ile ilk aşamaların birleşik görünümü. Her katmanın
ayrıntısı `BLUEPRINTS.md` ve `foundation.md` içindedir; bu dosya yalnızca
sıra ve durum gösterir.

## 0. Temel tasarım — TAMAMLANDI

Karakter çekirdeği, PTBL sosyal algısı, zaman damgası, puan haritası, öz-yansıma
ve özgün düşünce ilkeleri oluşturuldu. Ana belge: `foundation.md`.

## 1. Nox Seed v0 — TAMAMLANDI

Yerel bilgisayarda çalışan küçük Nox çekirdeği: konuşma, olay kaydı, PTBL
değerlendirme akışı. Teknik kılavuz: `seed-v0.md`.

## 2. L1 — PTBL Derinleştirme — TAMAMLANDI (13 Eylül 2026)

Kalite kapısı, güven kalibrasyonu, 15 vakalı regresyon fikstürü, üç aşamalı
boru hattı (fark et → anla → içselleştir), örüntü birleştirme, 8 eksenli puan
haritası. 42 test yeşil.

## 3. L2 — Project Core — TAMAMLANDI (13 Eylül 2026)

Proje sözleşmesi, yaşam döngüsü, varsayım defteri, kontrol noktaları, aç
bırakmayan öncelik kuyruğu, hizalanma döngüsü, izole proje klasörü + güvenlik
kapısı ilk sürümü. 4 proje üretildi, 1 oyun oynandı. Ayrıntı: `BLUEPRINTS.md` Bölüm 1.

## 4. L3 — Platform alfa — TAMAMLANDI (13 Eylül 2026)

Tauri masaüstü uygulaması: sol ray + merkez sohbet + sağ kayar panel, streaming,
SQLite köprüsü, markdown desteği. Ollama'sız çalışma (llama.cpp GGUF + NOX
localhost sunucusu). Ayrıntı: `BLUEPRINTS.md` Bölüm 3.

## 5. L4 — Güvenlik kapısı — TAMAMLANDI (13 Eylül 2026)

Eylem sınıflandırması (yeşil/lime/sarı/kırmızı), izole klasör denetimi,
kullanıcı onayı akışı. Canlı kanıt: klasör dışı yazma engellendi.

## 6. L5 — İnternet erişimi (ilk adım) — TAMAMLANDI (13 Eylül 2026)

Kontrollü okuma: domain izin listesi, kullanıcı onayı, içerik sınırı.
PTBL internet örüntüleri: okunan metinden aday üretme (canlı kanıt).

## 7. L6 — Hafıza — SIRADAKİ

Kalıcı kişisel hafıza (aday → değerlendirme → kabul/askı akışı), dosyalar,
notlar, takvim.

## 8. L7 — Çoklu cihaz — SIRADAKİ

Ana düğüm + yetkili istemciler; tek kanonik kimlik. Ayrıntı: `platform-target.md`.

## 9. L8 — Evrim iskeleti — TAMAMLANDI (14 Eylül 2026)

Pasiflik ölçütü (4 sinyal), reseptör (aynı fikir tanıma), aday değerlendirme
(PTBL kartı). Canlı kanıt: "Sesli konuşma" fikri askıya alındı. Üretim: L8+.
Ayrıntı: `BLUEPRINTS.md` Bölüm 2.

## 10. L9 — Final — İSKELET HAZIR (14 Eylül 2026)

Taşınabilir paket: `export` komutu, 22 dosya, manifest + doğrulama temiz.
Kullanıcı bildirimi + tam paket (model dahil) sonraki adım.

## 11. PTBL genişleme — DEVAM EDİYOR (14 Eylül 2026)

Kullanıcı modeli (kısa mesaj oranı, konular, aktif saatler — açık kayıt).
Canlı kanıt: kullanıcının ritmi çıkarıldı.
"""Kalıcı kişisel hafıza: aday → değerlendirme → kabul/askı akışı (L6).

Foundation §9: kullanıcı açısından anlamlı, gerekli ve izinli bilgiler.
Her hafıza adayı değerlendirilir; kabul edilenler kalıcı olur, askıya alınanlar
bekler, reddedilenler kayda geçer ama kullanılmaz.

Kural: hafıza asla otomatik yazılmaz; kullanıcı onayı veya açık kayıt gerekir.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

MEMORY_STATUSES = ("aday", "kabul", "askida", "reddedildi")


@dataclass(frozen=True)
class MemoryCandidate:
    """Hafıza adayı: kullanıcı hakkında anlamlı bilgi."""

    content: str
    source: str
    confidence: float
    category: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "content": self.content,
            "source": self.source,
            "confidence": self.confidence,
            "category": self.category,
        }


def validate_candidate(candidate: MemoryCandidate) -> list[str]:
    """Aday bütünlük denetimi."""
    violations: list[str] = []
    if not candidate.content.strip():
        violations.append("içerik boş")
    if not candidate.source.strip():
        violations.append("kaynak boş")
    if not (0.0 <= candidate.confidence <= 1.0):
        violations.append("güven 0-1 dışında")
    if candidate.category not in ("tercih", "bilgi", "hedef", "kişisel"):
        violations.append(f"geçersiz kategori: {candidate.category}")
    return violations
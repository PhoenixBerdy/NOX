"""Taşınabilirlik: NOX'un tüm varlığını tek pakete toplar (L9 iskeleti).

Almanya planı: bilgisayar sıfırlanacak, Nox kocaman alana taşınacak.
Paket: SQLite verisi + model dosyası + config + docs + geri yükleme doğrulaması.
"""
from __future__ import annotations

import json
import shutil
import zipfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

MANIFEST_NAME = "nox_manifest.json"


@dataclass(frozen=True)
class ExportResult:
    output_path: Path
    files_count: int
    total_bytes: int
    manifest_path: Path


def export_nox(
    project_root: Path,
    output_dir: Path,
    include_model: bool = True,
) -> ExportResult:
    """NOX'u taşınabilir pakete toplar."""
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    output_path = output_dir / f"nox_portable_{timestamp}.zip"
    manifest: dict[str, Any] = {
        "created_at": datetime.now(UTC).isoformat(),
        "version": "1.0",
        "files": [],
    }

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        data_dir = project_root / "data"
        if data_dir.exists():
            for f in data_dir.rglob("*"):
                if f.is_file():
                    arcname = f"data/{f.relative_to(data_dir).as_posix()}"
                    zf.write(f, arcname)
                    manifest["files"].append({"path": arcname, "bytes": f.stat().st_size})

        for f in [project_root / "pyproject.toml", project_root / "README.md"]:
            if f.exists():
                zf.write(f, f.name)
                manifest["files"].append({"path": f.name, "bytes": f.stat().st_size})

        docs_dir = project_root / "docs"
        if docs_dir.exists():
            for f in docs_dir.rglob("*.md"):
                arcname = f"docs/{f.relative_to(docs_dir).as_posix()}"
                zf.write(f, arcname)
                manifest["files"].append({"path": arcname, "bytes": f.stat().st_size})

        if include_model:
            model_dir = project_root / "models"
            if model_dir.exists():
                for f in model_dir.glob("*.gguf"):
                    arcname = f"models/{f.name.as_posix()}"
                    zf.write(f, arcname)
                    manifest["files"].append({"path": arcname, "bytes": f.stat().st_size})

        manifest_bytes = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        zf.writestr(MANIFEST_NAME, manifest_bytes)

    manifest_path = output_dir / f"nox_manifest_{timestamp}.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    return ExportResult(
        output_path=output_path,
        files_count=len(manifest["files"]),
        total_bytes=output_path.stat().st_size,
        manifest_path=manifest_path,
    )


def verify_portable(zip_path: Path) -> list[str]:
    """Paket bütünlüğünü doğrular; eksik/bozuk dosya listesi döner."""
    issues: list[str] = []
    if not zip_path.exists():
        issues.append(f"paket yok: {zip_path}")
        return issues
    with zipfile.ZipFile(zip_path, "r") as zf:
        if MANIFEST_NAME not in zf.namelist():
            issues.append("manifest yok")
            return issues
        manifest = json.loads(zf.read(MANIFEST_NAME).decode("utf-8"))
        for entry in manifest["files"]:
            if entry["path"] not in zf.namelist():
                issues.append(f"eksik dosya: {entry['path']}")
    return issues
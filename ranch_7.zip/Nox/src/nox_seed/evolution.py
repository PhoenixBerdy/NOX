"""Evrim iskeleti: pasiflik ölçütü ve aday fikir kaydı (L8 ilk adım).

Blueprint B2 §5: evrim yalnızca birleşik pasiflik sağlandığında devreye girer.
Dört sinyal: girdi, ses, odak, Nox pasifliği.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class PassivityReport:
    """Birleşik pasiflik ölçütünün sonucu."""

    is_passive: bool
    input_idle_seconds: float
    audio_playing: bool
    fullscreen_app: bool
    nox_active: bool
    reason: str


def check_passivity(
    last_input_time: float | None = None,
    audio_playing: bool = False,
    fullscreen_app: bool = False,
    nox_active: bool = False,
    idle_threshold: float = 600.0,  # 10 dakika
) -> PassivityReport:
    """Dört sinyali birleştirir; pasiflik kararı verir."""
    now = time.time()
    idle = (now - last_input_time) if last_input_time else float("inf")

    reasons = []
    if idle < idle_threshold:
        reasons.append(f"girdi aktif ({idle:.0f}s < {idle_threshold:.0f}s)")
    if audio_playing:
        reasons.append("ses çıkışı var")
    if fullscreen_app:
        reasons.append("tam ekran uygulama var")
    if nox_active:
        reasons.append("Nox'a mesaj geldi")

    is_passive = not reasons
    return PassivityReport(
        is_passive=is_passive,
        input_idle_seconds=idle,
        audio_playing=audio_playing,
        fullscreen_app=fullscreen_app,
        nox_active=nox_active,
        reason="pasif" if is_passive else "; ".join(reasons),
    )


@dataclass(frozen=True)
class EvolutionIdea:
    """Aday evrim fikri: reseptör benzerlik kaydı için."""

    title: str
    source: str
    observation: str
    status: str  # candidate | evaluated | suspended | archived | discarded

    def as_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "source": self.source,
            "observation": self.observation,
            "status": self.status,
        }
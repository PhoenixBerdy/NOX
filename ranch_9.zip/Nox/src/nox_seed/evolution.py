"""Evrim iskeleti: pasiflik ölçütü ve aday fikir kaydı (L8 ilk adım).

Blueprint B2 §5: evrim yalnızca birleşik pasiflik sağlandığında devreye girer.
Dört sinyal: girdi, ses, odak, Nox pasifliği.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class PassivityReport:
    """Birleşik pasiflik ölçütünün sonucu."""

    is_passive: bool
    input_idle_seconds: float
    audio_playing: bool
    fullscreen_app: bool
    nox_active: bool
    reason: str

def parse_suggestion(model_output: str) -> EvolutionIdea | None:
    """Otonom fikir üretimini ayrıştırır."""
    fields: dict[str, str] = {}
    for line in model_output.splitlines():
        line = line.strip()
        for tag in ("FİKİR", "KAYNAK", "GEREKCE"):
            if line.startswith(tag + ":"):
                fields[tag] = line.split(":", 1)[1].strip()
                break
    title = fields.get("FİKİR", "").strip()
    if not title or title.upper() == "YOK":
        return None
    return EvolutionIdea(
        title=title,
        source=fields.get("KAYNAK", "otonom"),
        observation=fields.get("GEREKCE", ""),
        status="candidate",
    )


def build_suggest_prompt(capabilities: list[str], recent_projects: list[dict[str, Any]]) -> list[dict[str, str]]:
    import json

    user = json.dumps({
        "mevcut_yetenekler": capabilities,
        "son_projeler": [p["contract"]["title"] for p in recent_projects[:5]],
    }, ensure_ascii=False)
    return [
        {"role": "system", "content": SUGGEST_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]

def check_passivity(
    last_input_time: float | None = None,
    audio_playing: bool = False,
    fullscreen_app: bool = False,
    nox_active: bool = False,
    idle_threshold: float = 600.0,  # 10 dakika
) -> PassivityReport:
    """Dört sinyali birleştirir; pasiflik kararı verir."""
    now = time.time()
    idle = (now - last_input_time) if last_input_time else float("inf")

    reasons = []
    if idle < idle_threshold:
        reasons.append(f"girdi aktif ({idle:.0f}s < {idle_threshold:.0f}s)")
    if audio_playing:
        reasons.append("ses çıkışı var")
    if fullscreen_app:
        reasons.append("tam ekran uygulama var")
    if nox_active:
        reasons.append("Nox'a mesaj geldi")

    is_passive = not reasons
    return PassivityReport(
        is_passive=is_passive,
        input_idle_seconds=idle,
        audio_playing=audio_playing,
        fullscreen_app=fullscreen_app,
        nox_active=nox_active,
        reason="pasif" if is_passive else "; ".join(reasons),
    )


@dataclass(frozen=True)
class EvolutionIdea:
    """Aday evrim fikri: reseptör benzerlik kaydı için."""

    title: str
    source: str
    observation: str
    status: str  # candidate | evaluated | suspended | archived | discarded

    def as_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "source": self.source,
            "observation": self.observation,
            "status": self.status,
        }

SUGGEST_SYSTEM_PROMPT = """Bir evrim fikir üreticisisin. Sana Nox'un mevcut yetenekleri ve son projeleri verilecek.
Nox'a değer katacak yeni bir yetenek fikri öner. Küçük, uygulanabilir, güvenli fikirler.
Kesin hüküm verme; aday öner.

Yanıtını SADECE şu 3 satırda ver; başka hiçbir şey yazma:

FİKİR: <yetenek fikri başlığı, en fazla 5 kelime>
KAYNAK: <fikrin kaynağı (internet, proje, gözlem)>
GEREKCE: <neden değerli, tek cümle>"""      
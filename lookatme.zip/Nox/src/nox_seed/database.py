from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

from .models import PatternAssessment, StoredPattern


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class Database:
    """Small, inspectable SQLite event store for Seed v0.

    The database records facts and model interpretations separately. It does not
    infer personal memory or grant tools any authority.
    """

    def __init__(self, path: Path) -> None:
        self.path = path

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._session() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    project_id TEXT,
                    payload_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    source_event_id INTEGER,
                    observation TEXT NOT NULL,
                    interpretation TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence >= 0 AND confidence <= 1),
                    pattern_type TEXT NOT NULL,
                    evidence_json TEXT NOT NULL,
                    unknowns_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'candidate',
                    FOREIGN KEY(source_event_id) REFERENCES events(id)
                );

                CREATE TABLE IF NOT EXISTS pattern_stages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    pattern_id INTEGER NOT NULL,
                    stage TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    FOREIGN KEY(pattern_id) REFERENCES patterns(id)
                );

                CREATE INDEX IF NOT EXISTS idx_events_created_at ON events(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_patterns_created_at ON patterns(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_pattern_stages_pattern ON pattern_stages(pattern_id);
                """
            )

    def record_event(
        self,
        kind: str,
        payload: dict[str, Any],
        *,
        project_id: str | None = None,
    ) -> int:
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO events (created_at, kind, project_id, payload_json)
                VALUES (?, ?, ?, ?)
                """,
                (utc_now(), kind, project_id, json.dumps(payload, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def record_pattern(
        self,
        assessment: PatternAssessment,
        *,
        source_event_id: int | None = None,
        status: str = "candidate",
        merge: bool = True,
    ) -> int:
        """Aday örüntüyü kaydeder; merge=True iken benzer adayla birleştirir.

        Birleşmede yeni satır açılmaz: mevcut adayın kanıt listesi büyür,
        'recurrence' aşama kaydı düşülür ve güven sınırlı artar.
        """
        if merge and status == "candidate":
            from .recurrence import apply_recurrence, find_similar_candidate

            with self._session() as connection:
                hit = find_similar_candidate(connection, assessment.observation)
                if hit is not None:
                    pattern_id, sim, rec_count = hit
                    new_confidence = apply_recurrence(
                        connection,
                        pattern_id,
                        list(assessment.evidence),
                        rec_count,
                        utc_now(),
                    )
                    connection.execute(
                        """
                        INSERT INTO pattern_stages (created_at, pattern_id, stage, payload_json)
                        VALUES (?, ?, 'recurrence', ?)
                        """,
                        (
                            utc_now(),
                            pattern_id,
                            json.dumps(
                                {
                                    "similarity": sim,
                                    "new_evidence": list(assessment.evidence),
                                    "recurrence_count": rec_count + 1,
                                    "confidence": new_confidence,
                                },
                                ensure_ascii=False,
                            ),
                        ),
                    )
                    return pattern_id
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO patterns (
                    created_at, source_event_id, observation, interpretation,
                    confidence, pattern_type, evidence_json, unknowns_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    utc_now(),
                    source_event_id,
                    assessment.observation,
                    assessment.interpretation,
                    assessment.confidence,
                    assessment.pattern_type,
                    json.dumps(assessment.evidence, ensure_ascii=False),
                    json.dumps(assessment.unknowns, ensure_ascii=False),
                    status,
                ),
            )
            return int(cursor.lastrowid)

    def record_pattern_stage(
        self,
        pattern_id: int,
        stage: str,
        payload: dict[str, Any],
    ) -> int:
        """2. (anlamak) veya 3. (içselleştirmek) aşama çıktısını ayrı kayıt olarak ekler.

        Hiçbir aşama öncekinin üzerine yazmaz; her biri yeni satırdır.
        """
        with self._session() as connection:
            cursor = connection.execute(
                """
                INSERT INTO pattern_stages (created_at, pattern_id, stage, payload_json)
                VALUES (?, ?, ?, ?)
                """,
                (utc_now(), pattern_id, stage, json.dumps(payload, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def pattern_stages(self, pattern_id: int) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, stage, payload_json
                FROM pattern_stages
                WHERE pattern_id = ?
                ORDER BY id ASC
                """,
                (pattern_id,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "stage": row["stage"],
                "payload": json.loads(row["payload_json"]),
            }
            for row in rows
        ]

    def set_pattern_status(self, pattern_id: int, status: str) -> None:
        """Kullanıcı onayıyla örüntünün yaşam döngüsü durumunu günceller."""
        with self._session() as connection:
            connection.execute(
                "UPDATE patterns SET status = ? WHERE id = ?",
                (status, pattern_id),
            )

    def recent_events(self, limit: int = 10) -> list[dict[str, Any]]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, kind, project_id, payload_json
                FROM events
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [
            {
                "id": int(row["id"]),
                "created_at": row["created_at"],
                "kind": row["kind"],
                "project_id": row["project_id"],
                "payload": json.loads(row["payload_json"]),
            }
            for row in rows
        ]

    def recent_patterns(self, limit: int = 10) -> list[StoredPattern]:
        with self._session() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, source_event_id, observation, interpretation,
                       confidence, pattern_type, evidence_json, unknowns_json, status
                FROM patterns
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._row_to_pattern(row) for row in rows]

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _session(self) -> Iterator[sqlite3.Connection]:
        """Commit or roll back each operation and always release the Windows file handle."""
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def _row_to_pattern(row: sqlite3.Row) -> StoredPattern:
        return StoredPattern(
            id=int(row["id"]),
            created_at=row["created_at"],
            source_event_id=row["source_event_id"],
            assessment=PatternAssessment(
                observation=row["observation"],
                interpretation=row["interpretation"],
                confidence=float(row["confidence"]),
                pattern_type=row["pattern_type"],
                evidence=list(json.loads(row["evidence_json"])),
                unknowns=list(json.loads(row["unknowns_json"])),
            ),
            status=row["status"],
        )
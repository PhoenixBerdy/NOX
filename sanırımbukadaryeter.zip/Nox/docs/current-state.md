# Nox — Güncel Durum

Son güncelleme: 13 Eylül 2026 (akşam oturumu)

## Neredeyiz?

**L2 (Project Core) TAMAMLANDI.** Work modeli kağıttan çıktı: 4 proje üretildi,
1 oyun oynandı, hizalanma canlı, Proje Masası zengin. **Ollama'sız NOX çalışıyor** —
llama.cpp GGUF, kendi beyniyle, kendi platformunda.

## Bu oturumda yapılanlar (13 Eylül akşamı)

### L2 kodu (tamamlandı)
- Project Core: `projects`, `project_transitions`, `assumptions` tabloları
- CLI: `project new / list / status / advance / step / code / reflect / validate / pdf`
- Model destekli sözleşme, kontrol noktası yürütücüsü, kod üretimi + güvenlik kapısı
- Hizalanma döngüsü (canlı öz-yansıma), Proje Masası (demo'da zengin)
- 93 test yeşil

### Platform alfa (Tauri)
- Kendi masaüstü uygulaması: sol ray + merkez sohbet + sağ kayar panel
- Streaming sohbet (Ollama API), SQLite köprüsü (Rust backend)
- Proje kartları → detay paneli (sözleşme + dosyalar)

### Model katmanı
- **Backend soyutlaması:** `ModelBackend` arayüzü + `OllamaBackend` + `LlamaCppBackend`
- **Ollama'sız çalışma kanıtlandı:** llama.cpp GGUF (Qwen3-4B), kendi beyniyle,
  kendi kimliğiyle (sistem promptu devrede). Ollama kapalıyken sohbet çalıştı.
- Bilinen kusur: `<think>` etiketi açık (think modu llama.cpp'de kapanmamış),
  cümle yapısı ("Sen Nox") prompt'tan kaynaklı — ince ayar sonrası.

### Blueprint'ler
- Work + Hizalanma (Bölüm 1) [TASARIM]
- Evrim (Bölüm 2) [TASARIM] — pasiflik ölçütü, hazırlık otonom/uygulama onaylı
- Platform (Bölüm 3) [ÖN ARAŞTIRMA] — dokuz bölge anatomisi, renk-körlüğü paleti

## Bilinen sınırlar / açık işler

- `<think>` etiketi ve "Sen Nox" cümle yapısı: prompt/think ayarı incelemesi.
- Tauri alfa: markdown yok, kod bloğu yok, Proje Masası basit.
- Model indirme: `models/Qwen3-4B-Q4_K_M.gguf` (2.5 GB) — zip'e katma.
- PDF Türkçe font: platform aşamasında.

## Açık kararlar (kullanıcı bekleniyor)

1. **Nihai model katmanı:** llama.cpp GGUF (seçildi, çalışıyor) — üretim geçişi ne zaman?
2. **Kişilik değerlendirme oturumu:** 4 soruluk demo sözleşme testi yapıldı mı?
3. **Yeni logo/kimlik:** platform aşamasına mı ertelendi?
4. **Eğitim müfredatı:** zamanı geldi mi?

## Sıradaki katman: L3 — Platform (alfa üstüne)

- Tauri platformunu zenginleştir: markdown, kod bloğu, Proje Masası tam veri
- Model katmanını üretime taşı: llama.cpp varsayılan backend, Ollama opsiyonel
- W5 (medya) ön araştırması

## Yeni sohbette devam komutu

`C:\Users\Yağız Cem\Documents\Projects\Nox` projesine devam et. Önce `README.md`,
`docs/foundation.md`, `docs/current-state.md` (bu dosya), `docs/seed-v0.md` ve
`docs/roadmap.md`'yi oku. L2 tamamlandı; L3 platform zenginleştirme ve model
katmanı üretimi sürüyor. Ollama'sız çalışma: `$env:NOX_BACKEND = "llama_cpp"`.
Test komutu: `$env:PYTHONPATH = "src"; python -m unittest discover -s tests`
(beklenen: 93 test, OK).
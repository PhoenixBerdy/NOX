# NOX — BLUEPRINTS
Tüm katman blueprint'lerinin tek evi. Her blueprint durum etiketi taşır:
[TASARIM] · [İNŞADA] · [TAMAMLANDI] · [ARŞİV]

---

# BÖLÜM 1 — WORK MODELİ + HİZALANMA [TASARIM]
**Tarih:** 13 Eylül 2026 · **Kaynak:** foundation.md §4 + newideasforme.txt manifestosu

> Tasarım belgesidir; buradaki bileşenler henüz kodda yok. L2'nin inşa planıdır.

## 1. Work modeli nedir

Nox'un sohbet penceresinden çıkıp üreten bir ortak olmasıdır: kullanıcı proje verir,
Nox sözleşme yayımlar, arka planda çalışır, kullanıcı bu sırada konuşmaya devam eder,
çıktı kontrol noktalarıyla ve doğrulanmış biçimde teslim edilir. "İki ayrı zeka mı?"
sorusunun cevabı: hayır — tek kimlik, üç iş hattı.

## 2. Üretim kapsamı (aşamalı)

| Seviye | Yetenek | İlk doğrulama |
|---|---|---|
| W1 | Metin/belge üretimi (rehber, liste, plan) | Almanca kelime listesi |
| W2 | Kod üretimi (tek dosyalık web oyunu) | Cookie-clicker prototipi |
| W3 | Çok dosyalı proje (kod + asset manifesti) | Cookie-clicker tam sürüm |
| W4 | Belge üretimi (PDF, tablo) | Stardew rehberi (PDF) |
| W5 | Medya (görsel/ses/video) | platform aşamasında araştırılır |

W5, 4B yerel modelin kapsamı dışında; vaat edilmez. W1-W3 bu donanımda çalışır.

## 3. Yetki haritası (4 seviye)

- **YEŞİL (A):** sessiz, kayıtlı otonomi. Teknoloji seçimi, dosya yapısı, iç mimari.
  Varsayım defterine yazılır, bildirim yok.
- **LİME (A½):** sessiz otonomi + sorgulanabilir gerekçe. Kullanıcıya dokunan teknik
  kararlar (kayıt biçimi, performans hedefi, varsayılanlar). Nox karar verir,
  gerekçeyi kaydeder; sorulursa açıklar.
- **SARI (B):** seçenek sunar, varsayılanla ilerler. Yaratıcı/yön kararları (oyun
  mekaniği, görsel stil). 2-3 seçenek + işaretli varsayılan; cevap yoksa varsayılan.
- **KIRMIZI (C):** her zaman sorar. Geri dönüşü olmayan/dış etkili işler: yayınlama,
  hesap/ödeme, dış servis, büyük dosya üzerine yazma.

Her karar; seviye, gerekçe, güven, alternatif ile varsayım defterine yazılır.

## 4. Proje yaşam döngüsü

taslak → sözleşme yayımlandı → sırada → çalışıyor → doğrulanıyor → tamamlandı
(duraklatıldı / yeniden planlanıyor / kullanıcı girdisi bekliyor / engellendi / iptal)

Her durum değişimi; neden, zaman, kaynak, dosyalar ve ara çıktıyla kaydedilir.
Nox kapansa bile proje kayıttan devam eder.

**Sözleşme içeriği:** hedeflenen çıktı, başarı ölçütü, kapsam ve kapsam dışı,
teknoloji yaklaşımı, varsayımlar + güven, kilometre taşları, kaynak bütçesi,
hangi koşulda kullanıcıyı bekleyeceği.

## 5. Üç akış mimarisi

1. **Canlı sohbet:** kullanıcı mesajı her zaman öncelikli.
2. **Proje:** iş küçük kontrol noktalarına bölünür; her noktada gelen kutu denetlenir.
3. **Sistem:** kuyruk, kaynak bütçesi, kayıt, güvenlik kapısı, bildirim — modelin
   keyfî yorumuna bırakılmaz.

Fiziksel sınır: qwen3:4b + 4 GB VRAM'de tek üretim hattı. Eşzamanlılık mantıksaldır;
5-6 proje açık kalabilir, hat kısa dilimlerle paylaşılır.

## 6. Öncelik kuyruğu (aç bırakmayan)

Sinyaller: kullanıcı aciliyeti (baskın), son tarih, bekletme maliyeti, değer,
tamamlanmaya yakınlık, bağımlılık hazırlığı, tahmini süre/kaynak, bekleme süresi
(arttıkça öncelik artar). Nox gerekçeyi görünür kılar; kullanıcı sırayı değiştirebilir.

İlk doğrulama: Stardew rehberi sürerken acil Almanca kelime listesi öne alınır,
rehber kayıpsız duraklatılır ve devam eder.

## 7. Hizalanma döngüsü (4 katman)

1. **Sözleşme hizası:** ara çıktı her kontrol noktasında başarı ölçütüyle karşılaştırılır.
2. **PTBL hizası:** kalite kapısı + regresyon denetimi (L1'den).
3. **Beklenti↔sonuç öz-yansıması:** her adımda tahmin yazılır, sonuçla karşılaştırılır;
   yanılma PTBL verisidir.
4. **Kullanıcı düzeltme metriği:** düzeltme sayısı/türü zamanla ölçülür; ana başarı
   ölçütü düzeltme ihtiyacının azalmasıdır. (Kullanıcı onayı: başka ölçüt yok.)

## 8. Güvenlik kapısı bağlantısı

- Üretim yalnızca izole proje klasörüne: `data/projects/<proje_id>/`
- Klasör dışına yazma SARI; silme/üzerine yazma KIRMIZI; dışa veri gönderme KIRMIZI.
- Güvenlik katmanı kişilikten her zaman üstündür (karşılıklı onaylı kırmızı çizgi).
- Red-line içeriği en son kullanıcıyla birlikte yazılacak.

## 9. PTBL entegrasyonu ("PTBL manyağı" ilkesi)

Çift yönlü beslenme: proje araştırmasındaki öğretim/anlatım örüntüleri PTBL adayı olur;
kullanıcı geri bildirimi PTBL kaydıdır; çıktı üslubu kullanıcı ritmine uyar.

## 10. L2 inşa sırası

1. `projects` tablosu + yaşam döngüsü (events.project_id kancası hazır)
2. `assumptions` tablosu (varsayım defteri)
3. Sözleşme üretici + CLI: project new / status / list
4. Kontrol noktası yürütücüsü (tek hatlı, kısa dilimler)
5. Öncelik kuyruğu + kullanıcı geçersiz kılma
6. İzole proje klasörü + güvenlik kapısı ilk sürümü
7. Hizalanma döngüsü: sözleşme doğrulama + beklenti/sonuç kaydı
8. W1 doğrulaması: Almanca kelime listesi (uçtan uca)
9. W2 doğrulaması: cookie-clicker prototipi

Her adım kendi testleriyle gelir; mevcut 42 test bozulmadan büyür.

## 11. Açık bırakılanlar

- W5 (medya): platform aşamasında araştırılacak; vaat yok.
- Gerçek paralellik: ölçüm sonrası.
- Demo arayüzüne proje görünürlüğü: L2 sonrası (Proje Masası demosu).
- Evrim blueprint'i: Bölüm 2'de yazılacak.

---

# BÖLÜM 2 — EVRİM [TASARIM BEKLİYOR]
Kullanıcı manifestosundaki evrim fikirleri (GitHub'dan otonom kod arama, fikir
reseptörleri, askı/arşiv/çöp yaşam döngüsü, "hazırlık otonom, uygulama onaylı"
modeli) burada blueprint'lenecek.

# BÖLÜM 3 — PLATFORM [ERTELENDİ]
Kullanıcı kararı: her şey tasarlandıktan sonra. Referans araştırması o aşamada.